﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ALC.Forms;
using System.Threading;
using LogLib;

namespace ALC
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            bool IsRun;
            Mutex m = new Mutex(true, "ALC", out IsRun);
            if (IsRun)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Form frmlogin = new FormLogIn();
                if (frmlogin.ShowDialog() == DialogResult.OK)
                {
                    Application.Run(new FormMain());
                }
                m.ReleaseMutex();
            }
            else
            {
                Log.showMessageBox("ALC program is already running!", "ALC", MsgBoxButtons.OK, MsgBoxIcon.Information);
                return;
            }
        }
    }
}
