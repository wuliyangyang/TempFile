﻿using AlcUtility;
using LogLib;
using System;
using System.Collections.Generic;

namespace ALC.Managers
{
    public class PluginOperateMgr
    {
        private static PluginOperateMgr _instance = new PluginOperateMgr();

        public static PluginOperateMgr GetInstance()
        {
            return _instance;
        }

        private PluginOperateMgr()
        {
            _operations = new Dictionary<PluginOperateItem, Func<object, object>>()
            {
                { PluginOperateItem.UpdateModuleStatus, UpdateModuleStatus },
                { PluginOperateItem.WriteLog, WriteLog },
                { PluginOperateItem.ShowMsgBox, ShowMsgBox },
                { PluginOperateItem.SaveCsv, SaveCsv },
                { PluginOperateItem.Error, Error },
                { PluginOperateItem.GetSystemStatus, GetSystemStatus },
                { PluginOperateItem.GetMode, GetMode },
                { PluginOperateItem.GetUser, GetUser },
                { PluginOperateItem.ButtonClickRequire, ButtonClickRequire },
                { PluginOperateItem.GetSoftwareVersion, GetSoftwareVersion },
            };
        }

        private Dictionary<PluginOperateItem, Func<object, object>> _operations;

        public void Setup(ref Action<string> formShown)
        {
            AlcSystem.Instance.SetUpdateALC(PluginOperate);
            UserMgr.GetInstance().UserAuthorityChanged +=
                (oldAuthority, UserAuthority) => AlcSystem.Instance.UserAuthorityChanged?.Invoke(oldAuthority, UserAuthority);
            formShown += formName => AlcSystem.Instance.FormShown?.Invoke(formName);
            LogicMgr.GetInstance().CanInit += () =>
            {
                if (AlcSystem.Instance.CanInit != null)
                {
                    foreach (Func<string> canInit in AlcSystem.Instance.CanInit.GetInvocationList())
                    {
                        string message = canInit();
                        if (!string.IsNullOrEmpty(message))
                        {
                            return message;
                        }
                    }
                }
                return null;
            };
            LogicMgr.GetInstance().CanStart += () =>
            {
                if (AlcSystem.Instance.CanStart != null)
                {
                    foreach (Func<string> canStart in AlcSystem.Instance.CanStart.GetInvocationList())
                    {
                        string message = canStart();
                        if (!string.IsNullOrEmpty(message))
                        {
                            return message;
                        }
                    }
                }
                return null;
            };
            LogicMgr.GetInstance().CanStop += () =>
            {
                if (AlcSystem.Instance.CanStop != null)
                {
                    foreach (Func<string> canStop in AlcSystem.Instance.CanStop.GetInvocationList())
                    {
                        string message = canStop();
                        if (!string.IsNullOrEmpty(message))
                        {
                            return message;
                        }
                    }
                }
                return null;
            };
            LogicMgr.GetInstance().CanPause += () =>
            {
                if (AlcSystem.Instance.CanPause != null)
                {
                    foreach (Func<string> canPause in AlcSystem.Instance.CanPause.GetInvocationList())
                    {
                        string message = canPause();
                        if (!string.IsNullOrEmpty(message))
                        {
                            return message;
                        }
                    }
                }
                return null;
            };
            LogicMgr.GetInstance().CanResume += () =>
            {
                if (AlcSystem.Instance.CanResume != null)
                {
                    foreach (Func<string> canResume in AlcSystem.Instance.CanResume.GetInvocationList())
                    {
                        string message = canResume();
                        if (!string.IsNullOrEmpty(message))
                        {
                            return message;
                        }
                    }
                }
                return null;
            };
            LogicMgr.GetInstance().CanReset += () =>
            {
                if (AlcSystem.Instance.CanReset != null)
                {
                    foreach (Func<string> canReset in AlcSystem.Instance.CanReset.GetInvocationList())
                    {
                        string message = canReset();
                        if (!string.IsNullOrEmpty(message))
                        {
                            return message;
                        }
                    }
                }
                return null;
            };
        }

        public object PluginOperate(PluginOperateItem opItem, object data)
        {
            try
            {
                return _operations[opItem](data);
            }
            catch (Exception e)
            {
                Log.showMessageBox(e.Message + "\r\n" + e.StackTrace, "PluginOp", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return null;
            }
        }

        private object UpdateModuleStatus(object obj)
        {
            var param = (UpdateModuleStatusParam)obj;
            LogicMgr.GetInstance().UpdateModuleStatus(param.moduleType, param.alive);
            return null;
        }

        private object WriteLog(object obj)
        {
            var param = (WriteLogParam)obj;
            Log.writeLog(param.message, (int)param.errorLevel, param.moduleOrFileName);
            return null;
        }

        private object ShowMsgBox(object obj)
        {
            var p = (ShowMsgBoxParam)obj;
            var ret = Log.showMessageBox(p.text, p.caption, (MsgBoxButtons)p.buttons, (MsgBoxIcon)p.icon, (MsgBoxDefaultButton)p.defaultbutton);
            if (ret == MsgBoxResult.Stop)
            {
                LogicMgr.GetInstance().Stop();
            }
            else if (ret == MsgBoxResult.Abort)
            {
                LogicMgr.GetInstance().Abort();
            }
            return ret;
        }

        private object SaveCsv(object obj)
        {
            var param = (SaveCsvParam)obj;
            Log.saveCsv(param.csvName, param.msg, param.head, param.addTime);
            return null;
        }

        private object Error(object obj)
        {
            var param = (ErrorParam)obj;
            return ErrorHandler.GetInstance().HandleError(param.moduleType, param.errorCode, (int)param.errorLevel, param.errorMsg);
        }

        private object GetSystemStatus(object obj)
        {
            return StatusMgr.SystemStatus;
        }

        private object GetMode(object obj)
        {
            return null;
        }

        private object GetUser(object obj)
        {
            return UserMgr.GetInstance().CurrentUser.authority;
        }

        private object ButtonClickRequire(object obj)
        {
            var param = (ButtonClickRequireParam)obj;
            switch(param.button)
            {
                case ButtonsName.Init:
                    LogicMgr.GetInstance().Init();
                    break;
                case ButtonsName.Start:
                    LogicMgr.GetInstance().Start();
                    break;
                case ButtonsName.Pause:
                    LogicMgr.GetInstance().Pause();
                    break;
                case ButtonsName.Reset:
                    LogicMgr.GetInstance().Reset();
                    break;
                case ButtonsName.Stop:
                    LogicMgr.GetInstance().Stop();
                    break;
                case ButtonsName.Resume:
                    LogicMgr.GetInstance().Resume();
                    break;
            }
            return null;
        }

        private object GetSoftwareVersion(object obj)
        {
            return XmlHelper.GetInstance().Version;
        }
    }
}