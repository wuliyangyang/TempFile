﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogLib
{
    public class DefLogTab
    {
        public const string All = "ALL";
        public const string ERROR = "ERROR";
        public const string OPERATION = "OPERATION";
    }
}
