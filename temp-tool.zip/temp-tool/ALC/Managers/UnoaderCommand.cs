﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EventDispatch;
using NetCom.Utility;
using System.Threading;
using ALC.Managers;
using ALC.ConstTypes;
using ALC.Forms;
using Newtonsoft.Json;

namespace ALC.Managers
{
    public class UnloaderCommand
    {
        private static UnloaderCommand _instance = new UnloaderCommand();
        public static UnloaderCommand getInstance()
        {
            return _instance;
        }

        private bool _ready = false;
        public AutoResetEvent _eventReady = new AutoResetEvent(false);
        public SYSTEM_STATUS RunningStatus = SYSTEM_STATUS.Idle;
        EventClient _client;

        private UnloaderCommand()
        {
            _client = new EventClient(new List<MSG_TYPE>() { MSG_TYPE.UNLOADSEND });
            _client.DealReceivedData += HandleMessage;
        }

        private string _testerId = string.Empty;

        public int UnloadSystemStopDone { get; set; }
        public int UnloadSystemResetDone { get; set; }

        public void startServer()
        { }

        private void HandleMessage(ReceivedData data)
        {
            if (data.modelType != MSG_TYPE.UNLOADSEND) return;

            GMgr.UIView.LogWrite(LogUpdateItem.Unloader, string.Format("Unload--->ALC : {0} {1}", data.msgData.msgName, data.msgData.msgParam), ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.TRACE);
                    
            switch (data.msgData.msgName)
            {
                case CommonDefinition.Init:
                    _ready = true;
                    _testerId = data.testerId;
                    //GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Received UnoadCommand Init", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.TRACE);
                    RunningStatus = SYSTEM_STATUS.Ready;
                     FormHome.Instance.UpdateUISystemStatus();
                    _eventReady.Set();
                    break;

                case CommonDefinition.Msg_Disconnet:
                    RunningStatus = SYSTEM_STATUS.Error;
                     FormHome.Instance.UpdateUISystemStatus();
                    _ready = true;
                    _testerId = data.testerId;
                    GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "UnloadCommand client disconnected!", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.ERROR);
                    break;

                #region Start
                case "Start": //response of "Start"
                    //GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Unload Start Ok, begin to Reset...", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.TRACE);
                    //Ask load to reset
                    this.SendCommnd(CommonDefinition.Reset);
                    break;
                #endregion

                #region Reset
                case "Reset": //Reset Ok
                    GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Unload Reset Ok.", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.TRACE);
                    break;
                #endregion

                #region System Stop
                case "SystemStop": 
                    GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Unloader--->ALC: SystemStop...", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.TRACE);
                    //if (!GMgr.SystermStopped())
                    {
                        if (data.msgData.msgResult == 0)
                        {
                            UnloadSystemStopDone = 1;
                            GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Unloader--->ALC: SystemStop Ok.", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.TRACE);
                        }
                        else
                        {
                            UnloadSystemStopDone = -1;
                            GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Unloader--->ALC: SystemStop Failed!", ALC.ConstTypes.ErrorCode.EC_SystemStopFailed, ILogNet.ConstTypes.ErrLevel.ERROR);
                        }
                    }
                    break;
                #endregion

                #region System reset
                case "SystemReset":
                    GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Unloader--->ALC: SystemReset...", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.TRACE);
                    //if (!GMgr.SystermStopped())
                    {
                        if (data.msgData.msgResult == 0)
                        {
                            UnloadSystemResetDone = 1;
                            GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Unloader--->ALC: SystemReset Ok.", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.TRACE);
                        }
                        else
                        {
                            UnloadSystemResetDone = -1;
                            GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Unloader--->ALC: SystemReset Failed!", ALC.ConstTypes.ErrorCode.EC_SystemResetFailed, ILogNet.ConstTypes.ErrLevel.ERROR);
                        }
                    }
                    break;
                #endregion
                default:
                    GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "Received unkown message from UnloadCommond client", ALC.ConstTypes.ErrorCode.EC_OK, ILogNet.ConstTypes.ErrLevel.ERROR);
                    break;
            }
        }

        public void SendCommnd(string cmd)
        {
            //Thread.Sleep(5000);
            if (string.IsNullOrEmpty(_testerId))
            {
                GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "No UnloadCommand Client connected!", ALC.ConstTypes.ErrorCode.EC_NoLoadCommondConnect, ILogNet.ConstTypes.ErrLevel.ERROR);
            }

            JsonMessage msg = new JsonMessage()
            {
                msgType = "Req",
                msgName = cmd,
                msgParam = null,
                msgResult = 0,
                errMsg = ""
            };
            GMgr.unloader.Send(_testerId, msg);
            GMgr.UIView.LogWrite(LogUpdateItem.Unloader, string.Format("ALC--->Unloader: {0}", cmd), ALC.ConstTypes.ErrorCode.EC_NoLoadCommondConnect, ILogNet.ConstTypes.ErrLevel.TRACE);
        }

        public void SendCommnd(JsonMessage msg)
        {
            //Thread.Sleep(5000);
            if (string.IsNullOrEmpty(_testerId))
            {
                GMgr.UIView.LogWrite(LogUpdateItem.Unloader, "No UnloadCommand Client connected!", ALC.ConstTypes.ErrorCode.EC_NoLoadCommondConnect, ILogNet.ConstTypes.ErrLevel.ERROR);
            }

            GMgr.unloader.Send(_testerId, msg);
            GMgr.UIView.LogWrite(LogUpdateItem.Unloader, string.Format("ALC--->Unload: {0} {1}", msg.msgName, JsonConvert.SerializeObject(msg.msgParam)), 0, ILogNet.ConstTypes.ErrLevel.TRACE);            
        }

        public bool IsReady()
        {
            //_eventReady.WaitOne(3000);
            return _ready;
        }
    }
}
