﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlcUtility
{
    public class AlcSystem
    {
        public static AlcSystem Instance { get; private set; } = new AlcSystem();

        private AlcSystem() { }

        #region Event
        public Action<string, string> UserAuthorityChanged;
        public Action<string> FormShown;
        public Func<string> CanInit;
        public Func<string> CanStart;
        public Func<string> CanStop;
        public Func<string> CanPause;
        public Func<string> CanResume;
        public Func<string> CanReset;
        #endregion //Event

        #region Operation
        private Func<PluginOperateItem, object, object> UpdateALC;
        public void SetUpdateALC(Func<PluginOperateItem, object, object> func)
        {
            if (UpdateALC == null) UpdateALC = func;
        }
        public void Log(string text, string moduleOrFileName, AlcErrorLevel errLevel = AlcErrorLevel.TRACE)
        {
            UpdateALC(PluginOperateItem.WriteLog, new WriteLogParam()
            {
                message = text,
                moduleOrFileName = moduleOrFileName,
                errorLevel = errLevel
            });
        }
        public void UpdateModuleStatus(bool alive, string moduleType)
        {
            UpdateALC(PluginOperateItem.UpdateModuleStatus, new UpdateModuleStatusParam()
            {
                moduleType = moduleType,
                alive = alive,
            });
        }
        public AlcMsgBoxResult ShowMsgBox(string text, string caption, AlcMsgBoxButtons buttons = AlcMsgBoxButtons.OK, AlcMsgBoxIcon icon = AlcMsgBoxIcon.Information, AlcMsgBoxDefaultButton defaultButton = AlcMsgBoxDefaultButton.Button1)
        {
            if (text == null) return AlcMsgBoxResult.None;
            return (AlcMsgBoxResult)UpdateALC(PluginOperateItem.ShowMsgBox, new ShowMsgBoxParam()
            {
                text = text,
                caption = caption ?? "ALC",
                buttons = buttons,
                icon = icon,
                defaultbutton = defaultButton,
            });
        }
        public void SaveCsv(string csvName, string head, string text, bool addTime = true)
        {
            if (string.IsNullOrEmpty(head) || string.IsNullOrEmpty(text)) return;
            UpdateALC(PluginOperateItem.SaveCsv, new SaveCsvParam()
            {
                csvName = csvName ?? "ALC",
                head = head,
                msg = text,
                addTime = addTime,
            });
        }
        public AlcMsgBoxResult Error(string errorMsg, long errorCode, AlcErrorLevel errorLevel, string moduleType)
        {
            return (AlcMsgBoxResult)UpdateALC(PluginOperateItem.Error, new ErrorParam()
            {
                moduleType = moduleType,
                errorMsg = errorMsg,
                errorCode = errorCode,
                errorLevel = errorLevel,
            });
        }
        public SYSTEM_STATUS GetSystemStatus()
        {
            return (SYSTEM_STATUS)UpdateALC(PluginOperateItem.GetSystemStatus, null);
        }
        public string GetUserAuthority()
        {
            return (string)UpdateALC(PluginOperateItem.GetUser, null);
        }
        public void ButtonClickRequire(ButtonsName button)
        {
            UpdateALC(PluginOperateItem.ButtonClickRequire, new ButtonClickRequireParam()
            {
                button = button,
            });
        }
        public string GetSoftwareVersion()
        {
            return (string)UpdateALC(PluginOperateItem.GetSoftwareVersion, null);
        }
        #endregion //Operation
    }
}
