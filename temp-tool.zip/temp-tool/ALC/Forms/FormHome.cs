﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using WeifenLuo.WinFormsUI.Docking;
using ALC.Managers;
using System.Windows.Forms;
using LogLib;
using AlcUtility;

namespace ALC.Forms
{
    public partial class FormHome : DockContent
    {
        public FormHome()
        {
            InitializeComponent();
            AutoScaleMode = AutoScaleMode.Dpi;

            buttonsImage = new Dictionary<ButtonsName, Tuple<Image, string, Image, string>>()
            {
                {ButtonsName.Init, new Tuple<Image, string, Image, string>(Properties.Resources.init, "Init", null, null) },
                {ButtonsName.Start, new Tuple<Image, string, Image, string>(Properties.Resources.icon_start, "Start", Properties.Resources.icon_stop, "Stop") },
                {ButtonsName.Pause, new Tuple<Image, string, Image, string>(Properties.Resources.icon_suspended, "Pause", Properties.Resources.icon_restore, "Resume") },
                {ButtonsName.Reset, new Tuple<Image, string, Image, string>(Properties.Resources.reset, "Reset", null, null) },
            };
            initButtons();

            LogicMgr.GetInstance().SetFormHome(this);
            LogicMgr.GetInstance().UpdateSystemStatus(SYSTEM_STATUS.Idle);
        }

        private TableLayoutPanel tPanel_buttons = new TableLayoutPanel();
        private Dictionary<ButtonsName, Button> homeButtons = new Dictionary<ButtonsName, Button>();
        private readonly Dictionary<ButtonsName, Tuple<Image, string, Image, string>> buttonsImage;
        private Dictionary<ButtonsName, bool> buttonsInUse = new Dictionary<ButtonsName, bool>();
        private Dictionary<ButtonsName, bool> buttonsEnable = new Dictionary<ButtonsName, bool>();
        private Dictionary<ButtonsName, bool> buttonsDefault = new Dictionary<ButtonsName, bool>();

        private void FormHome_Activated(object sender, EventArgs e)
        {
            //this.Invalidate();
            Application.DoEvents();
        }

        #region update lbl_SystemStatus's backcolor

        private delegate void dUpdateLbl_SystemStatus(object obj);

        public void UpdateColor_Lbl_SystemStatus(Color color)
        {
            if (InvokeRequired)
                BeginInvoke(new dUpdateLbl_SystemStatus(_UpdateColor_Lbl_SystemStatus), color);
            else
                _UpdateColor_Lbl_SystemStatus(color);
        }

        private void _UpdateColor_Lbl_SystemStatus(object color)
        {
            lbl_SystemStatus.BackColor = (Color)color;
        }

        public void UpdateText_Lbl_SystemStatus(string text)
        {
            if (InvokeRequired)
                BeginInvoke(new dUpdateLbl_SystemStatus(_UpdateText_Lbl_SystemStatus), text);
            else
                _UpdateText_Lbl_SystemStatus(text);
        }

        private void _UpdateText_Lbl_SystemStatus(object text)
        {
            lbl_SystemStatus.Text = text.ToString();
        }
        #endregion //update lbl_SystemStatus's backcolor


        #region Buttons

        #region init buttons
        private void initButtons()
        {
            foreach(ButtonsName btnName in Enum.GetValues(typeof(ButtonsName)))
            {
                buttonsInUse.Add(btnName, false);
                buttonsEnable.Add(btnName, false);
                buttonsDefault.Add(btnName, true);
            }

            tPanel_buttons.Dock = DockStyle.Fill;
            tPanel_buttons.GrowStyle = TableLayoutPanelGrowStyle.AddColumns;
            Button button;
            int buttonIndex = 0;
            if (XmlHelper.GetInstance().ShowInitButton)
            {
                buttonsInUse[ButtonsName.Init] = true;
                tPanel_buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
                button = getButton(ButtonsName.Init);
                tPanel_buttons.Controls.Add(button, buttonIndex++, 0);
                homeButtons.Add(ButtonsName.Init, button);
            }
            if (XmlHelper.GetInstance().ShowStartButton)
            {
                buttonsInUse[ButtonsName.Start] = true;
                tPanel_buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
                button = getButton(ButtonsName.Start);
                tPanel_buttons.Controls.Add(button, buttonIndex++, 0);
                homeButtons.Add(ButtonsName.Start, button);
            }
            if (XmlHelper.GetInstance().ShowPauseButton)
            {
                buttonsInUse[ButtonsName.Pause] = true;
                tPanel_buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
                button = getButton(ButtonsName.Pause);
                tPanel_buttons.Controls.Add(button, buttonIndex++, 0);
                homeButtons.Add(ButtonsName.Pause, button);
            }
            if (XmlHelper.GetInstance().ShowResetButton)
            {
                buttonsInUse[ButtonsName.Reset] = true;
                tPanel_buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
                button = getButton(ButtonsName.Reset);
                tPanel_buttons.Controls.Add(button, buttonIndex++, 0);
                homeButtons.Add(ButtonsName.Reset, button);
            }
            tPanel_top.ColumnCount++;
            tPanel_top.ColumnStyles.Insert(0, new ColumnStyle(SizeType.Absolute, 160F * buttonIndex));
            tPanel_top.Controls.Add(tPanel_buttons, 0, 0);
        }

        private Button getButton(ButtonsName buttonName)
        {
            Button button = new Button();
            button.Dock = DockStyle.Fill;
            button.ImageAlign = ContentAlignment.TopCenter;
            button.TextAlign = ContentAlignment.BottomCenter;

            switch (buttonName)
            {
                case ButtonsName.Init:
                    button.Image = Properties.Resources.init;
                    button.Text = "Init";
                    button.Click += new EventHandler(btnInit_Click);
                    break;
                case ButtonsName.Start:
                    button.Image = Properties.Resources.icon_start;
                    button.Text = "Start";
                    button.Click += new EventHandler(btnStart_Click);
                    break;
                case ButtonsName.Pause:
                    button.Image = Properties.Resources.icon_suspended;
                    button.Text = "Pause";
                    button.Click += new EventHandler(btnPause_Click);
                    break;
                case ButtonsName.Reset:
                    button.Image = Properties.Resources.icon_restore;
                    button.Text = "Reset";
                    button.Click += new EventHandler(btnReset_Click);
                    break;
                default:
                    break;
            }

            return button;
        }
        #endregion //init

        #region buttons' events
        private void btnInit_Click(object sender, EventArgs e)
        {
            string msg = UserMgr.GetInstance().CurrentUser.authority + " " + UserMgr.GetInstance().CurrentUser.name + " ---> clicked Init Button";
            Log.writeLog(msg, ErrorLevel.TRACE, DefLogTab.OPERATION);

            LogicMgr.GetInstance().Init();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (buttonsDefault[ButtonsName.Start])
            {
                if (Log.showMessageBox("Are you sure to start system?", "ALC", MsgBoxButtons.YesNo, MsgBoxIcon.Question) == MsgBoxResult.No) return;
                string msg = UserMgr.GetInstance().CurrentUser.authority + " " + UserMgr.GetInstance().CurrentUser.name + " ---> clicked Start Button and clicked yes";
                Log.writeLog(msg, ErrorLevel.TRACE, DefLogTab.OPERATION);

                LogicMgr.GetInstance().Start();
            }
            else
            {
                if (Log.showMessageBox("Are you sure to stop system?", "ALC", MsgBoxButtons.YesNo, MsgBoxIcon.Question) == MsgBoxResult.No) return;
                string msg = UserMgr.GetInstance().CurrentUser.authority + " " + UserMgr.GetInstance().CurrentUser.name +" ---> clicked Stop Button and clicked yes";
                Log.writeLog(msg, ErrorLevel.TRACE, DefLogTab.OPERATION);

                LogicMgr.GetInstance().Stop();
            }
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            if (buttonsDefault[ButtonsName.Pause])
            {
                if (Log.showMessageBox("Are you sure to pause system?", "ALC", MsgBoxButtons.YesNo, MsgBoxIcon.Question) == MsgBoxResult.No) return;
                string msg = UserMgr.GetInstance().CurrentUser.authority + " " + UserMgr.GetInstance().CurrentUser.name + " ---> clicked Pause Button and clicked yes";
                Log.writeLog(msg, ErrorLevel.TRACE, DefLogTab.OPERATION);

                LogicMgr.GetInstance().Pause();
            }
            else
            {
                if (Log.showMessageBox("Are you sure to resume system?", "ALC", MsgBoxButtons.YesNo, MsgBoxIcon.Question) == MsgBoxResult.No) return;
                string msg = UserMgr.GetInstance().CurrentUser.authority + " " + UserMgr.GetInstance().CurrentUser.name + " ---> clicked Resume Button and clicked yes";
                Log.writeLog(msg, ErrorLevel.TRACE, DefLogTab.OPERATION);

                LogicMgr.GetInstance().Resume();
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            if (Log.showMessageBox("Are you sure to reset system?", "ALC", MsgBoxButtons.YesNo, MsgBoxIcon.Question) == MsgBoxResult.No) return;
            string msg = UserMgr.GetInstance().CurrentUser.authority + " " + UserMgr.GetInstance().CurrentUser.name + " ---> clicked Reset Button and clicked yes";
            Log.writeLog(msg, ErrorLevel.TRACE, DefLogTab.OPERATION);

            LogicMgr.GetInstance().Reset();
        }
        #endregion //buttons' events

        #region get and set buttons' status
        public bool GetButtonInUse(ButtonsName btnName)
        {
            return buttonsInUse[btnName];
        }

        public bool GetButtonEnable(ButtonsName btnName)
        {
            return buttonsEnable[btnName];
        }
        public void SetButtonEnable(ButtonsName btnName, bool enable)
        {
            buttonsEnable[btnName] = enable;
            if (InvokeRequired)
            {
                this.BeginInvoke(new dUpdateButtonStatus(updateButtonEnable), btnName, enable);
                return;
            }
            else
            {
                updateButtonEnable(btnName, enable);
            }
        }

        public bool GetButtonDefault(ButtonsName btnName)
        {
            return buttonsDefault[btnName];
        }
        public void SetButtonDefault(ButtonsName btnName, bool isDefault)
        {
            buttonsDefault[btnName] = isDefault;
            if (InvokeRequired)
            {
                this.BeginInvoke(new dUpdateButtonStatus(updateButtonDefault), btnName, isDefault);
                return;
            }
            else
            {
                updateButtonDefault(btnName, isDefault);
            }
        }
        #endregion //get and set buttons' status

        #region update buttons' UI

        private delegate void dUpdateButtonStatus(ButtonsName btnName, bool enable);

        private void updateButtonEnable(ButtonsName btnName, bool enable)
        {
            if (!homeButtons.Keys.Contains(btnName)) return;
            if (homeButtons[btnName] == null) return;
            homeButtons[btnName].Enabled = enable;
        }

        private void updateButtonDefault(ButtonsName btnName, bool isDefault)
        {
            if (!homeButtons.Keys.Contains(btnName)) return;
            if (homeButtons[btnName] == null) return;
            if (isDefault)
            {
                homeButtons[btnName].Image = buttonsImage[btnName].Item1;
                homeButtons[btnName].Text = buttonsImage[btnName].Item2;
            }
            else
            {
                homeButtons[btnName].Image = buttonsImage[btnName].Item3;
                homeButtons[btnName].Text = buttonsImage[btnName].Item4;
            }
        }
        #endregion //update buttons' UI

        #endregion //Buttons

        #region HeartBeat
        class HeartBeat
        {
            public bool isAlive;
            public PictureBox picture;
        }
        private Dictionary<string, HeartBeat> moduleHeartBeat = new Dictionary<string, HeartBeat>();

        public void LoadHeartBeat(string heartBeatName)
        {
            if (!(moduleHeartBeat.Keys.Contains(heartBeatName) || heartBeatName == null || heartBeatName == string.Empty))
            {
                TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
                PictureBox pictureBox = new PictureBox();
                Label label = new Label();

                // pictureBox
                pictureBox.BackColor = SystemColors.Control;
                pictureBox.Dock = DockStyle.Fill;
                pictureBox.Image = Properties.Resources.gray;
                pictureBox.InitialImage = Properties.Resources.gray;
                pictureBox.Location = new Point(3, 3);
                pictureBox.Name = "picbx_" + heartBeatName;
                pictureBox.Size = new Size(44, 35);
                pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
                pictureBox.TabIndex = 0;
                pictureBox.TabStop = false;

                // label
                label.AutoSize = true;
                label.Dock = DockStyle.Fill;
                label.Font = new Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                label.Location = new Point(3, 44);
                label.Margin = new Padding(3);
                label.Name = "lbl_" + heartBeatName;
                label.TabIndex = 1;
                label.TextAlign = ContentAlignment.MiddleCenter;
                label.Text = heartBeatName;
                label.SizeChanged += label_SizeChanged;
                
                //if (heartBeatName.Length > 5)
                //{
                //    label.Text = heartBeatName.Substring(0, 4);
                //}
                //else
                //{
                //    label.Text = heartBeatName;
                //}

                
                //tablelayout
                tableLayoutPanel.ColumnCount = 1;
                tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
                tableLayoutPanel.Controls.Add(pictureBox, 0, 0);
                tableLayoutPanel.Controls.Add(label, 0, 1);
                tableLayoutPanel.Dock = DockStyle.Fill;
                tableLayoutPanel.Location = new Point(1288, 0);
                tableLayoutPanel.Margin = new Padding(0);
                tableLayoutPanel.Name = "tblyt_" + heartBeatName;
                tableLayoutPanel.RowCount = 2;
                tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
                tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 31F));
                tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 66F));
                tableLayoutPanel.Size = new Size(50, 72);
                tableLayoutPanel.TabIndex = 9;
                tableLayoutPanel.SuspendLayout();

                tPanel_top.ColumnCount++;
                tPanel_top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 50F));
                tPanel_top.Controls.Add(tableLayoutPanel, tPanel_top.ColumnCount - 1, 0);
                moduleHeartBeat.Add(heartBeatName, new HeartBeat() { isAlive = false, picture = pictureBox });
            }


        }

        private const int MIN_LENGTH = 4;
        private void label_SizeChanged(object sender, EventArgs e)
        {
            Label label = (Label)sender;
            float widthSize = label.Width * 1.2F / (Math.Max(label.Text.Length, MIN_LENGTH) + 1);
            float heightSize = label.Height * 0.8F;
            label.Font = new Font("宋体", Math.Min(widthSize, heightSize));
        }

        private delegate void SetModuleAlive(string module, bool isAlive);
        public void UpdateModuleStatus(string module, bool isAlive)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new SetModuleAlive(_setAlive), new object[] { module, isAlive });
                return;
            }
            else
            {
                _setAlive(module, isAlive);
            }
        }
        private void _setAlive(string module, bool isAlive)
        {
            if (moduleHeartBeat.Keys.Contains(module))
            {
                moduleHeartBeat[module].isAlive = isAlive;
                moduleHeartBeat[module].picture.Image = isAlive ? Properties.Resources.green : Properties.Resources.red;
            }
        }

        public bool isAllModuleAlive()
        {
            bool alive = true;

            foreach (var module in moduleHeartBeat)
            {
                if (!module.Value.isAlive)
                {
                    alive = false;
                    break;
                }
            }

            return alive;
        }
        #endregion
        
        public void LoadPluginUserControl(UserControl usrc, int startx, int starty, int length, int width)
        {
            if (usrc != null)
            {
                panel2.Controls.Add(usrc);
                usrc.Enabled = true;
                usrc.Location = new Point(startx, starty);
                usrc.Size = new Size(length, width);
            }
        }       
    }
}
