﻿namespace AlcUtility
{
    public enum ButtonsName
    {
        Init,
        Start,
        Pause,
        Reset,
        
        #region for ButtonClickRequire
        Stop,
        Resume,
        #endregion//for ButtonClickRequire
    }
}
