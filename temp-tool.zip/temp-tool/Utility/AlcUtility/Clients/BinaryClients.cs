﻿using System.Threading.Tasks;
using SuperSocket.Facility.Protocol;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;
using System;
using System.Net;
using LogLib;

namespace AlcUtility
{
    internal class PLCBinaryFilter : FixedSizeReceiveFilter<BinaryRequestInfo>
    {
        public static int FixedSize = 72;
        public PLCBinaryFilter(int msgLen)
            : base(msgLen)
        {
            FixedSize = msgLen;
        }

        protected override BinaryRequestInfo ProcessMatchedRequest(byte[] buffer, int offset, int length, bool toBeCopied)
        {
            byte[] recv = new byte[FixedSize];
            Buffer.BlockCopy(buffer, offset, recv, 0, length);
            return new BinaryRequestInfo("", recv);
        }
    }

    internal class PLCBinaryFilterFactory : IReceiveFilterFactory<BinaryRequestInfo>
    {
        private int _msgLen;
        public PLCBinaryFilterFactory(int msgLen)
        {
            _msgLen = msgLen;
        }
        public IReceiveFilter<BinaryRequestInfo> CreateFilter(IAppServer appServer, IAppSession appSession, IPEndPoint remoteEndPoint)
        {
            return new PLCBinaryFilter(_msgLen);
        }
    }

    internal class PLCBinarySession : AppSession<PLCBinarySession, BinaryRequestInfo>
    {
        private const int Max_Recv_Len = 4096;
        protected override int GetMaxRequestLength()
        {
            return Max_Recv_Len;
        }

        protected override void OnSessionStarted()
        {
            base.OnSessionStarted();
        }

        protected override void HandleUnknownRequest(BinaryRequestInfo requestInfo)
        {
            Log.writeLog(string.Format("{0}", requestInfo.Key), ErrorLevel.DEBUG);
        }

        protected override void HandleException(Exception e)
        {
            base.HandleException(e);
        }

        protected override void OnSessionClosed(CloseReason reason)
        {
            base.OnSessionClosed(reason);
        }
    }

    internal class PLCBinaryServer : AppServer<PLCBinarySession, BinaryRequestInfo>
    {
        public PLCBinaryServer(int msgLen)
            : base(new PLCBinaryFilterFactory(msgLen))
        { }

        protected override void OnSessionClosed(PLCBinarySession session, CloseReason reason)
        {
            base.OnSessionClosed(session, reason);
        }

        protected override void OnStopped()
        {
            base.OnStopped();
        }
    }

    public class BinaryClients
    {
        private PLCBinaryServer _server;
        private int _localPort;
        private PLCBinarySession _session;
        private Action<byte[]> _msgHandle;
        private Action<string> _disconnected;

        private int _msgLen;
        public BinaryClients(int localPort, Action<byte[]> msgHandle, Action<string> disconnected, int FixedMsgLen)
        {
            _localPort = localPort;
            _msgHandle = msgHandle;
            _disconnected = disconnected;
            _msgLen = FixedMsgLen;
        }

        ~BinaryClients()
        {
            if (_server != null)
            {
                if (_server.State == ServerState.Running)
                {
                    foreach (var c in _server.GetAllSessions())
                    {
                        c.Close();
                    }

                    _server.Stop();
                }
            }
        }

        public void close()
        {
            if (_server == null) return;
            _server.Stop();
        }

        public bool Connect(string remoteIP, int remoteport, bool bFirstConnect)
        {
            try
            {
                if (bFirstConnect)
                {
                    int ret = StartServer();
                    if (ret != ErrorCode.EC_OK) return false;
                }
                var remote = new IPEndPoint(IPAddress.Parse(remoteIP), remoteport);
                var client = _server as IActiveConnector;
                var task = client.ActiveConnect(remote);

                var r = task.ContinueWith(t =>
                {
                    System.Diagnostics.Debug.WriteLine("connected...{0}", t.Result.Session.RemoteEndPoint);
                    return t.Result.Result;
                }, TaskContinuationOptions.OnlyOnRanToCompletion);
                return r.Result;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
                return false;
            }
        }

        private int StartServer()
        {
            _server = new PLCBinaryServer(_msgLen);
            //set listen port
            if (!_server.Setup(_localPort))
            {
                Log.writeLog(string.Format("Start super socket server Failed! Bind port {0} error!", _localPort), ErrorLevel.DEBUG);
                return ErrorCode.EC_OK;
            }

            //add events

            //add new client connected event handler
            _server.NewSessionConnected += new SessionHandler<PLCBinarySession>(NewSessionConnected);

            //add request received event handler
            _server.NewRequestReceived += new RequestHandler<PLCBinarySession, BinaryRequestInfo>(RequestReceived);

            //add connecion closed event handler
            _server.SessionClosed += new SessionHandler<PLCBinarySession, CloseReason>(SessionClosed);

            if (!_server.Start())
            {
                Log.writeLog("Start ScanBinaryClient failed!", ErrorLevel.DEBUG);
                return ErrorCode.EC_Error;
            }

            Log.writeLog("Scan Binary Client started !", ErrorLevel.DEBUG);

            return ErrorCode.EC_OK;
        }

        private void NewSessionConnected(PLCBinarySession client)
        {
            _session = client;
            Log.writeLog(string.Format("Client {0} connected!", client.RemoteEndPoint), ErrorLevel.DEBUG);
        }

        private void RequestReceived(PLCBinarySession client, BinaryRequestInfo data)
        {
            try
            {
                _msgHandle(data.Body);
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        private void SessionClosed(PLCBinarySession client, CloseReason reason)
        {
            try
            {
                Log.writeLog(string.Format("Client {0} closed! {1}", client.RemoteEndPoint, reason), ErrorLevel.DEBUG);
                _disconnected(reason.ToString());
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        public bool sendMessage(string LocalModuleType, byte[] msg)
        {
            try
            {
                _session.Send(msg, 0, msg.Length);
                string str = BitConverter.ToString(msg);
                Log.writeLog(string.Format("ALC->{0} : {1}", LocalModuleType, str), ErrorLevel.TRACE, LocalModuleType);
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
                return false;
            }

            return true;
        }
    }
}
