﻿using LogLib;
using System.Configuration;

namespace AlcUtility
{
    public class Configur
    {
        protected string getString(string key, string defaultValue = null)
        {
            try
            {
                return ConfigurationManager.AppSettings[key] ?? defaultValue;
            }
            catch
            {
                Log.writeLog(string.Format("Can not find {0} in the config file.", key), ErrorLevel.DEBUG);
                return defaultValue;
            }
        }

        protected int getInt(string key, int defulatValue = 0)
        {
            try
            {
                return int.Parse(ConfigurationManager.AppSettings[key]);
            }
            catch
            {
                Log.writeLog(string.Format("Can not find {0} in the config file.", key), ErrorLevel.DEBUG);
                return defulatValue;
            }
        }

        protected void addOrUpdate(string key, string value)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            if (getString(key) == null)
                config.AppSettings.Settings.Add(key, value);
            else
                config.AppSettings.Settings[key].Value = value;
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }
    }
}
