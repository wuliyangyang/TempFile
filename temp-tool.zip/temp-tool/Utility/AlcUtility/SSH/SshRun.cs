﻿using Renci.SshNet;
using Renci.SshNet.Common;
using System;
using LogLib;

namespace AlcUtility
{
    public class SshRun
    {
        private string _ip = string.Empty;
        private string _user = string.Empty;
        private string _psw = string.Empty;
        public SshRun(string ip, string username, string password)
        {
            _ip = ip;
            _user = username;
            _psw = password;
        }
        public int RunSsh(string shellScript)
        {
            int ret = -9999;
            try
            {
                KeyboardInteractiveAuthenticationMethod keybAuth = new KeyboardInteractiveAuthenticationMethod(_user);
                keybAuth.AuthenticationPrompt += new EventHandler<AuthenticationPromptEventArgs>(HandleKeyEvent);

                ConnectionInfo conInfo = new ConnectionInfo(_ip, _user, keybAuth);

                using (SshClient ssh = new SshClient(conInfo))
                {
                    ssh.Connect();
                    //ssh.CreateCommand("ls>a123.txt",Encoding.Default);
                    //var r = ssh.RunCommand(@"sh ~/Desktop/test.sh > aaaa.txt");
                    //string strCmd = string.Format("{0} {1}", ConfigureMgr.getInstance().ShellScripte, ConfigureMgr.getInstance().GetSSHName(stepName));
                    System.Diagnostics.Debug.WriteLine(string.Format("SSH command:{0}", shellScript));
                    var r = ssh.RunCommand(shellScript);
                    ret = r.ExitStatus;
                    ssh.Disconnect();
                }
                return ret;
            }
            catch(Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
                return ret;
            }
        }

        private void HandleKeyEvent(object sender, AuthenticationPromptEventArgs e)
        {
            foreach (AuthenticationPrompt prompt in e.Prompts)
            {
                if (prompt.Request.IndexOf("Password:", StringComparison.InvariantCultureIgnoreCase) != -1)
                {
                    prompt.Response = _psw;
                }

                //if (prompt.Request.IndexOf("Yes or no:", StringComparison.InvariantCultureIgnoreCase) != -1)
                //{
                //    prompt.Response = "Yes";
                //}
            }
        }
    }
}
