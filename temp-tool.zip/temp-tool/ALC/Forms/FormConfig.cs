﻿using System.Drawing;
using System.Windows.Forms;
using ALC.Managers;

namespace ALC
{
    public partial class FormConfig : Form
    {
        public FormConfig()
        {
            InitializeComponent();
        }
        
        public void AddTabPage(string name, ControlPosition pos, UserControl ctrl)
        {
            if (ctrl == null) return;

            TabPage tp = new TabPage();
            tp.Name = name;
            tp.Text = name;
            tp.Controls.Add(ctrl);
            ctrl.Location = new Point(pos.startx, pos.starty);
            ctrl.Size = new Size(pos.width, pos.length);
            tabControl1.TabPages.Add(tp);
        }
    }
}
