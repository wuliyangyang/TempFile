﻿namespace AlcUtility
{
    public class ErrorCode
    {
        public static int EC_Error = -1;
        public static int EC_OK = 0;
        public static int EC_XmlNotExist = 1100;        //config.xml not Exist
        public static int EC_XmlFormatErr = 1101;       //config.xml format error

        public static int EC_ClientConnectException = 2001;
    }
}
