﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Threading;
using WeifenLuo.WinFormsUI.Docking;
using ALC.Managers;
using LogLib;
using AlcUtility;

namespace ALC.Forms
{
    public partial class FormMain : CustomForm
    {
        public FormMain()
        {
            InitializeComponent();
            _mainVersion = XmlHelper.GetInstance().Version;
            Title = XmlHelper.GetInstance().AppName + "  V" + _mainVersion + " [platform:" + Application.ProductVersion.ToString() + "]";

            Refresh_Form();

            Shown += new EventHandler(frmMain_Shown);
            backgroudWorker.WorkerSupportsCancellation = true;
            backgroudWorker.WorkerReportsProgress = true;
            backgroudWorker.DoWork += new DoWorkEventHandler(backgroudWorker_DoWork);
            backgroudWorker.ProgressChanged += new ProgressChangedEventHandler(backgroudWorker_ProgressChanged);
            
            dockPanel.Theme = vS2005Theme;
            dockPanel.DocumentStyle = DocumentStyle.DockingSdi;
            frmHome.Show(dockPanel);

            PluginOperateMgr.GetInstance().Setup(ref FormShown);
            LoadPlugins();
            DockContent frmLog = (DockContent)Log.getFormLogWindow();
            frmLog.Show(dockPanel, DockState.DockRightAutoHide);

            band_pages.Add(band_Home.Name, frmHome);
            band_pages.Add(band_Config.Name, frmConfig);
            
            ServerMgr.GetInstance().StartServers();
            Thread.Sleep(100);
        }

        private string _mainVersion;
        private BackgroundWorker backgroudWorker = new BackgroundWorker();
        private Mutex mutStbar = new Mutex();
        private bool m_initFlag = true;
        private bool m_progressing = true;

        private FormHome frmHome = new FormHome();
        private FormConfig frmConfig = new FormConfig();
        List<Form> _controls = new List<Form>();
        private Dictionary<string, Form> band_pages = new Dictionary<string, Form>();

        private void frmMain_Load(object sender, EventArgs e)
        {
            SysTimer1.Enabled = true;
            Log.writeLog(string.Format("*************Program Open, ALC Version {0}, Platform Version {1}***************", _mainVersion, Application.ProductVersion), ErrorLevel.DEBUG, DefLogTab.All);
        }

        private void frmMain_Shown(object sender, EventArgs e)
        {
            backgroudWorker.RunWorkerAsync();
        }

        public void LoadPlugins()
        {
            PluginMgr.GetInstance().LoadAllPlugins();
            foreach (var p in PluginMgr.GetInstance().Plugins)
            {
                LoadPluginForm(p.ModuleForm, p.ModuleType, p.ModuleIcon);
                frmHome.LoadHeartBeat(p.ModuleType);
                frmHome.LoadPluginUserControl(p.MainControl, p.mainpos.startx, p.mainpos.starty, p.mainpos.length, p.mainpos.width);
                frmConfig.AddTabPage(p.ModuleType, p.configpos, p.ConfigControl);
                Log.addABoxToLogWindow(p.ModuleType);
                p.load();
            }
        }

        public void LoadPluginForm(Form frm, string frmName, string iconIndex)
        {
            try
            {
                if ((frm != null) && (!band_pages.Keys.Contains(frm.Name)))
                {
                    Guifreaks.Navisuite.NaviBand band_frm = new Guifreaks.Navisuite.NaviBand(this.components);
                    band_frm.SuspendLayout();

                    band_frm.ClientArea.LayoutStyle = Guifreaks.Navisuite.NaviLayoutStyle.StyleFromOwner;
                    band_frm.ClientArea.Location = new Point(0, 0);
                    band_frm.ClientArea.Margin = new Padding(2);
                    band_frm.ClientArea.Name = "ClientArea";
                    band_frm.ClientArea.Size = new Size(134, 337);
                    band_frm.ClientArea.TabIndex = 0;
                    band_frm.LayoutStyle = Guifreaks.Navisuite.NaviLayoutStyle.StyleFromOwner;
                    band_frm.Location = new Point(1, 27);
                    band_frm.Margin = new Padding(2);
                    band_frm.Name = frmName;
                    band_frm.Text = frmName;
                    band_frm.Size = new Size(134, 337);
                    band_frm.TabIndex = 19;

                    int index;
                    if (!int.TryParse(iconIndex, out index))
                    {
                        index = 3;
                    }
                    band_frm.LargeImageIndex = index;
                    band_frm.SmallImageIndex = index;

                    this.funcBar.Controls.Add(band_frm);
                    frm.FormBorderStyle = FormBorderStyle.None;
                    this.band_pages.Add(band_frm.Name, (Form)frm);
                }
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        private void backgroudWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 1; i <= 100; i++)
            {
                if (!m_initFlag)
                {
                    backgroudWorker.ReportProgress(50);
                    m_progressing = false;
                    backgroudWorker.CancelAsync();
                    break;
                }
                else
                {
                    backgroudWorker.ReportProgress(i);
                    Thread.Sleep(10);
                }
            }
        }
        private void backgroudWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.BeginInvoke(new EventHandler(delegate
            {
                this.stBar_Progress.Value = e.ProgressPercentage;
                if (this.stBar_Progress.Value == 100)
                {
                    Thread.Sleep(500);
                    this.stBar_Progress.ForeColor = Color.Green;
                    this.stBar_Progress.AutoToolTip = true;
                    this.stBar_Progress.ToolTipText = "OK";
                }
                else if (!m_progressing)
                {
                    Thread.Sleep(100);
                    this.stBar_Progress.ForeColor = Color.Red;
                    this.stBar_Progress.AutoToolTip = true;
                    this.stBar_Progress.ToolTipText = "Fail";
                    backgroudWorker.Dispose();
                }
            }));
        }

        public void frmShow(Form form)
        {
            form.TopLevel = false;
            if (!_controls.Contains(form))
            {
                this.panUI.Controls.Add(form);
                form.Disposed += new EventHandler(control_Disposed);
                form.Dock = DockStyle.Fill;
                this._controls.Add(form);
            }
            form.Show();
            form.BringToFront();
            Application.DoEvents();
        }

        void control_Disposed(object sender, EventArgs e)
        {
            var ctrl = sender as Form;
            if (ctrl != null)
            {
                _controls.Remove(ctrl);
                this.panUI.Controls.Remove(ctrl);
            }
        }

        private void Refresh_Form()
        {
            Log.getFormLogWindow().Show();
            Log.getFormLogWindow().Hide();
        }

        private void frmHide()
        {
            foreach (string frmName in band_pages.Keys)
                band_pages[frmName].Hide();
        }

        public Action<string> FormShown;
        private void funcBar_ActiveBandChanged(object sender, EventArgs e)
        {
            Application.DoEvents();
            for (int i = 0; i < this.funcBar.Bands.Count; i++)
            {
                if (this.funcBar.ActiveBand == this.funcBar.Bands[i])
                {
                    if (band_pages.Keys.Contains(this.funcBar.Bands[i].Name))
                    {
                        if (this.funcBar.Bands[i].Name == this.band_Home.Name)
                        {
                            frmHide();
                            this.dockPanel.BringToFront();
                            band_pages[this.funcBar.Bands[i].Name].Show();
                            //this.dockPanel.Show();
                        }
                        else
                        {
                            frmHide();
                            frmShow(band_pages[this.funcBar.Bands[i].Name]);
                        }
                        FormShown?.Invoke(funcBar.Bands[i].Name);
                    }
                }
            }
        }

        private void frmMain_SizeChanged(object sender, EventArgs e)
        {
            //this.tableLayoutPanel1.Width = this.panData.Width - logWidth;
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(!LogicMgr.GetInstance().IsCloseable(out string details))
            {
                e.Cancel = true;
                Log.showMessageBox(details, "ALC", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }

            if (Log.showMessageBox("Are You Sure to Quit ALC Program?", "ALC", MsgBoxButtons.YesNo, MsgBoxIcon.Question) == MsgBoxResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                string msg = string.Format("Operator: {0} ---> Closed ALC software!", UserMgr.GetInstance().CurrentUser.name);
                Log.writeLog(msg, ErrorLevel.TRACE, null);
                PluginMgr.GetInstance().Dispose();
                e.Cancel = false;
                this.SysTimer1.Enabled = false;
            }
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                Thread.Sleep(300);
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        private void SysTimer1_Tick(object sender, EventArgs e)
        {
            this.lblSysTime.Text = DateTime.Now.ToString();
            if (UserMgr.GetInstance().CurrentUser.authority.ToUpper() == UserAuthority.ENGINEER.ToString().ToUpper())
            {
                this.stBar_Status.Text = UserAuthority.ENGINEER.ToString();
                if (this.stBar_Status.BackColor == Color.Yellow)
                {
                    this.stBar_Status.BackColor = Color.White;
                }
                else
                {
                    this.stBar_Status.BackColor = Color.Yellow;
                }
            }
            else if (UserMgr.GetInstance().CurrentUser.authority.ToUpper() == UserAuthority.ADMINISTRATOR.ToString().ToUpper())
            {
                this.stBar_Status.Text = UserAuthority.ADMINISTRATOR.ToString();
                if (this.stBar_Status.BackColor == Color.BlueViolet)
                {
                    this.stBar_Status.BackColor = Color.White;
                }
                else
                {
                    this.stBar_Status.BackColor = Color.BlueViolet;
                }
            }
            else
            {
                this.stBar_Status.Text = UserAuthority.OPERATOR.ToString();
                this.stBar_Status.BackColor = SystemColors.Control;
            }
        }

        private void stBar_Status_Click(object sender, EventArgs e)
        {
            Form frmlogin = new FormLogIn();
            frmlogin.ShowDialog();
        }

        private void band_Home_Click(object sender, EventArgs e)
        {

        }

        private void band_Config_Click(object sender, EventArgs e)
        {

        }
    }
}
