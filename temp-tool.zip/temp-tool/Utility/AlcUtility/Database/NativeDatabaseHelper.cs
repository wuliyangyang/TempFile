﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using LogLib;

namespace AlcUtility
{
    public class NativeDatabaseHelper:IDisposable
    {
        private SqlConnection _conn = null;
        private SqlTransaction _trans = null;

        //public NativeDatabaseHelper()
        //{
        //    string conn_str = ConfigurationManager.ConnectionStrings["nativeDB"].ConnectionString;
        //    _conn = new SqlConnection(conn_str);
        //    _conn.Open();
        //}

        public NativeDatabaseHelper(string conn_str)
        {           
            _conn = new SqlConnection(conn_str);
            _conn.Open();
        }

        public void beginTrans()
        {
            _trans = _conn.BeginTransaction();
        }

        public void commitTrans()
        {
            _trans.Commit();
        }

        public void rollBack()
        {
            _trans.Rollback();
        }

        public DataTable ExecuteDataTable(string sql, Dictionary<string, object> arges)
        {
            using (SqlCommand cmd = _conn.CreateCommand())
            {
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                cmd.Transaction = _trans;
                foreach (var item in arges)
                {
                    cmd.Parameters.AddWithValue(item.Key, item.Value);
                }
                DataTable dataTable = new DataTable();
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    adapter.Fill(dataTable);
                }
                return dataTable;
            }            
        }

        public void ExecuteAction(string sql, Dictionary<string, object> arges,Action<SqlDataReader> Ac)
        {
            using (SqlCommand cmd = _conn.CreateCommand())
            {
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                cmd.Transaction = _trans;
                foreach (var item in arges)
                {
                    cmd.Parameters.AddWithValue(item.Key, item.Value);
                }
                using (SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.SequentialAccess))
                {
                    while (reader.Read())
                    {
                        Ac(reader);
                    }
                }
            }
        }

        public int executeNoResult(string sql, Dictionary<string, object> arges)
        {
            using (SqlCommand cmd = _conn.CreateCommand())
            {
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;
                cmd.Transaction = _trans;
                foreach (var item in arges)
                {
                    cmd.Parameters.AddWithValue(item.Key, item.Value);
                }
               int effect_rt =  cmd.ExecuteNonQuery();
               return effect_rt;
            }
        }        

        public long executeProcWithIntValue(string procName, Dictionary<string, object> arges, string retArges)
        {
            using (SqlCommand cmd = _conn.CreateCommand())
            {

                cmd.CommandText = procName;
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (var item in arges)
                {
                    cmd.Parameters.AddWithValue(item.Key, item.Value);
                }
                cmd.Transaction = _trans;
                cmd.Parameters.Add(retArges, SqlDbType.BigInt).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                return Convert.ToInt64(cmd.Parameters[retArges].Value);
            }
        }

        public DataTable ExecProcedure(string procName, SqlParameter[] commandParameters)
        {
            using (SqlCommand cmd = _conn.CreateCommand())
            {

                cmd.CommandText = procName;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                cmd.Parameters.AddRange(commandParameters);
                DataTable dataTable = new DataTable();
                try
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        //DataSet da=new DataSet();
                        //adapter.Fill(da);
                        //return da.Tables[0];
                        adapter.Fill(dataTable);
                    }
                    return dataTable;
                }
                catch (Exception ex)
                {
                    Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
                    return dataTable;
                }
            }
        }

        public void Dispose()
        {
            if (_trans!= null)
            {
                try
                {
                    _trans.Dispose();
                }
                catch (Exception ex)
                {
                    Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
                }                
                _trans = null;
            }
            if (_conn != null)
            {
                _conn.Close();
                _conn.Dispose();
                _conn = null;
            }
        }
    }
}
