﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace LogLib.Forms
{
    public partial class FormLogWindow : DockContent
    {
        private static FormLogWindow _formLogWindown = new FormLogWindow();

        public static FormLogWindow getInstance()
        {
            return _formLogWindown;
        }

        private FormLogWindow()
        {
            InitializeComponent();
            this.CloseButtonVisible = false;
            init();
        }

        private const int MAX_LINE = 1000;
        private readonly List<string> DEFAULT_LOG_TABS = new List<string>
        {
            DefLogTab.All,
            DefLogTab.ERROR,
            DefLogTab.OPERATION
        };
        private Dictionary<string, RichTextBox> logTextBoxs = new Dictionary<string, RichTextBox>();

        private void init()
        {
            addDefaultLogBoxs();
        }

        private void addDefaultLogBoxs()
        {
            foreach (string title in DEFAULT_LOG_TABS)
            {
                addALogTab(title);
            }
        }

        public void addALogTab(string title)
        {
            if (logTextBoxs.ContainsKey(title))
                return;

            RichTextBox textBox = new RichTextBox();
            textBox.Dock = DockStyle.Fill;
            textBox.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            textBox.Name = "rtBox_" + title;
            textBox.ReadOnly = true;
            textBox.Text = "";
            textBox.MouseDoubleClick += new MouseEventHandler(this.textBox_MouseDoubleClick);

            TabPage tabPage = new TabPage();
            tabPage.Controls.Add(textBox);
            tabPage.Margin = new Padding(4, 7, 4, 7);
            tabPage.Name = "tabPg_" + title;
            tabPage.Padding = new Padding(0, 0, 0, 0);
            tabPage.Text = title;
            tabPage.UseVisualStyleBackColor = true;

            this.tabCtrl.Controls.Add(tabPage);

            logTextBoxs.Add(title, textBox);
        }

        private object writeLogLock = new object();
        private int intervalLimit = 1;
        private DateTime lastWriteTime = DateTime.Now;
        public void writeLog(string title, string msg, int errorLevel)
        {
            Task.Run(() =>
            {
                lock (writeLogLock)
                {
                    int ms = (int)(DateTime.Now - lastWriteTime).TotalMilliseconds;
                    if (ms < intervalLimit)
                    {
                        Thread.Sleep(intervalLimit - ms);
                    }
                    Invoke(new EventHandler(delegate
                    {
                        int currentLine = 0;
                        string strTime = "[" + DateTime.Now.ToString("HH:mm:ss") + "] ";

                        var logAll = logTextBoxs[DefLogTab.All];
                        switch (errorLevel)
                        {
                            case ErrorLevel.DEBUG:
                                logAll.SelectionColor = Color.Black;
                                break;
                            case ErrorLevel.TRACE:
                                logAll.SelectionColor = Color.Black;
                                break;
                            case ErrorLevel.WARN:
                                logAll.SelectionColor = Color.Violet;
                                break;
                            case ErrorLevel.ERROR:
                            case ErrorLevel.FATAL:
                                logAll.SelectionColor = Color.Red;
                                var logError = logTextBoxs[DefLogTab.ERROR];
                                currentLine = logError.Lines.Length;
                                if (currentLine > MAX_LINE)
                                    logError.Clear();
                                logError.AppendText(strTime + " " + msg + "\r\n");
                                logError.ScrollToCaret();
                                break;
                        }
                        currentLine = logAll.Lines.Length;
                        if (currentLine > MAX_LINE)
                            logAll.Clear();
                        logAll.AppendText(strTime + " " + msg + "\r\n");
                        logAll.ScrollToCaret();

                        if (title.CompareTo(DefLogTab.All) == 0)
                            return;
                        if (!logTextBoxs.ContainsKey(title))
                            return;
                        var logBox = logTextBoxs[title];
                        currentLine = logBox.Lines.Length;
                        if (currentLine > MAX_LINE)
                            logBox.Clear();
                        logBox.AppendText(strTime + " " + msg + "\r\n");
                        logBox.ScrollToCaret();
                    }));
                    lastWriteTime = DateTime.Now;
                }
            });
        }

        private void textBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //if (e.Button != MouseButtons.Right) return;
            ((RichTextBox)this.tabCtrl.SelectedTab.Controls[0]).Clear();
        }

        private void FormLogWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }
    }
}
