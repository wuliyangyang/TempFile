﻿using ALC.Managers;
using AlcUtility;
using LogLib;
using System;
using System.Windows.Forms;

namespace ALC.Forms
{
    public partial class FormChangePassword : CustomForm
    {
        private string currentAuthority = UserAuthority.OPERATOR.ToString();

        public FormChangePassword()
        {
            InitializeComponent();

            //init cbb_Authority
            var userAuthorityList = XmlHelper.GetInstance().UserAuthorityList;
            foreach (string authority in userAuthorityList)
            {
                if (authority.ToUpper() != UserAuthority.OPERATOR.ToString().ToUpper())
                    cbb_Authority.Items.Add(authority);
            }
            if (cbb_Authority.Items.Count > 0)
                cbb_Authority.SelectedItem = cbb_Authority.Items[0];
        }
        
        private void frmLogIn_Activated(object sender, EventArgs e)
        {
            txt_OldPassword.Focus();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            string authority = cbb_Authority.Text;
            string password = txt_OldPassword.Text;

            if(!UserMgr.GetInstance().CheckPasswordCorrect(authority, password))
            {
                Log.showMessageBox("Old password is incorrect!", "ChangePassword", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }

            if(txt_NewPassword.Text != txt_RepeatNewPassword.Text)
            {
                Log.showMessageBox("The two new passwords entered don't match!", "ChangePassword", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }

            password = txt_NewPassword.Text;
            BinaryFileHelper.getInstence().SavePassword(authority, password);
            Log.showMessageBox("Password changed successfully!", "ChangePassword", MsgBoxButtons.OK, MsgBoxIcon.Information);
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
