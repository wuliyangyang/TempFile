﻿using System;
using System.Collections.Generic;
using LogLib;
using System.IO;
using System.Xml.Linq;
using AlcUtility;
using System.Linq;

namespace ALC.Managers
{
    public class XmlHelper
    {
        private static XmlHelper _instance = new XmlHelper();
        public static XmlHelper GetInstance()
        {
            return _instance;
        }

        XElement _xml;
        private XmlHelper()
        {
            string configPath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "config.xml";
            if (!File.Exists(configPath))
            {
                Log.showMessageBox("Can not open config.xml file", "Load XML Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                Environment.Exit(ErrorCode.EC_XmlNotExist);
            }
            else
            {
                try
                {
                    _xml = XElement.Load(configPath);
                }
                catch (Exception ex)
                {
                    Log.showMessageBox("Can not Load config.xml file:\r\n" + ex.Message, "Load XML Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                    Environment.Exit(ErrorCode.EC_XmlFormatErr);
                }
            }
        }

        public string AppName
        {
            get
            {
                try
                {
                    return _xml.Attribute("name").Value;
                }
                catch
                {
                    return null;
                }
            }
        }

        public string Version
        {
            get
            {
                try
                {
                    return _xml.Attribute("version").Value;
                }
                catch
                {
                    return null;
                }
            }
        }

        public List<string> UserAuthorityList
        {
            get
            {
                string userAuthoritiesStr = string.Empty;
                List<string> userAuthorityList = new List<string>();
                if (_xml != null)
                {
                    if (_xml.Element("UserAuthority") != null)
                    {
                        userAuthoritiesStr = _xml.Element("UserAuthority").Value;
                        foreach(string userAuthority in userAuthoritiesStr.Split('\n').ToList())
                        {
                            if (!string.IsNullOrWhiteSpace(userAuthority))
                                userAuthorityList.Add(userAuthority.Trim());
                        }
                    }
                }
                return userAuthorityList;
            }
        }

        public List<Plugin> PluginList
        {
            get
            {
                try
                {
                    List<Plugin> pluginList = new List<Plugin>();

                    var plugins_xml = _xml.Element("Plugins");

                    foreach (var plugin_xml in plugins_xml.Descendants("Plugin"))
                    {
                        Plugin plugin = new Plugin()
                        {
                            //ModuleName = plugin_xml.Attribute("moduletype").Value,
                            DllName = plugin_xml.Element("DllName").Value,
                            ModuleIcon = plugin_xml.Element("Icon").Value,
                            version = plugin_xml.Element("Version").Value,
                            checkVersion = plugin_xml.Element("Version").Attribute("check").Value.ToLower() == "true",
                            initRanking = int.Parse(plugin_xml.Element("InitRanking").Value),
                            startRanking = int.Parse(plugin_xml.Element("StartRanking").Value),
                            stopRanking = int.Parse(plugin_xml.Element("StopRanking").Value),
                            resetRanking = int.Parse(plugin_xml.Element("ResetRanking").Value),
                            mainpos = new ControlPosition()
                            {
                                startx = int.Parse(plugin_xml.Element("UserControl").Attribute("startx").Value),
                                starty = int.Parse(plugin_xml.Element("UserControl").Attribute("starty").Value),
                                length = int.Parse(plugin_xml.Element("UserControl").Attribute("length").Value),
                                width = int.Parse(plugin_xml.Element("UserControl").Attribute("width").Value),
                            },
                            configpos = new ControlPosition
                            {
                                startx = int.Parse(plugin_xml.Element("ConfigView").Attribute("startx").Value),
                                starty = int.Parse(plugin_xml.Element("ConfigView").Attribute("starty").Value),
                                length = int.Parse(plugin_xml.Element("ConfigView").Attribute("length").Value),
                                width = int.Parse(plugin_xml.Element("ConfigView").Attribute("width").Value),
                            },
                        };
                        pluginList.Add(plugin);
                    }

                    return pluginList;
                }
                catch (Exception ex)
                {
                    Log.showMessageBox("Load config.xml file Failed:\r\n" + ex.Message + "\r\n" + ex.StackTrace, "Load XML Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                    Environment.Exit(-1);
                    return null;
                }
            }
        }

        public int StringServerPort
        {
            get
            {
                int portInt = 8899;
                string portStr = string.Empty;
                if (_xml != null)
                {
                    if (_xml.Element("Servers") != null)
                    {
                        if (_xml.Element("Servers").Element("StringServer") != null)
                        {
                            portStr = _xml.Element("Servers").Element("StringServer").Attribute("port").Value;
                            if (!int.TryParse(portStr, out portInt))
                            {
                                portInt = 8899;
                            }
                        }
                    }
                }
                return portInt;
            }
        }

        public int CRStringServerPort
        {
            get
            {
                int portInt = 8901;
                string portStr = string.Empty;
                if (_xml != null)
                {
                    if (_xml.Element("Servers") != null)
                    {
                        if (_xml.Element("Servers").Element("CRStringServer") != null)
                        {
                            portStr = _xml.Element("Servers").Element("CRStringServer").Attribute("port").Value;
                            if (!int.TryParse(portStr, out portInt))
                            {
                                portInt = 8901;
                            }
                        }
                    }
                }
                return portInt;
            }
        }

        public int BinaryServerPort
        {
            get
            {
                int portInt = 8900;
                string portStr = string.Empty;
                if (_xml != null)
                {
                    if (_xml.Element("Servers") != null)
                    {
                        if (_xml.Element("Servers").Element("BinaryServer") != null)
                        {
                            portStr = _xml.Element("Servers").Element("BinaryServer").Attribute("port").Value;
                            if (!int.TryParse(portStr, out portInt))
                            {
                                portInt = 8900;
                            }
                        }
                    }
                }
                return portInt;
            }
        }

        public bool ShowInitButton
        {
            get
            {
                return true;
                //if (_xml != null)
                //{
                //    if (_xml.Element("Buttons") != null)
                //    {
                //        if (_xml.Element("Buttons").Element("Init") != null)
                //        {
                //            if (_xml.Element("Buttons").Element("Init").Attribute("show").Value.ToString().ToLower() == "true")
                //            {
                //                return true;
                //            }
                //        }
                //    }
                //}
                //return false;
            }
        }

        public bool ShowStartButton
        {
            get
            {
                return true;
                //if (_xml != null)
                //{
                //    if (_xml.Element("Buttons") != null)
                //    {
                //        if (_xml.Element("Buttons").Element("Start") != null)
                //        {
                //            if (_xml.Element("Buttons").Element("Start").Attribute("show").Value.ToString().ToLower() == "true")
                //            {
                //                return true;
                //            }
                //        }
                //    }
                //}
                //return false;
            }
        }

        public bool ShowPauseButton
        {
            get
            {
                if (_xml != null)
                {
                    if (_xml.Element("Buttons") != null)
                    {
                        if (_xml.Element("Buttons").Element("Pause") != null)
                        {
                            if (_xml.Element("Buttons").Element("Pause").Attribute("show").Value.ToString().ToLower() == "true")
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
        }

        public bool ShowResetButton
        {
            get
            {
                if (_xml != null)
                {
                    if (_xml.Element("Buttons") != null)
                    {
                        if (_xml.Element("Buttons").Element("Reset") != null)
                        {
                            if (_xml.Element("Buttons").Element("Reset").Attribute("show").Value.ToString().ToLower() == "true")
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
        }
    }
}