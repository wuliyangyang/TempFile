﻿using System.Collections.Generic;
using System.Collections.Concurrent;
using AlcUtility;

namespace NetAndEvent.EventDispatcher
{
    public class EventServer
    {
        private ConcurrentDictionary<string,List<EventClient>> _client = new ConcurrentDictionary<string,List<EventClient>>();

        static private EventServer _instance = new EventServer();

        static public EventServer GetInstance()
        {
            return _instance;
        }

        private EventServer()
        { }

        public void Register(List<string> msgs, EventClient client)
        {
            foreach(var m in msgs)
            {
                _client.AddOrUpdate(m, new List<EventClient>(){client},(key, oldV) => {
                        oldV.Add(client);
                        return oldV;
                    });
            }
        }

        public void Exit(List<string> msgs, EventClient client)
        {
            foreach(var m in msgs)
            {
                if(_client.ContainsKey(m))
                {
                    _client[m].Remove(client);
                }
            }
        }

        public void Broadcast(string moduler, ReceivedData data)
        {
            List<EventClient> clients;
            _client.TryGetValue(moduler, out clients);
            if (clients != null)
            {
                foreach (var c in clients)
                {
                    c.MsgHandler(data);
                }
            }
        }
    }
}
