﻿using NetAndEvent.Utility;
using NetAndEvent.EventDispatcher;
using SuperSocket.Facility.Protocol;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;
using System;
using System.Collections.Concurrent;
using System.Net;
using LogLib;
using AlcUtility;

namespace NetAndEvent.SocketServer
{
    public class PLCBinaryFilter : FixedSizeReceiveFilter<BinaryRequestInfo>
    {
        public static readonly int FixedSize = 40 + Analyzer.MESSAGE_LENGTH;
        public PLCBinaryFilter()
            : base(FixedSize)
        { }

        protected override BinaryRequestInfo ProcessMatchedRequest(byte[] buffer, int offset, int length, bool toBeCopied)
        {
            byte[] recv = new byte[FixedSize];
            Buffer.BlockCopy(buffer, offset, recv, 0, length);
            return new BinaryRequestInfo("", recv);
        }
    }

    public class PLCBinaryFilterFactory : IReceiveFilterFactory<BinaryRequestInfo>
    {
        public IReceiveFilter<BinaryRequestInfo> CreateFilter(IAppServer appServer, IAppSession appSession, IPEndPoint remoteEndPoint)
        {
            return new PLCBinaryFilter();
        }
    }

    public class PLCBinarySession : AppSession<PLCBinarySession, BinaryRequestInfo>
    {
        private const int Max_Recv_Len = 1024;
        protected override int GetMaxRequestLength()
        {
            return Max_Recv_Len;
        }

        protected override void OnSessionStarted()
        {
            base.OnSessionStarted();
        }

        protected override void HandleUnknownRequest(BinaryRequestInfo requestInfo)
        {
            Log.writeLog(string.Format("{0}", requestInfo.Key), ErrorLevel.DEBUG);
        }

        protected override void HandleException(Exception e)
        {
            base.HandleException(e);
        }

        protected override void OnSessionClosed(CloseReason reason)
        {
            base.OnSessionClosed(reason);
        }
    }

    public class PLCBinaryServer : AppServer<PLCBinarySession, BinaryRequestInfo>
    {
        public PLCBinaryServer()
            : base(new PLCBinaryFilterFactory())
        { }

        protected override void OnSessionClosed(PLCBinarySession session, CloseReason reason)
        {
            base.OnSessionClosed(session, reason);
        }

        protected override void OnStopped()
        {
            base.OnStopped();
        }
    }

    public class BinaryServer
    {
        private PLCBinaryServer _server;
        private int _localPort;
        private ConcurrentDictionary<string, PLCBinarySession> _sessions = new ConcurrentDictionary<string, PLCBinarySession>();
        private ConcurrentDictionary<PLCBinarySession, Tuple<string, string>> _clients = new ConcurrentDictionary<PLCBinarySession, Tuple<string, string>>();

        public BinaryServer(int localPort)
        {
            _localPort = localPort;
        }

        ~BinaryServer()
        {
            if (_server != null)
            {
                if (_server.State == ServerState.Running)
                {
                    foreach (var c in _server.GetAllSessions())
                    {
                        c.Close();
                    }

                    _server.Stop();
                }
            }
        }

        public void close()
        {
            if (_server == null) return;
            _server.Stop();
        }

        public int StartServer()
        {
            _server = new PLCBinaryServer();
            //set listen port
            if (!_server.Setup(_localPort))
            {
                Log.writeLog(string.Format("Start super socket server Failed! Bind port {0} error!", _localPort), ErrorLevel.DEBUG);
                return ErrorCode.EC_OK;
            }

            //add events

            //add new client connected event handler
            _server.NewSessionConnected += new SessionHandler<PLCBinarySession>(NewSessionConnected);

            //add request received event handler
            _server.NewRequestReceived += new RequestHandler<PLCBinarySession, BinaryRequestInfo>(RequestReceived);

            //add connecion closed event handler
            _server.SessionClosed += new SessionHandler<PLCBinarySession, CloseReason>(SessionClosed);

            if (!_server.Start())
            {
                Log.writeLog("Start ScanBinaryClient failed!", ErrorLevel.DEBUG);
                return ErrorCode.EC_Error;
            }

            Log.writeLog("Scan Binary Client started !", ErrorLevel.DEBUG);

            return ErrorCode.EC_OK;
        }

        private void NewSessionConnected(PLCBinarySession client)
        {
            Log.writeLog(string.Format("Client {0} connected!", client.RemoteEndPoint), ErrorLevel.DEBUG);
        }

        private void RequestReceived(PLCBinarySession client, BinaryRequestInfo data)
        {
            try
            {
                Log.writeLog(string.Format("Received from {0}, Length: {1}, {2}", client.RemoteEndPoint, data.Body.Length, BitConverter.ToSingle(data.Body, 0)), ErrorLevel.DEBUG);
                BinaryData recv = BinaryAnalyzer.Analyze(data.Body);
                if (recv != null)
                {
                    recv.strMessage = recv.strMessage.Replace("\0", "");
                    recv.strMessage = recv.strMessage.Trim();
                    if (recv.commandId == CommonCommands.RegisterBinary)
                    {
                        _sessions.AddOrUpdate(recv.strMessage + (int)recv.param1, client, (key, oldV) => { return client; });
                        _clients.AddOrUpdate(client, new Tuple<string, string>(recv.strMessage, recv.strMessage + (int)recv.param1), (key, oldV) => { return new Tuple<string, string>(recv.strMessage, recv.strMessage + (int)recv.param1); });
                    }

                    ReceivedData rd = new ReceivedData()
                    {
                        moduleType = _clients[client].Item1,
                        moduleId = _clients[client].Item2,
                        ip = string.Format("{0}", client.RemoteEndPoint.Address),
                        port = client.RemoteEndPoint.Port,
                        binaryData = recv
                    };
                    EventServer.GetInstance().Broadcast(rd.moduleType, rd);
                    Log.writeLog(string.Format("{0}-->ALC : {1} {2},{3},{4},{5},{6} {7} {8}; channel: {9}, type: {10}", rd.moduleId, recv.commandId, recv.param1, recv.param2, recv.param3, recv.param4, recv.param5, recv.errorcode, recv.strMessage, recv.channelId, recv.msgType), ErrorLevel.DEBUG, rd.moduleType);
                }
                else
                {
                    Log.writeLog("Received PLC data NULL!", ErrorLevel.DEBUG);
                }
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        private void SessionClosed(PLCBinarySession client, CloseReason reason)
        {
            try
            {
                Log.writeLog(string.Format("Client {0} closed! {1}", client.RemoteEndPoint, reason), ErrorLevel.DEBUG);
                Tuple<string, string> closingClient;
                if (_clients.TryGetValue(client, out closingClient))
                {
                    if (reason != CloseReason.ServerClosing)
                    {
                        ReceivedData rd = new ReceivedData()
                        {
                            moduleType = closingClient.Item1,
                            moduleId = closingClient.Item2,
                            ip = string.Empty,
                            port = 0,
                            binaryData = new BinaryData()
                            {
                                commandId = CommonCommands.DisconnectedBinary,
                                msgType = MessageType.ReqBinary,
                                errorcode = ErrorCode.EC_ClientConnectException,
                                strMessage = "client connect exception"
                            }
                        };
                        EventServer.GetInstance().Broadcast(rd.moduleType, rd);
                        Log.writeLog(string.Format("{0} connection closed! Close reason : {1}", rd.moduleId, reason.ToString()), ErrorLevel.DEBUG, rd.moduleType);
                    }

                    PLCBinarySession removedSession;
                    _sessions.TryRemove(closingClient.Item2, out removedSession);
                    _clients.TryRemove(removedSession, out closingClient);
                }
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        public int sendMessage(string moduleId, BinaryData rsp)
        {
            try
            {
                PLCBinarySession client;
                if (_sessions.TryGetValue(moduleId, out client))
                {
                    byte[] sendbuf = BinaryAnalyzer.BinaryDataToByte(rsp);
                    client.Send(sendbuf, 0, sendbuf.Length);
                    Tuple<string, string> clientInfo;
                    _clients.TryGetValue(client, out clientInfo);
                    string moduleType = clientInfo?.Item1;
                    Log.writeLog(string.Format("ALC-->{0}: {1} {2},{3},{4},{5},{6} {7} {8}; channel: {9}, type: {10}", moduleId, rsp.commandId, rsp.param1, rsp.param2, rsp.param3, rsp.param4, rsp.param5, rsp.errorcode, rsp.strMessage, rsp.channelId, rsp.msgType), ErrorLevel.DEBUG, moduleType);
                }
                else
                {
                    Log.writeLog(string.Format("Error! BinaryServer not find the client with module id is {0}", moduleId), ErrorLevel.DEBUG);
                }
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
                return ErrorCode.EC_Error;
            }

            return ErrorCode.EC_OK;
        }
    }
}
