﻿using LogLib;
using AlcUtility;
using System;
using System.Collections.Generic;

namespace NetAndEvent.EventDispatcher
{
    public delegate void HandlerMessage(ReceivedData data);

    public class EventClient
    {
        public HandlerMessage DealReceivedData { set; get; }
        public string guid { get; private set; }
        private List<string> _msgs;

        public EventClient(List<string> msgs)
        {
            guid = Guid.NewGuid().ToString();
            _msgs = msgs;
            EventServer.GetInstance().Register(msgs, this);
        }


        ~EventClient()
        {
            EventServer.GetInstance().Exit(_msgs, this);
        }

        private ReceivedData ReceivedDataCopy(ReceivedData data)
        {
            if (data != null)
            {
                ReceivedData newData = new ReceivedData();
                newData.moduleType = data.moduleType;
                newData.moduleId = data.moduleId;
                newData.ip = data.ip;
                newData.port = data.port;
                if (data.strData != null)
                {
                    newData.strData = new JsonData()
                    {
                        msgChannel = data.strData.msgChannel,
                        msgParam = data.strData.msgParam,
                        msgType = data.strData.msgType,
                        msgName = data.strData.msgName,
                        errMsg = data.strData.errMsg,
                        msgResult = data.strData.msgResult,
                    };
                }
                if (data.binaryData != null)
                {
                    newData.binaryData = new BinaryData()
                    {
                        channelId = data.binaryData.channelId,
                        commandId = data.binaryData.commandId,
                        msgType = data.binaryData.msgType,
                        param1 = data.binaryData.param1,
                        param2 = data.binaryData.param2,
                        param3 = data.binaryData.param3,
                        param4 = data.binaryData.param4,
                        param5 = data.binaryData.param5,
                        errorcode = data.binaryData.errorcode,
                        strMessage = data.binaryData.strMessage
                    };
                }
                return newData;
            }
            else
                return null;
        }

        public void MsgHandler(ReceivedData data)
        {
            if (DealReceivedData != null)
            {
                ReceivedData newData = ReceivedDataCopy(data);
                DealReceivedData.BeginInvoke(newData, null, null);
            }
            else
            {
                Log.writeLog("No client registered in event server yet!", ErrorLevel.DEBUG);
            }
        }

    }
}
