﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogLib.Forms
{
    public partial class FormMsgBox : Form
    {
        private MsgBoxResult _result = MsgBoxResult.None;
        private MsgBoxResult _resultButton1, _resultButton2, _resultButton3;

        public FormMsgBox(string text, string caption, MsgBoxButtons buttons, MsgBoxIcon icon, MsgBoxDefaultButton defaultbutton)
        {
            InitializeComponent();
            this.lblTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            this.lbl_Content.Text = text;
            this.lbl_Content.Height = Math.Max(20 * this.lbl_Content.Lines.Length, this.lbl_Content.Height);
            this.Height = this.lbl_Content.Height + 165;
            this.Text = caption;
            switch(icon)
            {
                case MsgBoxIcon.Error:
                    this.pic_Ico.Image = LogLib.Properties.Resources.error;
                    break;
                case MsgBoxIcon.Information:
                    this.pic_Ico.Image = LogLib.Properties.Resources.info;
                    break;
                case MsgBoxIcon.Question:
                    this.pic_Ico.Image = LogLib.Properties.Resources.question;
                    break;
            }
            this.SetButton(buttons, defaultbutton);
        }

        public MsgBoxResult show()
        {
            this.ShowDialog();
            return _result;
        }

        private void SetButton(MsgBoxButtons buttons, MsgBoxDefaultButton defaultbutton)
        {
            int width = this.panel_Button.Width / 3 - 5;
            int height = this.panel_Button.Height - 7;
            int x = 0, y = 0;
            List<MsgBoxResult> results = MsgBoxTypes.button2result.ContainsKey(buttons) ? MsgBoxTypes.button2result[buttons] : new List<MsgBoxResult>();
            switch (results.Count())
            {
                case 1:
                    {
                        _resultButton1 = results[0];

                        x = this.panel_Button.Width - width;
                        y = 0;
                        Button btn1 = new Button();
                        btn1.Size = new Size(width, height);
                        btn1.Font = new Font("Segoe UI Symbol", 9F);
                        btn1.Location = new Point(x, y);
                        btn1.Text = _resultButton1.ToString();
                        btn1.Click += btn1_Click;
                        panel_Button.Controls.Add(btn1);

                        switch (defaultbutton)
                        {
                            case MsgBoxDefaultButton.Button1: this.ActiveControl = btn1; this.AcceptButton = btn1; break;
                        }
                    }
                    break;
                case 2:
                    {
                        _resultButton1 = results[0];
                        _resultButton2 = results[1];

                        x = (this.panel_Button.Width - width * 2) / 3;
                        y = 0;
                        Button btn1 = new Button();
                        btn1.Size = new Size(width, height);
                        btn1.Font = new Font("Segoe UI Symbol", 9F);
                        btn1.Location = new Point(x, y);
                        btn1.Text = _resultButton1.ToString();
                        btn1.Click += btn1_Click;
                        panel_Button.Controls.Add(btn1);

                        x = x * 2 + width;
                        y = 0;
                        Button btn2 = new Button();
                        btn2.Size = new Size(width, height);
                        btn2.Font = new Font("Segoe UI Symbol", 9F);
                        btn2.Location = new Point(x, y);
                        btn2.Text = _resultButton2.ToString();
                        btn2.Click += btn2_Click;
                        panel_Button.Controls.Add(btn2);

                        switch(defaultbutton)
                        {
                            case MsgBoxDefaultButton.Button1: this.ActiveControl = btn1; this.AcceptButton = btn1; break;
                            case MsgBoxDefaultButton.Button2: this.ActiveControl = btn2; this.AcceptButton = btn2; break;
                        }
                    }
                    break;
                case 3:
                    {
                        _resultButton1 = results[0];
                        _resultButton2 = results[1];
                        _resultButton3 = results[2];

                        x = 0;
                        y = 0;
                        Button btn1 = new Button();
                        btn1.Size = new Size(width, height);
                        btn1.Font = new Font("Segoe UI Symbol", 9F);
                        btn1.Location = new Point(x, y);
                        btn1.Text = _resultButton1.ToString();
                        btn1.Click += btn1_Click;
                        panel_Button.Controls.Add(btn1);

                        x = (this.panel_Button.Width - width * 3) / 2 + width;
                        y = 0;
                        Button btn2 = new Button();
                        btn2.Size = new Size(width, height);
                        btn2.Font = new Font("Segoe UI Symbol", 9F);
                        btn2.Location = new Point(x, y);
                        btn2.Text = _resultButton2.ToString();
                        btn2.Click += btn2_Click;
                        panel_Button.Controls.Add(btn2);

                        x = (this.panel_Button.Width - width * 3) + width * 2;
                        y = 0;
                        Button btn3 = new Button();
                        btn3.Size = new Size(width, height);
                        btn3.Font = new Font("Segoe UI Symbol", 9F);
                        btn3.Location = new Point(x, y);
                        btn3.Text = _resultButton3.ToString();
                        btn3.Click += btn3_Click;
                        panel_Button.Controls.Add(btn3);

                        switch (defaultbutton)
                        {
                            case MsgBoxDefaultButton.Button1: this.ActiveControl = btn1; this.AcceptButton = btn1; break;
                            case MsgBoxDefaultButton.Button2: this.ActiveControl = btn2; this.AcceptButton = btn2; break;
                            case MsgBoxDefaultButton.Button3: this.ActiveControl = btn3; this.AcceptButton = btn3; break;
                        }
                    }
                    break;
                default:
                    {
                        _resultButton1 = MsgBoxResult.OK;

                        x = this.panel_Button.Width - width;
                        y = 0;
                        Button btn1 = new Button();
                        btn1.Size = new Size(width, height);
                        btn1.Font = new Font("Segoe UI Symbol", 9F);
                        btn1.Location = new Point(x, y);
                        btn1.Text = MsgBoxResult.OK.ToString();
                        btn1.Click += btn1_Click;
                        panel_Button.Controls.Add(btn1);

                        switch (defaultbutton)
                        {
                            case MsgBoxDefaultButton.Button1: this.ActiveControl = btn1; this.AcceptButton = btn1; break;
                        }
                    }
                    break;
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            this._result = _resultButton1;
            this.Close();
            this.Dispose();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            this._result = _resultButton2;
            this.Close();
            this.Dispose();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            this._result = _resultButton3;
            this.Close();
            this.Dispose();
        }

        private void frmMessageBox_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

    }

}
