﻿using AlcUtility;

namespace ALC.Managers
{
    public class StatusMgr
    {
        public static SYSTEM_STATUS SystemStatus = SYSTEM_STATUS.Idle;
    }
}
