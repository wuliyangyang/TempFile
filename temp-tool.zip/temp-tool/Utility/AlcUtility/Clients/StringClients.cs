﻿using LogLib;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;
using System;
using System.Net;
using System.Threading.Tasks;

namespace AlcUtility
{
    public class StringClients
    {
        private int _port = 5001;
        private AppServer _server;
        private AppSession _session;

        private Action<string> _msgHandle;
        private Action<string> _disconnected;
        public StringClients(Action<string> msgHandle, Action<string> disconnected)
        {
            _msgHandle = msgHandle;
            _disconnected = disconnected;
        }

        ~StringClients()
        {
            if (_server != null)
            {
                try
                {
                    _server.Stop();
                }
                catch { }
                _server = null;
            }
        }
        public void close()
        {
            if(_server != null)
            {
                try
                {
                    _server.Stop();
                }
                catch { }
                _server = null;
            }
        }

        public bool Connect(string remoteIP, int remoteport, bool bFirstConect)
        {
            try
            {
                if (bFirstConect)
                {
                    int ret = StartServer();
                    if (ret != ErrorCode.EC_OK) return false;
                }
                var remote = new IPEndPoint(IPAddress.Parse(remoteIP), remoteport);
                var client = _server as IActiveConnector;
                var task = client.ActiveConnect(remote);

                var r = task.ContinueWith(t =>
                {
                    Log.writeLog("connected..." + t.Result.Session.RemoteEndPoint, ErrorLevel.DEBUG);
                    return t.Result.Result;
                }, TaskContinuationOptions.OnlyOnRanToCompletion);
                return r.Result;
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
                return false;
            }
        }

        private int StartServer()
        {
            if (_server != null)
                return ErrorCode.EC_OK;

            _server = new AppServer();

            //set listen port
            while (!_server.Setup(_port))
            {
                _port++;
                //return ErrorCode.EC_Error;
            }
            Log.writeLog(string.Format("Start super socket server for client with port {0}!", _port), ErrorLevel.DEBUG);

            //----------------------ADD EVENTS--------------------------

            //add new client connected event handler
            _server.NewSessionConnected += new SessionHandler<AppSession>(NewSessionConnected);

            //add request received event handler
            _server.NewRequestReceived += new RequestHandler<AppSession, StringRequestInfo>(RequestReceived);

            //add connecion closed event handler
            _server.SessionClosed += new SessionHandler<AppSession, CloseReason>(SessionClosed);

            if (!_server.Start())
            {
                Log.writeLog("Start superServer failed!", ErrorLevel.DEBUG);
                close();
                return ErrorCode.EC_Error;
            }
            Log.writeLog("SuperSocketServer Started !", ErrorLevel.DEBUG);

            return ErrorCode.EC_OK;
        }

        private void NewSessionConnected(AppSession client)
        {
            _session = client;
            Log.writeLog(string.Format("Client {0} connected!", client.RemoteEndPoint), ErrorLevel.DEBUG);
        }


        private void RequestReceived(AppSession client, StringRequestInfo data)
        {
            try
            {
                Log.writeLog(string.Format("Received from {0}: {1} {2}", client.RemoteEndPoint, data.Key, data.Body), ErrorLevel.DEBUG);
                _msgHandle(data.Key + data.Body);
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        private void SessionClosed(AppSession client, CloseReason reason)
        {
            try
            {
                _session = null;
                Log.writeLog(string.Format("{0} closed. reason: {1}", client.RemoteEndPoint, reason));
                _disconnected(reason.ToString());
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        public bool sendMessage(string msg)
        {
            try
            {
                if(_session != null)
                {
                    _session.Send(msg);
                    Log.writeLog(string.Format("Send --> {0}", msg));
                }
                else
                {
                    Log.writeLog("Send message Failed. Connection is closed.");
                }

            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
                return false;
            }
            return true;
        }
    }
}
