﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogLib;

namespace ALC.Managers
{
    public class ErrorHandler
    {
        private static ErrorHandler _instance = new ErrorHandler();

        public static ErrorHandler GetInstance()
        {
            return _instance;
        }

        private ErrorHandler() { }

        public MsgBoxResult HandleError(string moduleName, long errCode, int errLevel, string errMsg)
        {
            var message = errMsg + "\nErrorCode: " + errCode;
            Log.writeLog(message, errLevel, moduleName);
            MsgBoxResult ret = MsgBoxResult.None;
            switch (errLevel)
            {
                case ErrorLevel.WARN:
                    Task.Run(() =>
                    {
                        Log.showMessageBox(message, moduleName + " Warn", MsgBoxButtons.OK, MsgBoxIcon.Error);
                    });
                    break;
                case ErrorLevel.ERROR:
                    ret = Log.showMessageBox(message, moduleName + " Error", MsgBoxButtons.AbortRetryIgnore, MsgBoxIcon.Error);

                    if (ret == MsgBoxResult.Abort)
                    {
                        LogicMgr.GetInstance().Abort();
                    }
                    break;
                case ErrorLevel.FATAL:
                    Task.Run(() =>
                    {
                        Log.showMessageBox(message, moduleName + " Fatal Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                    });
                    LogicMgr.GetInstance().Abort();
                    break;
            }
            return ret;
        }
    }
}
