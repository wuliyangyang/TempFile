﻿using AlcUtility;
using System;

namespace ALC.Managers
{
    public class User
    {
        public string authority { get; set; }
        public string name { get; set; }
        public string desc { get; set; }
    }

    public class UserMgr
    {
        private static UserMgr _instance = new UserMgr();

        public static UserMgr GetInstance()
        {
            return _instance;
        }
        private UserMgr()
        {
        }

        private User _currentUser;
        public Action<string, string> UserAuthorityChanged;
        public User CurrentUser
        {
            get => _currentUser;
            private set
            {
                var oldAuthority = _currentUser?.authority;
                _currentUser = value;
                if (oldAuthority != _currentUser.authority)
                    UserAuthorityChanged?.Invoke(oldAuthority, value.authority);
            }
        }

        public bool Login(User user, string password)
        {
            if (CheckPasswordCorrect(user.authority, password))
            {
                CurrentUser = user;
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckPasswordCorrect(string authority, string password)
        {
            if (authority.ToUpper() == UserAuthority.OPERATOR.ToString().ToUpper())
            {
                return true;
            }
            string passwordStr = BinaryFileHelper.getInstence().GetPassword(authority);
            if (passwordStr == null) return authority == password;
            string passwordReal = RSAMgr.GetInstance().RSADecrypt(passwordStr);
            if (string.Compare(password, passwordReal) == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
