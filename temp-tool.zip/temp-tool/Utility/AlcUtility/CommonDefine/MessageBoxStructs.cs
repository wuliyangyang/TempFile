﻿namespace AlcUtility
{
    public enum AlcMsgBoxButtons
    {
        OK = 0,
        OKCancel,
        AbortRetryIgnore,
        YesNoCancel,
        YesNo,
        RetryCancel,
        ContinueStop,
        AbortRetry,
    }

    public enum AlcMsgBoxIcon
    {
        None = 0,
        Information,
        Question,
        Error,
    }

    public enum AlcMsgBoxDefaultButton
    {
        Button1,
        Button2,
        Button3,
    }

    public enum AlcMsgBoxResult
    {
        None = 0,
        OK = 1,
        Yes = 2,
        No = 3,
        Cancel = 4,
        Retry = 5,
        Ignore = 6,
        Abort = 7,
        Continue = 8,
        Stop = 9,
    }

    public enum AlcErrorLevel
    {
        DEBUG = 0,
        TRACE,
        WARN,
        ERROR,
        FATAL
    }
}
