﻿namespace AlcUtility
{
    public enum SYSTEM_STATUS
    {
        Idle,

        Initing,
        InitFailed,
        Ready,

        Starting,
        StartFailed,
        Running,

        Pausing,
        PauseFailed,
        Paused,

        Resuming,
        ResumeFailed,

        Finishing,
        FinishedFailed,
        Finished,

        Resetting,
        ResetFailed,

        Error,
        Abort,
    }
}
