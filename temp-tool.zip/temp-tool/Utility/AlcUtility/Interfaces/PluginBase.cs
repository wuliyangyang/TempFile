﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace AlcUtility
{
    public class PluginBase : IPlugins
    {
        protected readonly string _moduleType;
        protected List<string> _moduleTypesToSub;

        protected PluginBase(string moduleType)
        {
            _moduleType = moduleType;
            _moduleTypesToSub = new List<string>() { moduleType };
        }
        protected PluginBase(string moduleType, List<string> moduleTypesToSub)
        {
            _moduleType = moduleType;
            _moduleTypesToSub = moduleTypesToSub;
        }

        public Action<ReceivedData> SendMessageToNetwork;
        public Action<string, ReceivedData> BroadcastMessageToPlugins;

        /// <summary>
        /// regist to the ALC
        /// </summary>
        /// <param name="sendmessage">for sending messages to the network server</param>
        /// <param name="broadcast">for sending messages to the module which subscribes it</param>
        /// <param name="pluginOperate">for doing something that depends on the platform. Please refer to PluginOperateItem for details</param>
        /// <returns>Module Name, List of modules to subscribe</returns>
        public Tuple<string, List<string>> Register(Action<ReceivedData> sendmessage, Action<string, ReceivedData> broadcast)
        {
            SendMessageToNetwork = sendmessage;
            BroadcastMessageToPlugins = broadcast;

            return new Tuple<string, List<string>>(_moduleType, _moduleTypesToSub);
        }

        protected Dictionary<string, ICmdHandler> _jsonMsgHandlers = new Dictionary<string, ICmdHandler>();
        protected Dictionary<int, ICmdHandler> _binaryMsgHandlers = new Dictionary<int, ICmdHandler>();

        public virtual void MessageHandler(ReceivedData data)
        {
            if (data == null) return;

            if (data.strData != null)
            {
                try
                {
                    string msgName = data.strData.msgName.ToLower();
                    if (_jsonMsgHandlers.ContainsKey(msgName))
                    {
                        _jsonMsgHandlers[msgName].HandleMessage(data);
                    }
                    else
                    {
                        Log("unknown message " + msgName, AlcErrorLevel.ERROR);
                    }
                }
                catch (Exception ex)
                {
                    ShowMsgBox(ex.Message + "\n" + ex.StackTrace, "System Error");
                }
            }

            if (data.binaryData != null)
            {
                try
                {
                    int cmdId = data.binaryData.commandId;
                    if (_binaryMsgHandlers.ContainsKey(cmdId))
                    {
                        _binaryMsgHandlers[cmdId].HandleMessage(data);
                    }
                    else
                    {
                        Log("unknown command " + cmdId, AlcErrorLevel.ERROR);
                    }
                }
                catch (Exception ex)
                {
                    ShowMsgBox(ex.Message + "\n" + ex.StackTrace, "System Error");
                }
            }
        }

        #region UI
        public virtual UserControl GetControl()
        {
            return null;
        }
        public virtual Form GetForm()
        {
            return null;
        }
        public virtual UserControl GetConfigView()
        {
            return null;
        }
        #endregion //UI

        #region Logic
        public virtual bool Load()
        {
            return true;
        }
        public virtual bool Initialize()
        {
            return true;
        }
        public virtual bool Start()
        {
            return true;
        }
        public virtual bool Stop()
        {
            return true;
        }
        public virtual bool Reset()
        {
            return true;
        }
        public virtual bool Pause()
        {
            return true;
        }
        public virtual bool Resume()
        {
            return true;
        }
        public virtual bool Abort()
        {
            return true;
        }
        public virtual bool Dispose()
        {
            return true;
        }
        #endregion //Logic

        #region Wrap
        public void Log(string text, AlcErrorLevel errLevel = AlcErrorLevel.TRACE)
        {
            AlcSystem.Instance.Log(text, _moduleType, errLevel);
        }
        public void UpdateModuleStatus(bool alive)
        {
            AlcSystem.Instance.UpdateModuleStatus(alive, _moduleType);
        }
        public AlcMsgBoxResult ShowMsgBox(string text, string caption, AlcMsgBoxButtons buttons = AlcMsgBoxButtons.OK, AlcMsgBoxIcon icon = AlcMsgBoxIcon.Information, AlcMsgBoxDefaultButton defaultButton = AlcMsgBoxDefaultButton.Button1)
        {
            if (text == null) return AlcMsgBoxResult.None;
            return AlcSystem.Instance.ShowMsgBox(text, caption ?? _moduleType, buttons, icon, defaultButton);
        }
        public void SaveCsv(string csvName, string head, string text, bool addTime = true)
        {
            if (string.IsNullOrEmpty(head) || string.IsNullOrEmpty(text)) return;
            AlcSystem.Instance.SaveCsv(csvName ?? _moduleType, head, text, addTime);
        }
        public AlcMsgBoxResult Error(string errorMsg, long errorCode, AlcErrorLevel errorLevel)
        {
            return AlcSystem.Instance.Error(errorMsg, errorCode, errorLevel, _moduleType);
        }
        public SYSTEM_STATUS GetSystemStatus()
        {
            return AlcSystem.Instance.GetSystemStatus();
        }
        public string GetUserAuthority()
        {
            return AlcSystem.Instance.GetUserAuthority();
        }
        public void ButtonClickRequire(ButtonsName button)
        {
            AlcSystem.Instance.ButtonClickRequire(button);
        }
        #endregion //Wrap

        public interface ICmdHandler
        {
            void HandleMessage(ReceivedData data);
        }
    }
}
