﻿using NetAndEvent.EventDispatcher;
using AlcUtility;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using LogLib;

namespace ALC.Managers
{
    public class Plugin
    {
        public string ModuleType;
        public EventClient EventClient;
        public string DllName;
        public Form ModuleForm;
        public UserControl MainControl;
        public UserControl ConfigControl;
        public string ModuleIcon;

        public string version;
        public bool checkVersion;

        public ControlPosition mainpos;
        public ControlPosition configpos;

        public delegate bool ControlLogic();
        public ControlLogic init;
        public ControlLogic start;
        public ControlLogic stop;
        public ControlLogic pause;
        public ControlLogic resume;
        public ControlLogic reset;
        public ControlLogic abort;
        public ControlLogic load;
        public ControlLogic dispose;

        public int initRanking;
        public int startRanking;
        public int stopRanking;
        public int resetRanking;
    }

    public class ControlPosition
    {
        public int startx { get; set; }
        public int starty { get; set; }
        public int length { get; set; }
        public int width { get; set; }
    }

    public class PluginMgr
    {
        private static PluginMgr _instance = new PluginMgr();
        public static PluginMgr GetInstance()
        {
            return _instance;
        }

        private readonly string _pluginPath = Application.StartupPath + @"\plugins\";
        private const string _mainPluginName = "Main.dll";

        public List<Plugin> Plugins;
        public List<List<Plugin>> PluginsInitOrder = new List<List<Plugin>>();
        public List<List<Plugin>> PluginsStartOrder = new List<List<Plugin>>();
        public List<List<Plugin>> PluginsStopOrder = new List<List<Plugin>>();
        public List<List<Plugin>> PluginsResetOrder = new List<List<Plugin>>();

        private PluginMgr()
        {
            Plugins = XmlHelper.GetInstance().PluginList;
        }

        ~PluginMgr()
        {
            //Dispose();
        }

        public string GetMainVersion()
        {
            string version = string.Empty;
            try
            {
                AssemblyName assemblyName = AssemblyName.GetAssemblyName(_pluginPath + _mainPluginName);
                version = assemblyName.Version.ToString();
            }
            catch(Exception e)
            {
                Log.showMessageBox("Load main plugin failed!\r\n" + e.Message + "\r\n" + e.StackTrace, "Load Plugin Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                Environment.Exit(-1);
            }
            return version;
        }

        public void LoadAllPlugins()
        {
            try
            {
                for (int i = 0; i < Plugins.Count; i++)
                {
                    if (string.IsNullOrWhiteSpace(Plugins[i].DllName)) continue;

                    Assembly ass = Assembly.LoadFrom(_pluginPath + Plugins[i].DllName);
                    if (Plugins[i].checkVersion)
                    {
                        AssemblyName assName = ass.GetName();
                        string version = assName.Version.ToString();
                        if (string.Compare(Plugins[i].version, version) != 0)
                        {
                            Log.showMessageBox(string.Format("Plugin {0} version {1} doesn't match with xml config {2}!", Plugins[i].DllName, version, Plugins[i].version), "Load Plugin Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                            Environment.Exit(-1);
                        }
                    }
                    Type[] classes = ass.GetTypes();
                    bool realized = false;
                    foreach (Type t in classes)
                    {
                        //Type p = t.GetInterface("IPlugins");
                        //if (p != null)
                        if(t.IsSubclassOf(typeof(PluginBase)))
                        {
                            Type c = ass.GetType(t.ToString());
                            runPlugin(i, c);
                            InsertPluginToOrder(Plugins[i]);
                            realized = true;
                        }
                    }
                    if (realized == false)
                    {
                        Log.showMessageBox(string.Format("Load plugins failed!\r\nThere is no Class realizing IPlugin in {0}", Plugins[i].DllName), "Load Plugin Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                        Environment.Exit(-1);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.showMessageBox("Load plugins failed!\r\n" + ex.Message + "\r\n" + ex.StackTrace, "Load Plugin Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                Environment.Exit(-1);
            }
        }

        private void runPlugin(int index, Type t)
        {
            IPlugins p = Activator.CreateInstance(t) as IPlugins;

            Plugin plu = Plugins[index];

            Tuple<string, List<string>> res = p.Register(sendmessage, broadcast);
            plu.ModuleType = res.Item1;
            plu.EventClient = new EventClient(res.Item2);
            plu.EventClient.DealReceivedData = p.MessageHandler;
            plu.ModuleForm = p.GetForm();
            plu.MainControl = p.GetControl();
            plu.ConfigControl = p.GetConfigView();

            plu.init = p.Initialize;
            plu.start = p.Start;
            plu.stop = p.Stop;
            plu.pause = p.Pause;
            plu.resume = p.Resume;
            plu.reset = p.Reset;
            plu.abort = p.Abort;
            plu.load = p.Load;
            plu.dispose = p.Dispose;
        }

        private void InsertPluginToOrder(Plugin plu)
        {
            bool insert = false;
            for (int i = 0; i < PluginsStartOrder.Count; i++)
            {
                try
                {
                    int ranking = PluginsInitOrder[i][0].initRanking;
                    if (plu.initRanking < ranking)
                    {
                        List<Plugin> plus = new List<Plugin>() { plu };
                        PluginsInitOrder.Insert(i, plus);
                        insert = true;
                        break;
                    }
                    else if (plu.initRanking == ranking)
                    {
                        PluginsInitOrder[i].Add(plu);
                        insert = true;
                        break;
                    }
                }
                catch
                {
                    continue;
                }
            }
            if (!insert)
            {
                List<Plugin> plus = new List<Plugin>() { plu };
                PluginsInitOrder.Add(plus);
            }

            insert = false;
            for (int i = 0; i < PluginsStartOrder.Count; i++)
            {
                try
                {
                    int ranking = PluginsStartOrder[i][0].startRanking;
                    if (plu.startRanking < ranking)
                    {
                        List<Plugin> plus = new List<Plugin>() { plu };
                        PluginsStartOrder.Insert(i, plus);
                        insert = true;
                        break;
                    }
                    else if (plu.startRanking == ranking)
                    {
                        PluginsStartOrder[i].Add(plu);
                        insert = true;
                        break;
                    }
                }
                catch
                {
                    continue;
                }
            }
            if (!insert)
            {
                List<Plugin> plus = new List<Plugin>() { plu };
                PluginsStartOrder.Add(plus);
            }

            insert = false;
            for (int i = 0; i < PluginsStopOrder.Count; i++)
            {
                try
                {
                    int ranking = PluginsStopOrder[i][0].stopRanking;
                    if (plu.stopRanking < ranking)
                    {
                        List<Plugin> plus = new List<Plugin>() { plu };
                        PluginsStopOrder.Insert(i, plus);
                        insert = true;
                        break;
                    }
                    else if (plu.stopRanking == ranking)
                    {
                        PluginsStopOrder[i].Add(plu);
                        insert = true;
                        break;
                    }
                }
                catch
                {
                    continue;
                }
            }
            if (!insert)
            {
                List<Plugin> plus = new List<Plugin>() { plu };
                PluginsStopOrder.Add(plus);
            }

            insert = false;
            for (int i = 0; i < PluginsResetOrder.Count; i++)
            {
                try
                {
                    int ranking = PluginsResetOrder[i][0].resetRanking;
                    if (plu.resetRanking < ranking)
                    {
                        List<Plugin> plus = new List<Plugin>() { plu };
                        PluginsResetOrder.Insert(i, plus);
                        insert = true;
                        break;
                    }
                    else if (plu.resetRanking == ranking)
                    {
                        PluginsResetOrder[i].Add(plu);
                        insert = true;
                        break;
                    }
                }
                catch
                {
                    continue;
                }
            }
            if (!insert)
            {
                List<Plugin> plus = new List<Plugin>() { plu };
                PluginsResetOrder.Add(plus);
            }
        }

        public void Dispose()
        {
            foreach (var p in Plugins)
            {
                p.dispose?.Invoke();
            }
        }

        private void sendmessage(ReceivedData data)
        {
            ServerMgr.GetInstance().SendMessage(data);
        }

        private void broadcast(string module, ReceivedData data)
        {
            EventServer.GetInstance().Broadcast(module, data);
        }
    }
}
