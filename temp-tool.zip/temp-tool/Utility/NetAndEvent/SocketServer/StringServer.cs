﻿using AlcUtility;
using LogLib;
using NetAndEvent.EventDispatcher;
using Newtonsoft.Json;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;
using System;
using System.Collections.Concurrent;

namespace NetAndEvent.SocketServer
{
    public class StringServer
    {
        private int _port;
        private AppServer _server;
        private ConcurrentDictionary<string, AppSession> _sessions = new ConcurrentDictionary<string, AppSession>();
        private ConcurrentDictionary<AppSession, Tuple<string, string>> _clients = new ConcurrentDictionary<AppSession, Tuple<string, string>>();

        public StringServer(int port)
        {
            _port = port;
        }

        ~StringServer()
        {
            if (_server != null)
            {
                _server.Stop();
            }
        }

        public int StartServer()
        {
            _server = new AppServer();

            //set listen port
            if (!_server.Setup(_port))
            {
                Log.writeLog(string.Format("Start super socket server Failed! Bind port {0} error!", _port), ErrorLevel.DEBUG);
                return ErrorCode.EC_Error;
            }

            //----------------------ADD EVENTS--------------------------

            //add new client connected event handler
            _server.NewSessionConnected += new SessionHandler<AppSession>(NewSessionConnected);

            //add request received event handler
            _server.NewRequestReceived += new RequestHandler<AppSession, StringRequestInfo>(RequestReceived);

            //add connecion closed event handler
            _server.SessionClosed += new SessionHandler<AppSession, CloseReason>(SessionClosed);

            if (!_server.Start())
            {
                Log.writeLog("Start superServer failed!", ErrorLevel.DEBUG);
                return ErrorCode.EC_Error;
            }
            Log.writeLog("SuperSocketServer Started !", ErrorLevel.DEBUG);

            return ErrorCode.EC_OK;
        }

        private void NewSessionConnected(AppSession client)
        {
            Log.writeLog(string.Format("Client {0} connected!", client.RemoteEndPoint), ErrorLevel.DEBUG);
        }

        private void RemoveClient(string moduleId)
        {
            AppSession s = null;
            foreach (var k in _clients.Keys)
            {
                if (_clients[k].Item2 == moduleId)
                {
                    s = k;
                    break;
                }
            }
            if (s != null)
            {
                Tuple<string, string> removeItem;
                _clients.TryRemove(s, out removeItem);
            }
        }

        private void RequestReceived(AppSession client, StringRequestInfo data)
        {
            try
            {
                Log.writeLog(string.Format("Received from {0}: {1} {2}", client.RemoteEndPoint, data.Key, data.Body), ErrorLevel.DEBUG);
                JsonData recv = JsonConvert.DeserializeObject<JsonData>(string.Format("{0} {1}", data.Key, data.Body));
                if (recv == null)
                {
                    throw new Exception("Received message format error!");
                }
                if (string.Compare(recv.msgName.Trim().ToLower(), CommonCommands.Register) == 0)
                {
                    RegisterParam clientInfo = JsonConvert.DeserializeObject<RegisterParam>(recv.msgParam.ToString());

                    //save testerId for sending message
                    if (_sessions.Keys.Contains(clientInfo.moduleid))
                    {
                        //_clients should remove it first
                        RemoveClient(clientInfo.moduleid);
                    }
                    _clients.AddOrUpdate(client, new Tuple<string, string>(clientInfo.moduletype, clientInfo.moduleid), (key, oldV) =>
                    {
                        return new Tuple<string, string>(clientInfo.moduletype, clientInfo.moduleid);
                    });
                    _sessions.AddOrUpdate(clientInfo.moduleid, client, (key, oldV) => { return client; });
                }

                Tuple<string, string> moduleInfo;
                if (_clients.TryGetValue(client, out moduleInfo))
                {
                    ReceivedData rd = new ReceivedData()
                    {
                        moduleType = moduleInfo.Item1,
                        moduleId = moduleInfo.Item2,
                        ip = client.RemoteEndPoint.Address.ToString(),
                        port = client.RemoteEndPoint.Port,
                        strData = recv
                    };
                    EventServer.GetInstance().Broadcast(moduleInfo.Item1, rd);
                    Log.writeLog(string.Format("{0}-->ALC : {1} {2} {3} {4}; channel: {5}, type: {6}", rd.moduleId, recv.msgName, recv.msgParam, recv.msgResult, recv.errMsg, recv.msgChannel, recv.msgType), ErrorLevel.DEBUG, rd.moduleType);
                }
                else
                {
                    JsonData reply = new JsonData()
                    {
                        msgType = MessageType.RSP,
                        msgName = recv.msgName,
                        msgResult = ErrorCode.EC_Error,
                        errMsg = "Client has not registered yet !"
                    };
                    client.Send(JsonConvert.SerializeObject(reply));
                    Log.writeLog(string.Format("This client {0} has not sent Init message yet !", client.LocalEndPoint), ErrorLevel.DEBUG);
                }
            }
            catch (Exception ex)
            {
                JsonData reply = new JsonData()
                {
                    msgType = MessageType.RSP,
                    msgResult = ErrorCode.EC_Error,
                    errMsg = "Message Format Error!"
                };
                client.Send(JsonConvert.SerializeObject(reply));
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        private void SessionClosed(AppSession client, CloseReason reason)
        {
            //remove from testToSession
            try
            {
            Log.writeLog(string.Format("Client {0} closed! Close reason : {1}", client.RemoteEndPoint, reason.ToString()), ErrorLevel.DEBUG);
                Tuple<string, string> closingClient;
                if (_clients.TryGetValue(client, out closingClient))
                {
                    if (reason != CloseReason.ServerClosing)
                    {
                        //let top level know client's disconnecting
                        ReceivedData rd = new ReceivedData()
                        {
                            moduleType = closingClient.Item1,
                            moduleId = closingClient.Item2,
                            strData = new JsonData()
                            {
                                msgType = "Req",
                                msgName = CommonCommands.Disconnected,
                                msgResult = (int)reason,
                                errMsg = reason.ToString()
                            }
                        };
                        EventServer.GetInstance().Broadcast(closingClient.Item1, rd);
                        Log.writeLog(string.Format("{0} connection closed! Close reason : {1}", rd.moduleId, reason.ToString()), ErrorLevel.DEBUG, rd.moduleType);
                    }

                    //remove from local list
                    AppSession session;
                    _sessions.TryRemove(closingClient.Item2, out session);

                    Tuple<string, string> removedTester;
                    _clients.TryRemove(client, out removedTester);
                }
            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
            }
        }

        public int sendMessage(string moduleId, JsonData msg)
        {
            try
            {
                AppSession client;
                if (_sessions.TryGetValue(moduleId, out client))
                {
                    string sendMsg = JsonConvert.SerializeObject(msg) + "\r\n";
                    client.Send(sendMsg);
                    Tuple<string, string> clientInfo;
                    _clients.TryGetValue(client, out clientInfo);
                    string moduleType = clientInfo?.Item1;
                    string paramStr = JsonConvert.SerializeObject(msg.msgParam);
                    Log.writeLog(string.Format("ALC-->{0}: {1} {2} {3} {4}; channel: {5}, type: {6}", moduleId, msg.msgName, paramStr, msg.msgResult, msg.errMsg, msg.msgChannel, msg.msgType), ErrorLevel.DEBUG, moduleType);
                }
                else
                {
                    Log.writeLog(string.Format("Error! StringServer not find the client with module id is {0}", moduleId), ErrorLevel.DEBUG);
                }

            }
            catch (Exception ex)
            {
                Log.writeLog(ex.Message + "\r\n" + ex.StackTrace, ErrorLevel.DEBUG);
                return ErrorCode.EC_Error;
            }
            return ErrorCode.EC_OK;
        }
    }
}
