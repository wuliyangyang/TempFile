﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogLib.Managers
{
    [Obsolete("LogFileMgr is Obsolete, use Log4netMgr", true)]
    class LogFileMgr
    {
        private static LogFileMgr _logFileMgr = new LogFileMgr();

        public static LogFileMgr getInstance()
        {
            return _logFileMgr;
        }

        private string PATH_LOG;

        LogFileMgr()
        {
            this.init();
        }

        ~LogFileMgr()
        {
            foreach(var sw in _files.Values)
            {
                try
                {
                    sw.Close();
                    sw.Dispose();
                }
                catch
                { }
            }
        }

        private object _addLogLock = new object();
        private Dictionary<string, StreamWriter> _files = new Dictionary<string, StreamWriter>();

        private void init()
        {
            PATH_LOG = System.Configuration.ConfigurationManager.AppSettings["LogPath"];
        }

        [Obsolete("LogFileMgr.saveLogFile is Obsolete, use Log4netMgr.log", true)]
        public void saveLogFile(string titleStr, string msg)
        {
            Task.Run(() =>
            {
                try
                {
                    string strmsg = string.Format("[{0}] {1}", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss:fff"), msg);

                    string strLogFile = PATH_LOG + DateTime.Now.ToString("yyyyMMdd");
                    strLogFile = strLogFile + "\\" + titleStr + DateTime.Now.ToString("yyyyMMdd");
                    strLogFile = string.Concat(strLogFile, ".log");

                    lock (_addLogLock)
                    {
                        if (!_files.Keys.Contains(strLogFile))
                        {
                            if (!Directory.Exists(PATH_LOG))
                                Directory.CreateDirectory(PATH_LOG);
                            if (!Directory.Exists(PATH_LOG + DateTime.Now.ToString("yyyyMMdd")))
                                Directory.CreateDirectory(PATH_LOG + DateTime.Now.ToString("yyyyMMdd"));

                            _files.Add(strLogFile, new StreamWriter(strLogFile, true, Encoding.UTF8));
                        }
                    }

                    lock (_files[strLogFile])
                    {
                        _files[strLogFile].WriteLine(strmsg);
                        _files[strLogFile].Flush();
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Write(ex.Message);
                    System.Diagnostics.Debug.Write(ex.StackTrace);
                }
            });
        }

        [Obsolete("LogFileMgr.saveCsvFile is Obsolete, use Log4netMgr.SaveSCV", true)]
        public bool saveCsvFile(string titleStr, string msg, string headString)
        {
            headString = "Time," + (string.IsNullOrEmpty(headString) ? "Discription" : headString);

            string strLogFile = string.Empty;

            if (!Directory.Exists(PATH_LOG))
                Directory.CreateDirectory(PATH_LOG);
            if (!Directory.Exists(PATH_LOG + DateTime.Now.ToString("yyyyMMdd")))
                Directory.CreateDirectory(PATH_LOG + DateTime.Now.ToString("yyyyMMdd"));

            strLogFile = PATH_LOG + DateTime.Now.ToString("yyyyMMdd");
            try
            {
                strLogFile = strLogFile + "\\" + titleStr + DateTime.Now.ToString("yyyyMMdd");	
                strLogFile = string.Concat(strLogFile, ".csv");
                if (!File.Exists(strLogFile))
                {
                    StreamWriter sw = new StreamWriter(strLogFile, true, Encoding.UTF8);
                    sw.WriteLine(headString);
                    sw.Close();
                }
                StreamWriter sw1 = new StreamWriter(strLogFile, true, Encoding.UTF8);
                msg = DateTime.Now.ToString("HH:mm:ss") + "," + msg;
                sw1.WriteLine(msg);
                sw1.Close();
                return true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message);
                System.Diagnostics.Debug.Write(ex.StackTrace);
                return false;
            }
        }
    }
}