﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlcUtility;

namespace PluginTest
{
    public class ConfigMgr : Configur
    {
        public static ConfigMgr Instance { get; } = new ConfigMgr();

        public int TestCfg
        {
            get => getInt("TestCfg", 1000);
            set => addOrUpdate("TestCfg", value.ToString());
        }
    }
}
