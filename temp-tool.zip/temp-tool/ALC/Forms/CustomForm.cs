﻿using ALC.Managers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALC.Forms
{
    public partial class CustomForm : Form
    {
        public CustomForm()
        {
            InitializeComponent();
            ResetTitlePanel();
        }

        private bool moving = false;
        private Point oldMousePosition;

        public new FormBorderStyle FormBorderStyle
        {
            get
            {
                return base.FormBorderStyle;
            }
            set
            {
                if (value != FormBorderStyle.Sizable && value != FormBorderStyle.SizableToolWindow)
                {
                    pan_Title.Controls.Remove(btn_FrmMaximum);
                }
                base.FormBorderStyle = value;
            }
        }

        #region 隐藏父类的属性，使其不可见

        [Browsable(false)]
        public new string Text
        {
            get
            {
                return this.lbl_FrmTitle.Text;
            }
            set
            { }
        }

        [Browsable(false)]
        public new bool ControlBox
        {
            get {
                return false;
            }
            set
            {
                base.ControlBox = false;
            }
        }

        #endregion

        [Browsable(true)]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [Description("窗体图标")]
        public Image TitleImage
        {
            get { return this.pan_Ico.BackgroundImage; }
            set { this.pan_Ico.BackgroundImage = value; }
        }

        [Browsable(true)]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [Description("窗体布局")]
        public ImageLayout TitleImageLayout
        {
            get { return this.pan_Ico.BackgroundImageLayout; }
            set { this.pan_Ico.BackgroundImageLayout = value; }
        }

        [Browsable(true)]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [Description("窗体标题")]
        public string Title
        {
            get { return this.lbl_FrmTitle.Text; }
            set { this.lbl_FrmTitle.Text = value; }
        }



        [Browsable(true)]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [Description("窗体标题字体样式")]
        public Font TitleFont
        {
            get
            {
                return this.lbl_FrmTitle.Font;
            }
            set
            {
                this.lbl_FrmTitle.Font = value;
            }
        }


        [Browsable(true)]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [Description("窗体标题字体颜色")]
        public Color TitleColor
        {
            get
            {
                return this.lbl_FrmTitle.ForeColor;
            }
            set
            {
                this.lbl_FrmTitle.ForeColor = value;
            }
        }

        [Browsable(true)]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [Description("窗体标题栏背景色")]
        public Color TitleBarBackColor
        {
            get
            {
                return pan_Title.BackColor;
            }
            set
            {
                pan_Title.BackColor = value;
            }
        }




        public new bool MaximizeBox
        {
            get
            {
                return pan_Title.Contains(btn_FrmMaximum);
            }
            set
            {
                if (!value)
                {
                    pan_Title.Controls.Remove(btn_FrmMaximum);
                }
                else if (!pan_Title.Contains(btn_FrmMaximum))
                {
                    pan_Title.Controls.Add(btn_FrmMaximum);
                }
            }
        }

        public new bool MinimizeBox
        {
            get
            {
                return pan_Title.Contains(btn_FrmMinimize);
            }
            set
            {
                if (!value)
                {
                    pan_Title.Controls.Remove(btn_FrmMinimize);
                }
                else if (!pan_Title.Contains(btn_FrmMinimize))
                {
                    pan_Title.Controls.Add(btn_FrmMinimize);
                }
            }
        }


        private void ResetTitlePanel()
        {
            base.ControlBox = false;
            base.Text = null;
            SetToolTip(btn_FrmClose, "关闭");
            //btn_FrmMaximum.Size = btn_FrmClose.Size;
            SetToolTip(btn_FrmMaximum, "最大化或还原");
            //btn_FrmMinimize.Size = btn_FrmClose.Size;
            SetToolTip(btn_FrmMinimize, "最小化");
        }

        private void SetToolTip(Control ctrl, string tip)
        {
            new ToolTip().SetToolTip(ctrl, tip);
        }

        private void Titlebutton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            switch (btn.Tag.ToString())
            {
                case "close":
                    {
                        this.Close();
                        break;
                    }
                case "max":
                    {
                        if (this.WindowState == FormWindowState.Maximized)
                        {
                            this.WindowState = FormWindowState.Normal;
                            this.btn_FrmMaximum.Image = ALC.Properties.Resources.top_full_screen_normal;
                        }
                        else
                        {
                            this.WindowState = FormWindowState.Maximized;
                            this.btn_FrmMaximum.Image = ALC.Properties.Resources.top_adaptive_normal;
                        }
                        break;
                    }
                case "min":
                    {
                        if (this.WindowState != FormWindowState.Minimized)
                        {
                            this.WindowState = FormWindowState.Minimized;
                        }
                        break;
                    }
            }
        }

        private void Titlepanel_MouseDown(object sender, MouseEventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                return;
            }
            //Titlepanel.Cursor = Cursors.NoMove2D;
            oldMousePosition = e.Location;
            moving = true;
        }

        private void Titlepanel_MouseUp(object sender, MouseEventArgs e)
        {
            //Titlepanel.Cursor = Cursors.Default;
            moving = false;
        }

        private void Titlepanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && moving)
            {
                Point newPosition = new Point(e.Location.X - oldMousePosition.X, e.Location.Y - oldMousePosition.Y);
                this.Location += new Size(newPosition);
            }
        }

        private void Titlepanel_DoubleClick(object sender, EventArgs e)
        {
            if (pan_Title.Contains(btn_FrmMaximum))
            {
                btn_FrmMaximum.PerformClick();
            }
        }

        private void Titlepanel_ControlRemoved(object sender, ControlEventArgs e)
        {
            switch (e.Control.Name)
            {
                case "btn_FrmMinimize":
                    {
                        if (pan_Title.Contains(btn_FrmMinimize))
                        {
                            btn_FrmMinimize.Left = btn_FrmClose.Left - btn_FrmClose.Width;
                        }
                        break;
                    }
            }
        }

        private void Titlepanel_ControlAdded(object sender, ControlEventArgs e)
        {
            switch (e.Control.Name)
            {
                case "btn_FrmMaximum":
                    {
                        if (pan_Title.Contains(btn_FrmMinimize))
                        {
                            btn_FrmMinimize.Left = btn_FrmMaximum.Left - btn_FrmMaximum.Width;
                        }
                        break;
                    }
                case "btn_FrmMinimize":
                    {
                        if (pan_Title.Contains(btn_FrmMaximum))
                        {
                            btn_FrmMinimize.Left = btn_FrmMaximum.Left - btn_FrmMaximum.Width;
                        }
                        break;
                    }
            }
        }

        private void lbl_FrmTitle_MouseDown(object sender, MouseEventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                return;
            }
            //Titlepanel.Cursor = Cursors.NoMove2D;
            oldMousePosition = e.Location;
            moving = true;
        }

        private void lbl_FrmTitle_MouseMove(object sender, MouseEventArgs e)
        {
            moving = false;
        }

        private void lbl_FrmTitle_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && moving)
            {
                Point newPosition = new Point(e.Location.X - oldMousePosition.X, e.Location.Y - oldMousePosition.Y);
                this.Location += new Size(newPosition);
            }
        }
    }
}
