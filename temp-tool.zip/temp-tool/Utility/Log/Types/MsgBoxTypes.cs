﻿using System.Collections.Generic;

namespace LogLib
{
    public enum MsgBoxButtons
    {
        OK = 0,
        OKCancel,
        AbortRetryIgnore,
        YesNoCancel,
        YesNo,
        RetryCancel,
        ContinueStop,
        AbortRetry,
        ContinueAbort,
        ContinueStopAbort,
    }

    public enum MsgBoxIcon
    {
        None = 0,
        Information,
        Question,
        Error,
    }

    public enum MsgBoxDefaultButton
    {
        Button1,
        Button2,
        Button3,
    }

    public enum MsgBoxResult
    {
        None = 0,
        OK = 1,
        Yes = 2,
        No = 3,
        Cancel = 4,
        Retry = 5,
        Ignore = 6,
        Abort = 7,
        Continue = 8,
        Stop = 9,
    }

    internal class MsgBoxTypes
    {
        internal static readonly Dictionary<MsgBoxButtons, List<MsgBoxResult>> button2result = new Dictionary<MsgBoxButtons, List<MsgBoxResult>>()
        {
            {MsgBoxButtons.OK, new List<MsgBoxResult>(){MsgBoxResult.OK}},
            {MsgBoxButtons.OKCancel, new List<MsgBoxResult>(){MsgBoxResult.OK, MsgBoxResult.Cancel}},
            {MsgBoxButtons.AbortRetryIgnore, new List<MsgBoxResult>(){MsgBoxResult.Abort, MsgBoxResult.Retry, MsgBoxResult.Ignore}},
            {MsgBoxButtons.YesNoCancel, new List<MsgBoxResult>(){MsgBoxResult.Yes, MsgBoxResult.No, MsgBoxResult.Cancel}},
            {MsgBoxButtons.YesNo, new List<MsgBoxResult>(){MsgBoxResult.Yes, MsgBoxResult.No}},
            {MsgBoxButtons.RetryCancel, new List<MsgBoxResult>(){MsgBoxResult.Retry, MsgBoxResult.Cancel}},
            {MsgBoxButtons.ContinueStop, new List<MsgBoxResult>(){MsgBoxResult.Continue, MsgBoxResult.Stop}},
            {MsgBoxButtons.AbortRetry, new List<MsgBoxResult>(){MsgBoxResult.Abort, MsgBoxResult.Retry}},
            {MsgBoxButtons.ContinueAbort, new List<MsgBoxResult>(){MsgBoxResult.Continue, MsgBoxResult.Abort}},
            {MsgBoxButtons.ContinueStopAbort, new List<MsgBoxResult>(){ MsgBoxResult.Continue, MsgBoxResult.Stop, MsgBoxResult.Abort}},
        };
    }
}
