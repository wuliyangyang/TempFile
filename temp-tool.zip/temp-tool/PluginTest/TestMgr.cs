﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlcUtility;

namespace PluginTest
{
    public class TestMgr
    {
        public static void Test()
        {
            //PluginTest.GetInstance().Log("test");
            //PluginTest.GetInstance().SaveCsv("Test", "head", "aabb");
            AlcSystem.Instance.UserAuthorityChanged +=
                (oldAuthority, userAuthority) => AlcSystem.Instance.ShowMsgBox($"UserAuthority Changed to {userAuthority}, old Authority is {oldAuthority}", "Test");
            AlcSystem.Instance.FormShown +=
                formName =>
                {
                    Task.Run(() =>
                    {
                        if (formName == "Test")
                            AlcSystem.Instance.ShowMsgBox($"Form shown to {formName}", "Test");
                    });
                };
            AlcSystem.Instance.CanStart += () => "test plugin can't start";
            AlcSystem.Instance.CanStart += () => null;
            if(AlcSystem.Instance.GetUserAuthority() == UserAuthority.OPERATOR.ToString())
                AlcSystem.Instance.ShowMsgBox($"UserAuthority Set to {AlcSystem.Instance.GetUserAuthority()}", "Test");
        }
    }
}
