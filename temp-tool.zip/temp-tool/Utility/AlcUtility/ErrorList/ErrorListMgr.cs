﻿using LogLib;
using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Collections.Generic;

namespace AlcUtility
{
    public class ErrorListMgr
    {
        private static ErrorListMgr _instance = new ErrorListMgr();

        public static ErrorListMgr GetInstance()
        {
            return _instance;
        }

        private XElement errorListXml;
        private Dictionary<int, XElement> errorList = new Dictionary<int, XElement>();

        private ErrorListMgr()
        {
            init();
        }

        public string GetErrorElement(int errorCode, string element)
        {
            try
            {
                return errorList[errorCode].Element(element).Value;
            }
            catch (Exception ex)
            {
                Log.showMessageBox("Get Error Element Fail:\r\n" + ex.Message, "GetErrorElement", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return null;
            }
        }

        private void init()
        {
            loadXmlFile();

            try
            {
                foreach (XElement error in errorListXml.Descendants("Error"))
                {
                    errorList.Add(int.Parse(error.Attribute("code").Value), error);
                }
            }
            catch (Exception ex)
            {
                Log.showMessageBox("Can not Load ErrorList.xml file:\r\n" + ex.Message, "Load XML Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                Environment.Exit(ErrorCode.EC_XmlFormatErr);
            }
        }

        private void loadXmlFile()
        {
            string errorListPath = Application.StartupPath + "\\ErrorList.xml";
            if (!File.Exists(errorListPath))
            {
                Log.showMessageBox("Can not open ErrorList.xml file", "Load XML Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                Environment.Exit(ErrorCode.EC_XmlNotExist);
            }
            else
            {
                try
                {
                    errorListXml = XElement.Load(errorListPath);
                }
                catch (Exception ex)
                {
                    Log.showMessageBox("Can not Load ErrorList.xml file:\r\n" + ex.Message, "Load XML Error", MsgBoxButtons.OK, MsgBoxIcon.Error);
                    Environment.Exit(ErrorCode.EC_XmlFormatErr);
                }
            }
        }
    }
}
