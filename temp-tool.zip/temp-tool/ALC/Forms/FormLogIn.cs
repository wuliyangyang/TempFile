﻿using ALC.Managers;
using AlcUtility;
using LogLib;
using System;
using System.Windows.Forms;

namespace ALC.Forms
{
    public partial class FormLogIn : CustomForm
    {
        private string currentAuthority = UserAuthority.OPERATOR.ToString();

        public FormLogIn()
        {
            InitializeComponent();

            //init cbb_Authority
            var userAuthorityList = XmlHelper.GetInstance().UserAuthorityList;
            if (userAuthorityList.Count == 0)
                userAuthorityList.Add(UserAuthority.OPERATOR.ToString());
            foreach (string authority in userAuthorityList)
            {
                cbb_Authority.Items.Add(authority);
            }
            cbb_Authority.SelectedItem = userAuthorityList[0];
        }

        private void UpdateLableNameOrPassword()
        {
            if (currentAuthority.ToUpper() == UserAuthority.OPERATOR.ToString().ToUpper())
                lbl_NameOrPassword.Text = "Username:";
            else
                lbl_NameOrPassword.Text = "Password:";
        }

        private void frmLogIn_Load(object sender, EventArgs e)
        {

        }

        private void frmLogIn_Activated(object sender, EventArgs e)
        {
            txt_NameOrPassword.Focus();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            User user = new User()
            {
                authority = currentAuthority,
            };
            string password;
            if (currentAuthority.ToUpper() == UserAuthority.OPERATOR.ToString().ToUpper())
            {
                user.name = txt_NameOrPassword.Text;
                password = string.Empty;
            }
            else
            {
                user.name = string.Empty;
                password = txt_NameOrPassword.Text;
            }
            if(UserMgr.GetInstance().Login(user, password))
            {
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                Log.showMessageBox("Log in fail!", "LogIn", MsgBoxButtons.OK, MsgBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cbb_Authority_SelectedIndexChanged(object sender, EventArgs e)
        {
            string authority = (string)((ComboBox)sender).SelectedItem;
            if (authority == currentAuthority) return;
            currentAuthority = authority;
            UpdateLableNameOrPassword();
        }

        private void lbl_ChangePassword_Click(object sender, EventArgs e)
        {
            new FormChangePassword().ShowDialog();
        }
    }
}
