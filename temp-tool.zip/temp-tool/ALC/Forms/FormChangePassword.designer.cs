﻿namespace ALC.Forms
{
    partial class FormChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_NameOrPassword = new System.Windows.Forms.Label();
            this.txt_OldPassword = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbb_Authority = new System.Windows.Forms.ComboBox();
            this.txt_NewPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_RepeatNewPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(104, 59);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.TabIndex = 30;
            this.label1.Text = "Authority:";
            // 
            // lbl_NameOrPassword
            // 
            this.lbl_NameOrPassword.AutoSize = true;
            this.lbl_NameOrPassword.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_NameOrPassword.Location = new System.Drawing.Point(76, 116);
            this.lbl_NameOrPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_NameOrPassword.Name = "lbl_NameOrPassword";
            this.lbl_NameOrPassword.Size = new System.Drawing.Size(103, 20);
            this.lbl_NameOrPassword.TabIndex = 32;
            this.lbl_NameOrPassword.Text = "Old password:";
            // 
            // txt_OldPassword
            // 
            this.txt_OldPassword.Location = new System.Drawing.Point(194, 116);
            this.txt_OldPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txt_OldPassword.Name = "txt_OldPassword";
            this.txt_OldPassword.PasswordChar = '*';
            this.txt_OldPassword.Size = new System.Drawing.Size(152, 23);
            this.txt_OldPassword.TabIndex = 1;
            this.txt_OldPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(80, 292);
            this.btnOK.Margin = new System.Windows.Forms.Padding(2);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(87, 28);
            this.btnOK.TabIndex = 34;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(201, 292);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(87, 28);
            this.btnCancel.TabIndex = 35;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbb_Authority
            // 
            this.cbb_Authority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Authority.FormattingEnabled = true;
            this.cbb_Authority.Location = new System.Drawing.Point(194, 57);
            this.cbb_Authority.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cbb_Authority.Name = "cbb_Authority";
            this.cbb_Authority.Size = new System.Drawing.Size(152, 25);
            this.cbb_Authority.TabIndex = 39;
            // 
            // txt_NewPassword
            // 
            this.txt_NewPassword.Location = new System.Drawing.Point(194, 173);
            this.txt_NewPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txt_NewPassword.Name = "txt_NewPassword";
            this.txt_NewPassword.PasswordChar = '*';
            this.txt_NewPassword.Size = new System.Drawing.Size(152, 23);
            this.txt_NewPassword.TabIndex = 40;
            this.txt_NewPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(70, 173);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 41;
            this.label2.Text = "New password:";
            // 
            // txt_RepeatNewPassword
            // 
            this.txt_RepeatNewPassword.Location = new System.Drawing.Point(194, 230);
            this.txt_RepeatNewPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txt_RepeatNewPassword.Name = "txt_RepeatNewPassword";
            this.txt_RepeatNewPassword.PasswordChar = '*';
            this.txt_RepeatNewPassword.Size = new System.Drawing.Size(152, 23);
            this.txt_RepeatNewPassword.TabIndex = 42;
            this.txt_RepeatNewPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(21, 230);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 20);
            this.label3.TabIndex = 43;
            this.label3.Text = "Repeat new password:";
            // 
            // FormChangePassword
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 355);
            this.Controls.Add(this.txt_RepeatNewPassword);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_NewPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbb_Authority);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.txt_OldPassword);
            this.Controls.Add(this.lbl_NameOrPassword);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Title = "ChangePassword";
            this.TitleFont = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TitleImage = global::ALC.Properties.Resources.logo;
            this.TopMost = true;
            this.Activated += new System.EventHandler(this.frmLogIn_Activated);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.lbl_NameOrPassword, 0);
            this.Controls.SetChildIndex(this.txt_OldPassword, 0);
            this.Controls.SetChildIndex(this.btnOK, 0);
            this.Controls.SetChildIndex(this.btnCancel, 0);
            this.Controls.SetChildIndex(this.cbb_Authority, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.txt_NewPassword, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.txt_RepeatNewPassword, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_NameOrPassword;
        private System.Windows.Forms.TextBox txt_OldPassword;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbb_Authority;
        private System.Windows.Forms.TextBox txt_NewPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_RepeatNewPassword;
        private System.Windows.Forms.Label label3;
    }
}