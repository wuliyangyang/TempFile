﻿namespace ALC.Forms
{
    partial class FormLogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_NameOrPassword = new System.Windows.Forms.Label();
            this.txt_NameOrPassword = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbb_Authority = new System.Windows.Forms.ComboBox();
            this.lbl_ChangePassword = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(67, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.TabIndex = 30;
            this.label1.Text = "Authority:";
            // 
            // lbl_NameOrPassword
            // 
            this.lbl_NameOrPassword.AutoSize = true;
            this.lbl_NameOrPassword.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_NameOrPassword.Location = new System.Drawing.Point(67, 119);
            this.lbl_NameOrPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_NameOrPassword.Name = "lbl_NameOrPassword";
            this.lbl_NameOrPassword.Size = new System.Drawing.Size(79, 20);
            this.lbl_NameOrPassword.TabIndex = 32;
            this.lbl_NameOrPassword.Text = "Username:";
            // 
            // txt_NameOrPassword
            // 
            this.txt_NameOrPassword.Location = new System.Drawing.Point(167, 119);
            this.txt_NameOrPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txt_NameOrPassword.Name = "txt_NameOrPassword";
            this.txt_NameOrPassword.PasswordChar = '*';
            this.txt_NameOrPassword.Size = new System.Drawing.Size(152, 23);
            this.txt_NameOrPassword.TabIndex = 1;
            this.txt_NameOrPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(71, 186);
            this.btnOK.Margin = new System.Windows.Forms.Padding(2);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(87, 28);
            this.btnOK.TabIndex = 34;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(192, 186);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(87, 28);
            this.btnCancel.TabIndex = 35;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cbb_Authority
            // 
            this.cbb_Authority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Authority.FormattingEnabled = true;
            this.cbb_Authority.Location = new System.Drawing.Point(167, 57);
            this.cbb_Authority.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cbb_Authority.Name = "cbb_Authority";
            this.cbb_Authority.Size = new System.Drawing.Size(152, 25);
            this.cbb_Authority.TabIndex = 39;
            this.cbb_Authority.SelectedIndexChanged += new System.EventHandler(this.cbb_Authority_SelectedIndexChanged);
            // 
            // lbl_ChangePassword
            // 
            this.lbl_ChangePassword.AutoSize = true;
            this.lbl_ChangePassword.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbl_ChangePassword.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChangePassword.Location = new System.Drawing.Point(287, 227);
            this.lbl_ChangePassword.Name = "lbl_ChangePassword";
            this.lbl_ChangePassword.Size = new System.Drawing.Size(113, 17);
            this.lbl_ChangePassword.TabIndex = 40;
            this.lbl_ChangePassword.Text = "Change password";
            this.lbl_ChangePassword.Click += new System.EventHandler(this.lbl_ChangePassword_Click);
            // 
            // FormLogIn
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 253);
            this.Controls.Add(this.lbl_ChangePassword);
            this.Controls.Add(this.cbb_Authority);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.txt_NameOrPassword);
            this.Controls.Add(this.lbl_NameOrPassword);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormLogIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Title = "LogIn";
            this.TitleFont = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TitleImage = global::ALC.Properties.Resources.logo;
            this.TopMost = true;
            this.Activated += new System.EventHandler(this.frmLogIn_Activated);
            this.Load += new System.EventHandler(this.frmLogIn_Load);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.lbl_NameOrPassword, 0);
            this.Controls.SetChildIndex(this.txt_NameOrPassword, 0);
            this.Controls.SetChildIndex(this.btnOK, 0);
            this.Controls.SetChildIndex(this.btnCancel, 0);
            this.Controls.SetChildIndex(this.cbb_Authority, 0);
            this.Controls.SetChildIndex(this.lbl_ChangePassword, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_NameOrPassword;
        private System.Windows.Forms.TextBox txt_NameOrPassword;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbb_Authority;
        private System.Windows.Forms.Label lbl_ChangePassword;
    }
}