﻿namespace ALC.Forms
{
    partial class CustomForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomForm));
            this.pan_Title = new System.Windows.Forms.Panel();
            this.lbl_FrmTitle = new System.Windows.Forms.Label();
            this.pan_Ico = new System.Windows.Forms.Panel();
            this.btn_FrmMinimize = new System.Windows.Forms.Button();
            this.btn_FrmMaximum = new System.Windows.Forms.Button();
            this.btn_FrmClose = new System.Windows.Forms.Button();
            this.pan_Title.SuspendLayout();
            this.SuspendLayout();
            // 
            // pan_Title
            // 
            this.pan_Title.BackColor = System.Drawing.SystemColors.Control;
            this.pan_Title.Controls.Add(this.lbl_FrmTitle);
            this.pan_Title.Controls.Add(this.pan_Ico);
            this.pan_Title.Controls.Add(this.btn_FrmMinimize);
            this.pan_Title.Controls.Add(this.btn_FrmMaximum);
            this.pan_Title.Controls.Add(this.btn_FrmClose);
            this.pan_Title.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_Title.Location = new System.Drawing.Point(0, 0);
            this.pan_Title.Name = "pan_Title";
            this.pan_Title.Size = new System.Drawing.Size(870, 28);
            this.pan_Title.TabIndex = 29;
            this.pan_Title.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.Titlepanel_ControlAdded);
            this.pan_Title.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.Titlepanel_ControlRemoved);
            this.pan_Title.DoubleClick += new System.EventHandler(this.Titlepanel_DoubleClick);
            this.pan_Title.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Titlepanel_MouseDown);
            this.pan_Title.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Titlepanel_MouseMove);
            this.pan_Title.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Titlepanel_MouseUp);
            // 
            // lbl_FrmTitle
            // 
            this.lbl_FrmTitle.AutoSize = true;
            this.lbl_FrmTitle.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbl_FrmTitle.Font = new System.Drawing.Font("Segoe UI Symbol", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FrmTitle.Location = new System.Drawing.Point(79, 0);
            this.lbl_FrmTitle.Name = "lbl_FrmTitle";
            this.lbl_FrmTitle.Size = new System.Drawing.Size(0, 19);
            this.lbl_FrmTitle.TabIndex = 4;
            this.lbl_FrmTitle.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lbl_FrmTitle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbl_FrmTitle_MouseDown);
            this.lbl_FrmTitle.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lbl_FrmTitle_MouseMove);
            this.lbl_FrmTitle.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lbl_FrmTitle_MouseUp);
            // 
            // pan_Ico
            // 
            this.pan_Ico.BackgroundImage = global::ALC.Properties.Resources.logo;
            this.pan_Ico.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pan_Ico.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan_Ico.Location = new System.Drawing.Point(0, 0);
            this.pan_Ico.Name = "pan_Ico";
            this.pan_Ico.Size = new System.Drawing.Size(79, 28);
            this.pan_Ico.TabIndex = 3;
            // 
            // btn_FrmMinimize
            // 
            this.btn_FrmMinimize.BackgroundImage = global::ALC.Properties.Resources.top_minimize_normal;
            this.btn_FrmMinimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_FrmMinimize.Location = new System.Drawing.Point(786, 0);
            this.btn_FrmMinimize.Name = "btn_FrmMinimize";
            this.btn_FrmMinimize.Size = new System.Drawing.Size(28, 28);
            this.btn_FrmMinimize.TabIndex = 2;
            this.btn_FrmMinimize.Tag = "min";
            this.btn_FrmMinimize.UseVisualStyleBackColor = true;
            this.btn_FrmMinimize.Click += new System.EventHandler(this.Titlebutton_Click);
            // 
            // btn_FrmMaximum
            // 
            this.btn_FrmMaximum.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_FrmMaximum.Image = global::ALC.Properties.Resources.top_adaptive_normal;
            this.btn_FrmMaximum.Location = new System.Drawing.Point(814, 0);
            this.btn_FrmMaximum.Name = "btn_FrmMaximum";
            this.btn_FrmMaximum.Size = new System.Drawing.Size(28, 28);
            this.btn_FrmMaximum.TabIndex = 1;
            this.btn_FrmMaximum.Tag = "max";
            this.btn_FrmMaximum.UseVisualStyleBackColor = true;
            this.btn_FrmMaximum.Click += new System.EventHandler(this.Titlebutton_Click);
            // 
            // btn_FrmClose
            // 
            this.btn_FrmClose.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_FrmClose.Image = global::ALC.Properties.Resources.top_close_normal;
            this.btn_FrmClose.Location = new System.Drawing.Point(842, 0);
            this.btn_FrmClose.Name = "btn_FrmClose";
            this.btn_FrmClose.Size = new System.Drawing.Size(28, 28);
            this.btn_FrmClose.TabIndex = 0;
            this.btn_FrmClose.Tag = "close";
            this.btn_FrmClose.UseVisualStyleBackColor = true;
            this.btn_FrmClose.Click += new System.EventHandler(this.Titlebutton_Click);
            // 
            // CustomForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 432);
            this.ControlBox = false;
            this.Controls.Add(this.pan_Title);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CustomForm";
            this.pan_Title.ResumeLayout(false);
            this.pan_Title.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pan_Title;
        private System.Windows.Forms.Button btn_FrmMinimize;
        private System.Windows.Forms.Button btn_FrmMaximum;
        private System.Windows.Forms.Button btn_FrmClose;
        private System.Windows.Forms.Panel pan_Ico;
        private System.Windows.Forms.Label lbl_FrmTitle;
    }
}