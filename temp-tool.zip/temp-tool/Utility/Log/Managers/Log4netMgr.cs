﻿using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Core;
using log4net.Layout;
using log4net.Repository;
using log4net.Repository.Hierarchy;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace LogLib.Managers
{
    class Log4netMgr
    {
        public static Log4netMgr Instance { get; } = new Log4netMgr();
        RollingFileAppender defaultAppender;

        private Log4netMgr()
        {
            var appenders = LogManager.GetRepository().GetAppenders();
            defaultAppender = (RollingFileAppender)appenders.First((a) => a.Name == "RollingLogFileAppender");
        }

        private object logerCreateLocker = new object();
        private ConcurrentDictionary<string, ILog> loggers = new ConcurrentDictionary<string, ILog>();

        public void Log(string message, string fileName = null, int level = ErrorLevel.TRACE)
        {
            Task.Run(() =>
            {
                if (!string.IsNullOrEmpty(fileName))
                {
                    LogCustomFile(message, null, fileName, ".log", level);
                }
                var logger11 = LogManager.GetLogger(fileName ?? "");
                Log(message, level, LogManager.GetLogger(fileName ?? ""));
            });
        }

        public void SaveSCV(string fileName, string msg, string headString, bool addTime = true)
        {
            headString = string.IsNullOrEmpty(headString) ? "Discription" : headString;
            if (addTime)
            {
                headString = "Time," + headString;
                msg = DateTime.Now.ToString("HH:mm:ss") + "," + msg;
            }

            string extension = ".csv";
            string loggerKey = fileName + extension;
            if (!loggers.ContainsKey(loggerKey))
            {
                lock (logerCreateLocker)
                {
                    if (!loggers.ContainsKey(loggerKey))
                    {
                        CreateLogger(fileName, extension, "%m%n");
                    }
                }
            }

            RollingFileAppender appender = (RollingFileAppender)((Logger)((LogImpl)loggers[loggerKey]).Logger).Parent.Appenders[0];

            if (!File.Exists(appender.File))
            {
                Log(headString, 0, loggers[loggerKey]);
            }
            else
            {
                FileInfo fileInfo = new FileInfo(appender.File);
                if (fileInfo.Length == 0) Log(headString, 0, loggers[loggerKey]);
            }

            Log(msg, 0, loggers[loggerKey]);
        }

        private void LogCustomFile(string message, string conversionPattern, string fileName, string extension, int level)
        {
            string loggerKey = fileName + extension;
            if (!loggers.ContainsKey(loggerKey))
            {
                lock (logerCreateLocker)
                {
                    if (!loggers.ContainsKey(loggerKey))
                    {
                        CreateLogger(fileName, extension, conversionPattern);
                    }
                }
            }

            Log(message, level, loggers[loggerKey]);
        }

        private void CreateLogger(string logName, string extension, string conversionPattern)
        {
            RollingFileAppender appender = defaultAppender;

            string path = appender.File;
            path = path.Replace('\\', '/');
            var sl = appender.DatePattern.Split('\\', '/');
            for (int i = 0; i < sl.Count(); i++)
            {
                int index = path.LastIndexOf('/');
                path = path.Remove(index);
            }
            path += "/";

            string datePattern = appender.DatePattern.Replace('\\', '/');
            datePattern = datePattern.Remove(datePattern.LastIndexOf('/') + 1);
            datePattern += $"'{logName}_'yyyyMMdd\"{extension}\"";

            RollingFileAppender rollingFileAppender = new RollingFileAppender()
            {
                LockingModel = new FileAppender.MinimalLock(),
                File = path,
                AppendToFile = appender.AppendToFile,
                StaticLogFileName = appender.StaticLogFileName,
                DatePattern = datePattern,
                RollingStyle = appender.RollingStyle,
                Layout = new PatternLayout(conversionPattern ?? ((PatternLayout)appender.Layout).ConversionPattern),
            };
            rollingFileAppender.ActivateOptions();
            ILoggerRepository repository = LogManager.CreateRepository(logName + "Repository");
            BasicConfigurator.Configure(repository, rollingFileAppender);
            ILog logger = LogManager.GetLogger(repository.Name, logName);

            loggers.AddOrUpdate(logName + extension, logger, (k, v) => logger);
        }

        private void Log(string message, int level, ILog logger)
        {
            switch (level)
            {
                case ErrorLevel.DEBUG:
                    logger.Debug(message);
                    break;
                case ErrorLevel.TRACE:
                    logger.Info(message);
                    break;
                case ErrorLevel.WARN:
                    logger.Warn(message);
                    break;
                case ErrorLevel.ERROR:
                    logger.Error(message);
                    break;
                case ErrorLevel.FATAL:
                    logger.Fatal(message);
                    break;
            }
        }
    }
}
