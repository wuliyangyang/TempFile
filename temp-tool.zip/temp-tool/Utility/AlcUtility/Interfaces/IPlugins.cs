﻿using System;
using System.Collections.Generic;

namespace AlcUtility
{
    public interface IPlugins
    {
        /// <summary>
        /// Regist and Provide functions
        /// </summary>
        /// <param name="sendmessage">for sending messages to the network server.</param>
        /// <param name="broadcast">for sending messages to the module which subscribes it.</param>
        /// <param name="pluginOperate">for doing something that depends on the platform. Please refer to PluginOperateItem for details.</param>
        /// <returns>Module Name, List of interested modules.</returns>
        Tuple<string, List<string>> Register(
           Action<ReceivedData> sendmessage,
           Action<string, ReceivedData> broadcast);

        //Hander Messages
        void MessageHandler(ReceivedData data);

        //Shown in the UI. If no need to, return null
        System.Windows.Forms.Form GetForm();
        System.Windows.Forms.UserControl GetControl();
        System.Windows.Forms.UserControl GetConfigView();


        //----------------------------------------------------------------------------
        //---All the interface below, if no need to, just do nothing but return true.
        bool Load();

        bool Initialize();
        bool Start();
        bool Stop();
        bool Pause();
        bool Resume();
        bool Reset();
        bool Abort();

        bool Dispose();
    }
}
