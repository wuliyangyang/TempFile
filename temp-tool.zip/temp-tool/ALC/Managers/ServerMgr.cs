﻿using AlcUtility;
using NetAndEvent.SocketServer;

namespace ALC.Managers
{
    public class ServerMgr
    {
        private static ServerMgr _instance = new ServerMgr();
        public static ServerMgr GetInstance()
        {
            return _instance;
        }
        
        private StringServer _stringSrv;
        private CRStringServer _CRstringSrv;
        private BinaryServer _binarySrv;
        private ServerMgr()
        {
            if (XmlHelper.GetInstance().StringServerPort > 0)
                _stringSrv = new StringServer(XmlHelper.GetInstance().StringServerPort);
            if (XmlHelper.GetInstance().BinaryServerPort > 0)
                _binarySrv = new BinaryServer(XmlHelper.GetInstance().BinaryServerPort);
            if (XmlHelper.GetInstance().CRStringServerPort > 0)
                _CRstringSrv = new CRStringServer(XmlHelper.GetInstance().CRStringServerPort);

        }

        public void StartServers()
        {
            if (_stringSrv != null)
                _stringSrv.StartServer();
            if (_binarySrv != null)
                _binarySrv.StartServer();
            if (_CRstringSrv != null)
                _CRstringSrv.StartServer();
        }

        public void SendMessage(ReceivedData data)
        {
            if (_binarySrv != null && data.binaryData != null)
            {
                _binarySrv.sendMessage(data.moduleId, data.binaryData);
            }
            if (_stringSrv != null && data.strData != null)
            {
                _stringSrv.sendMessage(data.moduleId, data.strData);
            }
        }
    }
}
