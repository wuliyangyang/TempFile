﻿using System.Windows.Forms;
using LogLib.Managers;
using LogLib.Forms;

namespace LogLib
{
    public class ErrorLevel
    {
        public const int DEBUG = 0;
        public const int TRACE = 1;
        public const int WARN = 2;
        public const int ERROR = 3;
        public const int FATAL = 4;
    }

    public class Log
    {
        private static Log4netMgr _logFileMgr = Log4netMgr.Instance;
        private static FormLogWindow _formLogWindow = FormLogWindow.getInstance();
        
        private static void writeLogFile(string msg, int errorLevel, string logName)
        {
            if (logName == "ALL") logName = null;
            _logFileMgr.Log(msg, logName, errorLevel);
        }

        public static void saveCsv(string csvName, string msg, string head = null, bool addTime = true)
        {
            _logFileMgr.SaveSCV(csvName, msg, head, addTime);
        }

        public static Form getFormLogWindow()
        {
            return _formLogWindow;
        }

        public static void addABoxToLogWindow(string title)
        {
            _formLogWindow.addALogTab(title);
        }

        public static void writeLog(string msg, int errorLevel = ErrorLevel.TRACE, string moduleOrFileName = null)
        {
            if (moduleOrFileName != null)
            {
                _formLogWindow.writeLog(moduleOrFileName, msg, errorLevel);
            }
            writeLogFile(msg, errorLevel, moduleOrFileName);
        }

        public static MsgBoxResult showMessageBox(string text, string caption, MsgBoxButtons buttons, MsgBoxIcon icon, MsgBoxDefaultButton defaultbutton = MsgBoxDefaultButton.Button1)
        {
            string message = string.Format("\r\ncaption: {0}\r\n{1}\r\nbutton: {2}; icon: {3}", caption, text, buttons.ToString(), icon.ToString());
            writeLogFile(message, ErrorLevel.TRACE, "msgBox");
            var msgBox = new FormMsgBox(text, caption, buttons, icon, defaultbutton);
            MsgBoxResult result = msgBox.show();
            writeLogFile(string.Format("\r\nmessage result: {0}\r\nmessage: {1}", result.ToString(), message), ErrorLevel.TRACE, "msgBox");
            return result;
        }
    }
}
