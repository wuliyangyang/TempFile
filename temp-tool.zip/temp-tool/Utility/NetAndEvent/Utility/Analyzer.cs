﻿using System;
using System.Text;
using NetAndEvent.SocketServer;
using System.Diagnostics;
using AlcUtility;

namespace NetAndEvent.Utility
{
    public class Analyzer
    {
        public const int INT_LEN = 4;
        public const int FLOAT_LEN = 4;
        public const string KEY_MESSAGE_LENGTH = "MESSAGE_LENGTH";
        public static int MESSAGE_LENGTH
        {
            get
            {
                try
                {
                    return int.Parse(System.Configuration.ConfigurationManager.AppSettings[KEY_MESSAGE_LENGTH]);
                }
                catch
                {
                    return 32;
                }
            }

            private set { }
        }

        static Analyzer()
        {
            try
            {
                MESSAGE_LENGTH = int.Parse(System.Configuration.ConfigurationManager.AppSettings[KEY_MESSAGE_LENGTH]);
            }
            catch
            {
                MESSAGE_LENGTH = 32;
            }
        }
    }

    public class BinaryAnalyzer : Analyzer
    {
        public static BinaryData Analyze(byte[] data)
        {
            //check the length
            if (data.Length != PLCBinaryFilter.FixedSize)
            {
                Debug.WriteLine("Error! Received Data Length Wrong!");
                return null;
            }

            int offset = 0;

            //4 int, 5 float
            int[] cmds = new int[3];
            float[] pars = new float[5];
            for (int i = 0; i < 3; i++)
            {
                byte[] iData = new byte[INT_LEN];
                Buffer.BlockCopy(data, offset, iData, 0, INT_LEN);
                offset += INT_LEN;
                cmds[i] = BitConverter.ToInt32(iData, 0);
            }
            for (int i = 0; i < 5; i++)
            {
                byte[] fData = new byte[FLOAT_LEN];
                Buffer.BlockCopy(data, offset, fData, 0, FLOAT_LEN);
                offset += FLOAT_LEN;
                pars[i] = BitConverter.ToSingle(fData, 0);
            }

            //error code
            Int64 errcode = 0;
            for (int i = 3; i < 4; i++)
            {
                byte[] iData = new byte[INT_LEN * 2];
                Buffer.BlockCopy(data, offset, iData, 0, INT_LEN * 2);
                offset += (INT_LEN * 2);
                errcode = BitConverter.ToInt64(iData, 0);
            }

            //32 byte string
            byte[] bmsg = new byte[MESSAGE_LENGTH];
            Buffer.BlockCopy(data, offset, bmsg, 0, MESSAGE_LENGTH);
            offset += MESSAGE_LENGTH;
            string strmsg = Encoding.ASCII.GetString(bmsg);


            return new BinaryData()
            {
                channelId = cmds[0],
                msgType = cmds[1],
                commandId = cmds[2],
                param1 = pars[0],
                param2 = pars[1],
                param3 = pars[2],
                param4 = pars[3],
                param5 = pars[4],
                errorcode = errcode,
                strMessage = strmsg
            };
        }

        public static byte[] BinaryDataToByte(BinaryData data)
        {
            byte[] res = new byte[PLCBinaryFilter.FixedSize];

            byte[] cnl = BitConverter.GetBytes(data.channelId);
            byte[] mtp = BitConverter.GetBytes(data.msgType);
            byte[] cmd = BitConverter.GetBytes(data.commandId);
            byte[] p1 = BitConverter.GetBytes(data.param1);
            byte[] p2 = BitConverter.GetBytes(data.param2);
            byte[] p3 = BitConverter.GetBytes(data.param3);
            byte[] p4 = BitConverter.GetBytes(data.param4);
            byte[] p5 = BitConverter.GetBytes(data.param5);
            byte[] err = BitConverter.GetBytes(data.errorcode);
            byte[] bc;
            if (!string.IsNullOrEmpty(data.strMessage))
            {
                bc = Encoding.ASCII.GetBytes(data.strMessage);
            }
            else
            {
                bc = new byte[MESSAGE_LENGTH];
            }

            Buffer.BlockCopy(cnl, 0, res, 0, INT_LEN);
            Buffer.BlockCopy(mtp, 0, res, INT_LEN * 1, INT_LEN);
            Buffer.BlockCopy(cmd, 0, res, INT_LEN * 2, INT_LEN);
            Buffer.BlockCopy(p1, 0, res, INT_LEN * 3, INT_LEN);
            Buffer.BlockCopy(p2, 0, res, INT_LEN * 4, INT_LEN);
            Buffer.BlockCopy(p3, 0, res, INT_LEN * 5, INT_LEN);
            Buffer.BlockCopy(p4, 0, res, INT_LEN * 6, INT_LEN);
            Buffer.BlockCopy(p5, 0, res, INT_LEN * 7, INT_LEN);
            Buffer.BlockCopy(err, 0, res, INT_LEN * 8, INT_LEN * 2);
            Buffer.BlockCopy(bc, 0, res, INT_LEN * 10, bc.Length < MESSAGE_LENGTH ? bc.Length : MESSAGE_LENGTH);

            return res;
        }
    }
}
