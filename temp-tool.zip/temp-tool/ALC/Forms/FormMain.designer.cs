﻿namespace ALC.Forms
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.tvHome = new System.Windows.Forms.TreeView();
            this.tvConfig = new System.Windows.Forms.TreeView();
            this.imageListSmall = new System.Windows.Forms.ImageList(this.components);
            this.imageListLarge = new System.Windows.Forms.ImageList(this.components);
            this.vS2005Theme = new WeifenLuo.WinFormsUI.Docking.VS2005Theme();
            this.vS2015Theme = new WeifenLuo.WinFormsUI.Docking.VS2015LightTheme();
            this.stBar = new System.Windows.Forms.StatusStrip();
            this.stBar_System = new System.Windows.Forms.ToolStripStatusLabel();
            this.stBar_Monitor = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblSysTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.stBar_Progress = new System.Windows.Forms.ToolStripProgressBar();
            this.stBar_Status = new System.Windows.Forms.ToolStripStatusLabel();
            this.Admin = new System.Windows.Forms.ToolStripStatusLabel();
            this.funcBar = new Guifreaks.Navisuite.NaviBar(this.components);
            this.band_Config = new Guifreaks.Navisuite.NaviBand(this.components);
            this.band_Home = new Guifreaks.Navisuite.NaviBand(this.components);
            this.panUI = new System.Windows.Forms.Panel();
            this.dockPanel = new WeifenLuo.WinFormsUI.Docking.DockPanel();
            this.SysTimer1 = new System.Windows.Forms.Timer(this.components);
            this.stBar.SuspendLayout();
            this.funcBar.SuspendLayout();
            this.band_Config.SuspendLayout();
            this.band_Home.SuspendLayout();
            this.panUI.SuspendLayout();
            this.SuspendLayout();
            // 
            // tvHome
            // 
            this.tvHome.LineColor = System.Drawing.Color.Empty;
            this.tvHome.Location = new System.Drawing.Point(0, 0);
            this.tvHome.Name = "tvHome";
            this.tvHome.Size = new System.Drawing.Size(121, 97);
            this.tvHome.TabIndex = 0;
            // 
            // tvConfig
            // 
            this.tvConfig.LineColor = System.Drawing.Color.Empty;
            this.tvConfig.Location = new System.Drawing.Point(0, 0);
            this.tvConfig.Name = "tvConfig";
            this.tvConfig.Size = new System.Drawing.Size(121, 97);
            this.tvConfig.TabIndex = 0;
            // 
            // imageListSmall
            // 
            this.imageListSmall.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListSmall.ImageStream")));
            this.imageListSmall.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListSmall.Images.SetKeyName(0, "go-home-5.png");
            this.imageListSmall.Images.SetKeyName(1, "daemons.png");
            this.imageListSmall.Images.SetKeyName(2, "Trilian_Pro_014.png");
            this.imageListSmall.Images.SetKeyName(3, "smserver.png");
            this.imageListSmall.Images.SetKeyName(4, "kchart.png");
            this.imageListSmall.Images.SetKeyName(5, "file-manager.png");
            this.imageListSmall.Images.SetKeyName(6, "tray.png");
            this.imageListSmall.Images.SetKeyName(7, "camera.png");
            this.imageListSmall.Images.SetKeyName(8, "robot.png");
            // 
            // imageListLarge
            // 
            this.imageListLarge.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListLarge.ImageStream")));
            this.imageListLarge.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListLarge.Images.SetKeyName(0, "agt_home.png");
            this.imageListLarge.Images.SetKeyName(1, "file-manager.png");
            this.imageListLarge.Images.SetKeyName(2, "my_documents.png");
            this.imageListLarge.Images.SetKeyName(3, "onebit_01.png");
            this.imageListLarge.Images.SetKeyName(4, "onebit_02.png");
            this.imageListLarge.Images.SetKeyName(5, "onebit_03.png");
            this.imageListLarge.Images.SetKeyName(6, "onebit_04.png");
            this.imageListLarge.Images.SetKeyName(7, "onebit_06.png");
            this.imageListLarge.Images.SetKeyName(8, "Trilian_Pro_014.png");
            // 
            // stBar
            // 
            this.stBar.AutoSize = false;
            this.stBar.BackColor = System.Drawing.SystemColors.Control;
            this.stBar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.stBar.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.stBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stBar_System,
            this.stBar_Monitor,
            this.lblSysTime,
            this.stBar_Progress,
            this.stBar_Status,
            this.Admin});
            this.stBar.Location = new System.Drawing.Point(0, 526);
            this.stBar.Name = "stBar";
            this.stBar.Padding = new System.Windows.Forms.Padding(1, 0, 25, 0);
            this.stBar.Size = new System.Drawing.Size(872, 21);
            this.stBar.TabIndex = 63;
            // 
            // stBar_System
            // 
            this.stBar_System.AutoSize = false;
            this.stBar_System.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.stBar_System.Name = "stBar_System";
            this.stBar_System.Size = new System.Drawing.Size(250, 16);
            this.stBar_System.Text = "System Status";
            this.stBar_System.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // stBar_Monitor
            // 
            this.stBar_Monitor.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.stBar_Monitor.Name = "stBar_Monitor";
            this.stBar_Monitor.Size = new System.Drawing.Size(267, 16);
            this.stBar_Monitor.Spring = true;
            this.stBar_Monitor.Text = "Monitor";
            this.stBar_Monitor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSysTime
            // 
            this.lblSysTime.Name = "lblSysTime";
            this.lblSysTime.Size = new System.Drawing.Size(55, 16);
            this.lblSysTime.Text = "SysTime";
            // 
            // stBar_Progress
            // 
            this.stBar_Progress.BackColor = System.Drawing.SystemColors.Control;
            this.stBar_Progress.Name = "stBar_Progress";
            this.stBar_Progress.Size = new System.Drawing.Size(190, 15);
            this.stBar_Progress.Value = 50;
            // 
            // stBar_Status
            // 
            this.stBar_Status.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.stBar_Status.Name = "stBar_Status";
            this.stBar_Status.Size = new System.Drawing.Size(58, 16);
            this.stBar_Status.Text = "Account";
            this.stBar_Status.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.stBar_Status.Click += new System.EventHandler(this.stBar_Status_Click);
            // 
            // Admin
            // 
            this.Admin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Admin.Image = global::ALC.Properties.Resources.Login_Manager;
            this.Admin.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Admin.Name = "Admin";
            this.Admin.Size = new System.Drawing.Size(24, 16);
            // 
            // funcBar
            // 
            this.funcBar.ActiveBand = this.band_Home;
            this.funcBar.BackColor = System.Drawing.Color.Black;
            this.funcBar.Controls.Add(this.band_Home);
            this.funcBar.Controls.Add(this.band_Config);
            this.funcBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.funcBar.LargeImages = this.imageListSmall;
            this.funcBar.LayoutStyle = Guifreaks.Navisuite.NaviLayoutStyle.Office2010Silver;
            this.funcBar.Location = new System.Drawing.Point(0, 28);
            this.funcBar.Margin = new System.Windows.Forms.Padding(1);
            this.funcBar.Name = "funcBar";
            this.funcBar.ShowMoreOptionsButton = false;
            this.funcBar.Size = new System.Drawing.Size(136, 498);
            this.funcBar.TabIndex = 64;
            this.funcBar.VisibleLargeButtons = 10;
            this.funcBar.ActiveBandChanged += new System.EventHandler(this.funcBar_ActiveBandChanged);
            // 
            // band_Config
            // 
            // 
            // band_Config.ClientArea
            // 
            this.band_Config.ClientArea.LayoutStyle = Guifreaks.Navisuite.NaviLayoutStyle.StyleFromOwner;
            this.band_Config.ClientArea.Location = new System.Drawing.Point(0, 0);
            this.band_Config.ClientArea.Margin = new System.Windows.Forms.Padding(1);
            this.band_Config.ClientArea.Name = "ClientArea";
            this.band_Config.ClientArea.Size = new System.Drawing.Size(1, 1);
            this.band_Config.ClientArea.TabIndex = 0;
            this.band_Config.LargeImageIndex = 2;
            this.band_Config.LayoutStyle = Guifreaks.Navisuite.NaviLayoutStyle.StyleFromOwner;
            this.band_Config.Location = new System.Drawing.Point(1, 27);
            this.band_Config.Margin = new System.Windows.Forms.Padding(1);
            this.band_Config.Name = "band_Config";
            this.band_Config.Size = new System.Drawing.Size(0, 0);
            this.band_Config.SmallImage = ((System.Drawing.Image)(resources.GetObject("band_Config.SmallImage")));
            this.band_Config.SmallImageIndex = 0;
            this.band_Config.TabIndex = 12;
            this.band_Config.Text = "Configuration";
            this.band_Config.Click += new System.EventHandler(this.band_Config_Click);
            // 
            // band_Home
            // 
            // 
            // band_Home.ClientArea
            // 
            this.band_Home.ClientArea.BackColor = System.Drawing.Color.Black;
            this.band_Home.ClientArea.LayoutStyle = Guifreaks.Navisuite.NaviLayoutStyle.StyleFromOwner;
            this.band_Home.ClientArea.Location = new System.Drawing.Point(0, 0);
            this.band_Home.ClientArea.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.band_Home.ClientArea.Name = "ClientArea";
            this.band_Home.ClientArea.Size = new System.Drawing.Size(134, 369);
            this.band_Home.ClientArea.TabIndex = 0;
            this.band_Home.LargeImageIndex = 0;
            this.band_Home.LayoutStyle = Guifreaks.Navisuite.NaviLayoutStyle.StyleFromOwner;
            this.band_Home.Location = new System.Drawing.Point(1, 27);
            this.band_Home.Margin = new System.Windows.Forms.Padding(1);
            this.band_Home.Name = "band_Home";
            this.band_Home.Size = new System.Drawing.Size(134, 369);
            this.band_Home.SmallImage = ((System.Drawing.Image)(resources.GetObject("band_Home.SmallImage")));
            this.band_Home.SmallImageIndex = 0;
            this.band_Home.TabIndex = 8;
            this.band_Home.Text = "Home";
            this.band_Home.Click += new System.EventHandler(this.band_Home_Click);
            // 
            // panUI
            // 
            this.panUI.Controls.Add(this.dockPanel);
            this.panUI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panUI.Location = new System.Drawing.Point(136, 28);
            this.panUI.Margin = new System.Windows.Forms.Padding(1);
            this.panUI.Name = "panUI";
            this.panUI.Size = new System.Drawing.Size(736, 498);
            this.panUI.TabIndex = 65;
            // 
            // dockPanel
            // 
            this.dockPanel.AutoSize = true;
            this.dockPanel.BackColor = System.Drawing.SystemColors.Control;
            this.dockPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockPanel.DockBackColor = System.Drawing.SystemColors.Control;
            this.dockPanel.DocumentStyle = WeifenLuo.WinFormsUI.Docking.DocumentStyle.DockingWindow;
            this.dockPanel.Location = new System.Drawing.Point(0, 0);
            this.dockPanel.Margin = new System.Windows.Forms.Padding(1);
            this.dockPanel.Name = "dockPanel";
            this.dockPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dockPanel.RightToLeftLayout = true;
            this.dockPanel.Size = new System.Drawing.Size(736, 498);
            this.dockPanel.SupportDeeplyNestedContent = true;
            this.dockPanel.TabIndex = 63;
            // 
            // SysTimer1
            // 
            this.SysTimer1.Interval = 1000;
            this.SysTimer1.Tick += new System.EventHandler(this.SysTimer1_Tick);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 547);
            this.Controls.Add(this.panUI);
            this.Controls.Add(this.funcBar);
            this.Controls.Add(this.stBar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(3);
            this.Name = "FormMain";
            this.Title = "Assembly Line Controller";
            this.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.SizeChanged += new System.EventHandler(this.frmMain_SizeChanged);
            this.Controls.SetChildIndex(this.stBar, 0);
            this.Controls.SetChildIndex(this.funcBar, 0);
            this.Controls.SetChildIndex(this.panUI, 0);
            this.stBar.ResumeLayout(false);
            this.stBar.PerformLayout();
            this.funcBar.ResumeLayout(false);
            this.band_Config.ResumeLayout(false);
            this.band_Home.ResumeLayout(false);
            this.panUI.ResumeLayout(false);
            this.panUI.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView tvHome;
        private System.Windows.Forms.TreeView tvConfig;
        private System.Windows.Forms.ImageList imageListSmall;
        private System.Windows.Forms.ImageList imageListLarge;
        private WeifenLuo.WinFormsUI.Docking.VS2005Theme vS2005Theme;
        private WeifenLuo.WinFormsUI.Docking.VS2015LightTheme vS2015Theme;
        private System.Windows.Forms.StatusStrip stBar;
        private System.Windows.Forms.ToolStripStatusLabel stBar_System;
        private System.Windows.Forms.ToolStripStatusLabel stBar_Monitor;
        private System.Windows.Forms.ToolStripProgressBar stBar_Progress;
        private System.Windows.Forms.ToolStripStatusLabel stBar_Status;
        private System.Windows.Forms.ToolStripStatusLabel Admin;
        private Guifreaks.Navisuite.NaviBar funcBar;
        private Guifreaks.Navisuite.NaviBand band_Home;
        private Guifreaks.Navisuite.NaviBand band_Config;
        private System.Windows.Forms.Panel panUI;
        private WeifenLuo.WinFormsUI.Docking.DockPanel dockPanel;
        private System.Windows.Forms.ToolStripStatusLabel lblSysTime;
        private System.Windows.Forms.Timer SysTimer1;

    }
}