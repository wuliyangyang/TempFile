﻿namespace AlcUtility
{
    public enum PluginOperateItem
    {
        UpdateModuleStatus,
        WriteLog,
        ShowMsgBox,
        SaveCsv,
        Error,
        GetSystemStatus,
        GetMode,
        GetUser,
        ButtonClickRequire,
        GetSoftwareVersion,
    }

    /// <summary>
    /// UpdateModuleStatus操作时需要传入的结构
    /// </summary>
    public class UpdateModuleStatusParam
    {
        /// <summary>
        /// 要更新状态模块的类型。（必填）
        /// </summary>
        public string moduleType { set; get; }
        /// <summary>
        /// 模块的状态，true表示模块连接上，false表示未连接上。（必填）
        /// </summary>
        public bool alive { set; get; }
    }

    /// <summary>
    /// Error操作时需要传入的结构
    /// </summary>
    public class ErrorParam
    {
        /// <summary>
        /// 发生错误的模块类型。（必填）
        /// </summary>
        public string moduleType { set; get; }
        /// <summary>
        /// 错误代号。（必填)
        /// </summary>
        public long errorCode { set; get; }
        /// <summary>
        /// 错误等级。（可缺省，缺省值为DEBUG）
        /// </summary>
        public AlcErrorLevel errorLevel { set; get; }
        /// <summary>
        /// 报错信息。（必填）
        /// </summary>
        public string errorMsg { set; get; }
    }

    /// <summary>
    /// WriteLog操作时需要传入的结构
    /// </summary>
    public class WriteLogParam
    {
        /// <summary>
        /// 要写入日志的内容。（必填）
        /// </summary>
        public string message { set; get; }
        /// <summary>
        /// 错误等级，根据不同的等级会存入对应的日志中。（可缺省，缺省值为DEBUG）
        /// </summary>
        public AlcErrorLevel errorLevel { set; get; }
        /// <summary>
        /// 模块名或要存入的文件名。（可缺省，缺省值为"ALL"）
        /// </summary>
        public string moduleOrFileName { set; get; }
    }

    /// <summary>
    /// SaveCsv操作时需要传入的结构
    /// </summary>
    public class SaveCsvParam
    { 
        /// <summary>
        /// csv文件名。（必填）
        /// </summary>
        public string csvName {set; get;}
        /// <summary>
        /// csv表头，各项之间用逗号隔开。（必填）
        /// </summary>
        public string head { set; get; }
        /// <summary>
        /// 要写入csv的内容，各项之间用逗号隔开，必须与表头项数匹配。（必填）
        /// </summary>
        public string msg {set; get;}
        /// <summary>
        /// 是否在首列写入插入时间
        /// </summary>
        public bool addTime { set; get; }
    }

    /// <summary>
    /// ShowMsgBox操作时需要传入的结构
    /// </summary>
    public class ShowMsgBoxParam
    {
        /// <summary>
        /// 要弹框提示的内容。（必填）
        /// </summary>
        public string text {set; get;}
        /// <summary>
        /// 弹框标题。（可缺省，缺省值为"ALC"）
        /// </summary>
        public string caption {set; get;}
        /// <summary>
        /// 弹框提示可选按钮。（可缺省，缺省值为OK）
        /// </summary>
        public AlcMsgBoxButtons buttons {set; get;}
        /// <summary>
        /// 弹框主题图片。（可缺省，缺省值为None）
        /// </summary>
        public AlcMsgBoxIcon icon {set; get;}
        /// <summary>
        /// 弹框默认选中按钮。（可缺省，缺省值为Button1）
        /// </summary>
        public AlcMsgBoxDefaultButton defaultbutton { set; get; }
    }

    /// <summary>
    /// ButtonClickRequire操作时需要传入的结构
    /// </summary>
    public class ButtonClickRequireParam
    {
        /// <summary>
        /// 想要触发的按钮
        /// </summary>
        public ButtonsName button { set; get; }
    }
}
