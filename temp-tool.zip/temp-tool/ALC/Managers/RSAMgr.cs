﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace ALC.Managers
{
    public class RSAMgr
    {
        private static RSAMgr _instance = new RSAMgr();

        public static RSAMgr GetInstance()
        {
            return _instance;
        }

        private RSAMgr()
        {

        }
        
        // RSA 密钥对
        private const string RSAPublicKey = "<RSAKeyValue><Modulus>zddYQHKvE55w7KDHc8bNgcaKxpE+g/8lP7TTDf761K7FOL30wroGoy1E3jLAFkI6+fQn+Rp9xlGKn0yxud8wirZuob+8KlmcglZWmsmLdOl/OpwJWu2XpugPdCra1oNgf76bA8LOCIk+HyDq63j3+kI48JuHZIEf/ktSLa4Yg8M=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
        private const string RSAPriviteKey = "<RSAKeyValue><Modulus>zddYQHKvE55w7KDHc8bNgcaKxpE+g/8lP7TTDf761K7FOL30wroGoy1E3jLAFkI6+fQn+Rp9xlGKn0yxud8wirZuob+8KlmcglZWmsmLdOl/OpwJWu2XpugPdCra1oNgf76bA8LOCIk+HyDq63j3+kI48JuHZIEf/ktSLa4Yg8M=</Modulus><Exponent>AQAB</Exponent><P>9Lt4oeHz50xbNveG0jsIaQRPncTv83Q/kWFwW8734SI4m1xQ9cQaNRyn8W2YLlSZGFzEf0LXpCcXjif4fOPf6Q==</P><Q>11F8FXYV/aX4k9fHLSa7ZnM1ngMMdQb+gxPCLRARafkVepzenG8z1XuIA8f5zT/tqDEAS3Akau6c+mmBD2KGyw==</Q><DP>7zh1QV/5pwUHQGKSQdt8bBLPtDs2BbaDEJu7VbKosENgK9UAOkvXBkWdkCv9joQZJiw/0tnGqemgZ8+AYKvqSQ==</DP><DQ>PNfav1nB9w3qQySrNLgIJngRw5fK8lrKmpF/wioTMaXgCui/AudtdzrUAXWFwhj5eBh4o9iJgenxU9VyUb2epw==</DQ><InverseQ>mRz6vqD5I/M1HeA0Ckhcl8eJHJoHKpcv2/kOqkewXDBgjNlESrGyvfrpXC6m/4dv2E4gjyiMnoxSGrKam1VepA==</InverseQ><D>EBC9n5IT3gkgsSc/Seb7RSS00hil83Fne9hmHJKJCy500B/rSYNxXyz6UglN+q7CoZ2PvR53MJJOqm429NXZmOYKJ5IfFnVkjutu7OxeYqcwcNSJZZIoDHpvcK3u1C6PH/gUYVZFzUZzNv6HUeu6Zlp5fJr46Qn1iZo8phJ5rrE=</D></RSAKeyValue>";

        /// <summary>
        /// 使用RSA实现加密
        /// </summary>
        /// <param name="data">加密数据</param>
        /// <returns></returns>
        public string RSAEncrypt(string data)
        {
            RSACryptoServiceProvider rsaPublic = new RSACryptoServiceProvider();
            rsaPublic.FromXmlString(RSAPublicKey);

            byte[] publicValue = rsaPublic.Encrypt(Encoding.UTF8.GetBytes(data), false);
            return Convert.ToBase64String(publicValue);
        }

        /// <summary>
        /// 使用RSA实现解密
        /// </summary>
        /// <param name="data">加密数据</param>
        /// <returns></returns>
        public string RSADecrypt(string data)
        {
            RSACryptoServiceProvider rsaPublic = new RSACryptoServiceProvider();
            rsaPublic.FromXmlString(RSAPriviteKey);

            byte[] privateValue = rsaPublic.Decrypt(Convert.FromBase64String(data), false);
            return Encoding.UTF8.GetString(privateValue);
        }

        public byte[] RSAEncryptToByte(string data)
        {
            RSACryptoServiceProvider rsaPublic = new RSACryptoServiceProvider();
            rsaPublic.FromXmlString(RSAPublicKey);

            return rsaPublic.Encrypt(Encoding.UTF8.GetBytes(data), false);
        }
    }
}
