﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AlcUtility;

namespace PluginTest2
{
    public class PluginTest2 : PluginBase
    {
        public PluginTest2() : base("Test2")
        {
            AlcSystem.Instance.FormShown +=
                formName =>
                {
                    if (formName == "Test2")
                        AlcSystem.Instance.ShowMsgBox($"Form shown to {formName}", "Test2");
                };
        }

        public override Form GetForm()
        {
            return new Form();
        }
    }
}
