﻿using ALC.Forms;
using AlcUtility;
using LogLib;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;

namespace ALC.Managers
{
    public class LogicMgr
    {
        private static LogicMgr _instance = new LogicMgr();

        private LogicMgr() { }

        public static LogicMgr GetInstance()
        {
            return _instance;
        }

        private FormHome _formHome;

        public void SetFormHome(FormHome form)
        {
            _formHome = form;
        }

        public void UpdateSystemStatus(SYSTEM_STATUS status)
        {
            StatusMgr.SystemStatus = status;
            string msg = string.Empty;
            switch (status)
            {
                case SYSTEM_STATUS.Idle:
                    msg = "Idle";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Silver);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);

                    _formHome.SetButtonDefault(ButtonsName.Start, true);
                    _formHome.SetButtonDefault(ButtonsName.Pause, true);
                    break;

                case SYSTEM_STATUS.Initing:
                    msg = "Initializing...";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Yellow);

                    _formHome.SetButtonEnable(ButtonsName.Init, false);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, false);
                    break;

                case SYSTEM_STATUS.InitFailed:
                    msg = "Initialize Failed";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.OrangeRed);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);
                    break;

                case SYSTEM_STATUS.Ready:
                    msg = "Ready";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Yellow);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, true);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);

                    _formHome.SetButtonDefault(ButtonsName.Start, true);
                    _formHome.SetButtonDefault(ButtonsName.Pause, true);
                    break;

                case SYSTEM_STATUS.Starting:
                    msg = "Starting...";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Yellow);

                    _formHome.SetButtonEnable(ButtonsName.Init, false);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, false);
                    break;

                case SYSTEM_STATUS.StartFailed:
                    msg = "Start Failed";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.OrangeRed);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, true);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);
                    break;

                case SYSTEM_STATUS.Running:
                    msg = "Running";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Lime);

                    _formHome.SetButtonEnable(ButtonsName.Start, true);
                    _formHome.SetButtonEnable(ButtonsName.Pause, true);

                    _formHome.SetButtonDefault(ButtonsName.Start, false);
                    _formHome.SetButtonDefault(ButtonsName.Pause, true);
                    break;

                case SYSTEM_STATUS.Pausing:
                    msg = "Pausing";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Yellow);

                    _formHome.SetButtonEnable(ButtonsName.Init, false);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, false);
                    break;

                case SYSTEM_STATUS.PauseFailed:
                    msg = "PauseFailed";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.OrangeRed);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, true);
                    _formHome.SetButtonEnable(ButtonsName.Pause, true);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);
                    break;

                case SYSTEM_STATUS.Paused:
                    msg = "Paused";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Yellow);

                    _formHome.SetButtonEnable(ButtonsName.Start, true);
                    _formHome.SetButtonEnable(ButtonsName.Pause, true);

                    _formHome.SetButtonDefault(ButtonsName.Start, false);
                    _formHome.SetButtonDefault(ButtonsName.Pause, false);
                    break;

                case SYSTEM_STATUS.Resuming:
                    msg = "Resuming";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Yellow);

                    _formHome.SetButtonEnable(ButtonsName.Init, false);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, false);
                    break;

                case SYSTEM_STATUS.ResumeFailed:
                    msg = "ResumeFailed";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.OrangeRed);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, true);
                    _formHome.SetButtonEnable(ButtonsName.Pause, true);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);
                    break;

                case SYSTEM_STATUS.Finishing:
                    msg = "Finishing";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Yellow);

                    _formHome.SetButtonEnable(ButtonsName.Init, false);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, false);
                    break;

                case SYSTEM_STATUS.FinishedFailed:
                    msg = "Finish Failed";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.OrangeRed);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, true);
                    _formHome.SetButtonEnable(ButtonsName.Pause, true);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);
                    break;

                case SYSTEM_STATUS.Finished:
                    msg = "Finish OK";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Lime);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, true);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);

                    _formHome.SetButtonDefault(ButtonsName.Start, true);
                    _formHome.SetButtonDefault(ButtonsName.Pause, true);
                    break;

                case SYSTEM_STATUS.Resetting:
                    msg = "Resetting...";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Yellow);

                    _formHome.SetButtonEnable(ButtonsName.Init, false);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, false);
                    break;

                case SYSTEM_STATUS.ResetFailed:
                    msg = "Reset Failed";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.OrangeRed);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);
                    break;
                    
                case SYSTEM_STATUS.Error:
                    msg = "Error";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.OrangeRed);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);

                    _formHome.SetButtonDefault(ButtonsName.Start, true);
                    _formHome.SetButtonDefault(ButtonsName.Pause, true);
                    break;
                case SYSTEM_STATUS.Abort:
                    msg = "Abort";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.OrangeRed);

                    _formHome.SetButtonEnable(ButtonsName.Init, true);
                    _formHome.SetButtonEnable(ButtonsName.Start, false);
                    _formHome.SetButtonEnable(ButtonsName.Pause, false);
                    _formHome.SetButtonEnable(ButtonsName.Reset, true);

                    _formHome.SetButtonDefault(ButtonsName.Start, true);
                    _formHome.SetButtonDefault(ButtonsName.Pause, true);
                    break;

                default:
                    msg = "Idle";
                    _formHome.UpdateColor_Lbl_SystemStatus(Color.Silver);
                    break;
            }
            _formHome.UpdateText_Lbl_SystemStatus(msg);
        }

        public void UpdateModuleStatus(string module, bool isAlive)
        {
            _formHome.UpdateModuleStatus(module, isAlive);
        }

        public Func<string> CanInit;
        public Func<string> CanStart;
        public Func<string> CanStop;
        public Func<string> CanPause;
        public Func<string> CanResume;
        public Func<string> CanReset;

        public void Init()
        {
            if (!_formHome.GetButtonInUse(ButtonsName.Init))
            {
                Log.showMessageBox("can't init, button not in use", "init", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.GetButtonEnable(ButtonsName.Init))
            {
                Log.showMessageBox("can't init, button is disabled", "init", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.isAllModuleAlive())
            {
                Log.showMessageBox("can't init, not all module is alive", "init", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (CanInit != null)
            {
                foreach (Func<string> canInit in CanInit.GetInvocationList())
                {
                    string message = canInit();
                    if (!string.IsNullOrEmpty(message))
                    {
                        Log.showMessageBox($"can't init, {message}", "init", MsgBoxButtons.OK, MsgBoxIcon.Error);
                        return;
                    }
                }
            }

            Task.Run(() =>
            {
                UpdateSystemStatus(SYSTEM_STATUS.Initing);
                
                bool initOk = true;
                var pluOrder = PluginMgr.GetInstance().PluginsInitOrder;
                for (int i = 0; i < pluOrder.Count; i++)
                {
                    var plugins = pluOrder[i];
                    List<Thread> threads = new List<Thread>();
                    foreach (var p in plugins)
                    {
                        Thread t = new Thread(() =>
                        {
                            if (!p.init())
                            {
                                initOk = false;
                                Log.writeLog(p.ModuleType + " init fail", ErrorLevel.ERROR, p.ModuleType);
                            }
                        });
                        threads.Add(t);
                        t.Start();
                    }
                    foreach (var t in threads)
                    {
                        t.Join();
                    }
                    if (!initOk)
                        break;
                }

                if (StatusMgr.SystemStatus != SYSTEM_STATUS.Initing) return;

                if (initOk)
                {
                    Log.writeLog("All Plugins Init OK.");
                    UpdateSystemStatus(SYSTEM_STATUS.Ready);
                }
                else
                {
                    UpdateSystemStatus(SYSTEM_STATUS.InitFailed);
                }
            });
        }

        public void Start()
        {
            if (!_formHome.GetButtonInUse(ButtonsName.Start))
            {
                Log.showMessageBox("can't start, button not in use", "start", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.GetButtonEnable(ButtonsName.Start))
            {
                Log.showMessageBox("can't start, button is disabled", "start", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.GetButtonDefault(ButtonsName.Start))
            {
                Log.showMessageBox("can't start, already in start status", "start", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.isAllModuleAlive())
            {
                Log.showMessageBox("can't start, not all module is alive", "start", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (CanStart != null)
            {
                foreach (Func<string> canStart in CanStart.GetInvocationList())
                {
                    string message = canStart();
                    if (!string.IsNullOrEmpty(message))
                    {
                        Log.showMessageBox($"can't start, {message}", "start", MsgBoxButtons.OK, MsgBoxIcon.Error);
                        return;
                    }
                }
            }

            Task.Run(() =>
            {
                UpdateSystemStatus(SYSTEM_STATUS.Starting);

                bool startOk = true;
                var pluOrder = PluginMgr.GetInstance().PluginsStartOrder;
                for (int i = 0; i < pluOrder.Count; i++)
                {
                    var plugins = pluOrder[i];
                    List<Thread> threads = new List<Thread>();
                    foreach (var p in plugins)
                    {
                        Thread t = new Thread(() =>
                        {
                            if (!p.start())
                            {
                                startOk = false;
                                Log.writeLog(p.ModuleType + " start fail", ErrorLevel.ERROR, p.ModuleType);
                            }
                        });
                        threads.Add(t);
                        t.Start();
                    }
                    foreach (var t in threads)
                    {
                        t.Join();
                    }
                    if (!startOk)
                        break;
                }

                if (StatusMgr.SystemStatus != SYSTEM_STATUS.Starting) return;

                if (startOk)
                {
                    Log.writeLog("All Plugins Start OK.");
                    UpdateSystemStatus(SYSTEM_STATUS.Running);
                }
                else
                {
                    UpdateSystemStatus(SYSTEM_STATUS.StartFailed);
                }
            });

        }

        public void Stop()
        {
            if (!_formHome.GetButtonInUse(ButtonsName.Start))
            {
                Log.showMessageBox("can't stop, button not in use", "stop", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.GetButtonEnable(ButtonsName.Start))
            {
                Log.showMessageBox("can't stop, button is disabled", "stop", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (_formHome.GetButtonDefault(ButtonsName.Start))
            {
                Log.showMessageBox("can't stop, already in stop status", "stop", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.isAllModuleAlive())
            {
                Log.showMessageBox("can't stop, not all module is alive", "stop", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (CanStop != null)
            {
                foreach (Func<string> canStop in CanStop.GetInvocationList())
                {
                    string message = canStop();
                    if (!string.IsNullOrEmpty(message))
                    {
                        Log.showMessageBox($"can't stop, {message}", "stop", MsgBoxButtons.OK, MsgBoxIcon.Error);
                        return;
                    }
                }
            }

            Task.Run(() =>
            {
                UpdateSystemStatus(SYSTEM_STATUS.Finishing);

                bool stopOk = true;
                var pluOrder = PluginMgr.GetInstance().PluginsStopOrder;
                for (int i = 0; i < pluOrder.Count; i++)
                {
                    var plugins = pluOrder[i];
                    List<Thread> threads = new List<Thread>();
                    foreach (var p in plugins)
                    {
                        Thread t = new Thread(() =>
                        {
                            if (!p.stop())
                            {
                                stopOk = false;
                                Log.writeLog(p.ModuleType + " stop fail", ErrorLevel.ERROR, p.ModuleType);
                            }
                        });
                        threads.Add(t);
                        t.Start();
                    }
                    foreach (var t in threads)
                    {
                        t.Join();
                    }
                    if (!stopOk)
                        break;
                }

                if (StatusMgr.SystemStatus != SYSTEM_STATUS.Finishing) return;

                if (stopOk)
                {
                    Log.writeLog("All Plugins Stop OK.");
                    UpdateSystemStatus(SYSTEM_STATUS.Finished);
                }
                else
                {
                    UpdateSystemStatus(SYSTEM_STATUS.FinishedFailed);
                }
            });
        }

        public void Pause()
        {
            if (!_formHome.GetButtonInUse(ButtonsName.Pause))
            {
                Log.showMessageBox("can't pause, button not in use", "pause", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.GetButtonEnable(ButtonsName.Pause))
            {
                Log.showMessageBox("can't pause, button is disabled", "pause", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.GetButtonDefault(ButtonsName.Pause))
            {
                Log.showMessageBox("can't pause, already in pause status", "pause", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.isAllModuleAlive())
            {
                Log.showMessageBox("can't pause, not all module is alive", "pause", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (CanPause != null)
            {
                foreach (Func<string> canPause in CanPause.GetInvocationList())
                {
                    string message = canPause();
                    if (!string.IsNullOrEmpty(message))
                    {
                        Log.showMessageBox($"can't pause, {message}", "pause", MsgBoxButtons.OK, MsgBoxIcon.Error);
                        return;
                    }
                }
            }

            Task.Run(() =>
            {
                UpdateSystemStatus(SYSTEM_STATUS.Pausing);

                var plugins = PluginMgr.GetInstance().Plugins;
                List<Thread> threads = new List<Thread>();
                bool pauseOk = true;
                foreach (var p in plugins)
                {
                    Thread t = new Thread(() =>
                    {
                        if (!p.pause())
                        {
                            pauseOk = false;
                            Log.writeLog(p.ModuleType + " pause fail", ErrorLevel.ERROR, p.ModuleType);
                        }
                    });
                    threads.Add(t);
                    t.Start();
                }
                foreach (var t in threads)
                {
                    t.Join();
                }

                if (StatusMgr.SystemStatus != SYSTEM_STATUS.Pausing) return;

                if (pauseOk)
                {
                    Log.writeLog("All Plugins Pause OK.");
                    UpdateSystemStatus(SYSTEM_STATUS.Paused);
                }
                else
                {
                    UpdateSystemStatus(SYSTEM_STATUS.PauseFailed);
                }
            });
        }

        public void Resume()
        {
            if (!_formHome.GetButtonInUse(ButtonsName.Pause))
            {
                Log.showMessageBox("can't resume, button not in use", "resume", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.GetButtonEnable(ButtonsName.Pause))
            {
                Log.showMessageBox("can't resume, button is disabled", "resume", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (_formHome.GetButtonDefault(ButtonsName.Pause))
            {
                Log.showMessageBox("can't resume, already in resume status", "resume", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.isAllModuleAlive())
            {
                Log.showMessageBox("can't resume, not all module is alive", "resume", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (CanResume != null)
            {
                foreach (Func<string> canResume in CanResume.GetInvocationList())
                {
                    string message = canResume();
                    if (!string.IsNullOrEmpty(message))
                    {
                        Log.showMessageBox($"can't resume, {message}", "resume", MsgBoxButtons.OK, MsgBoxIcon.Error);
                        return;
                    }
                }
            }

            Task.Run(() =>
            {
                UpdateSystemStatus(SYSTEM_STATUS.Resuming);

                var plugins = PluginMgr.GetInstance().Plugins;
                List<Thread> threads = new List<Thread>();
                bool resumeOk = true;
                foreach (var p in plugins)
                {
                    Thread t = new Thread(() =>
                    {
                        if (!p.resume())
                        {
                            resumeOk = false;
                            Log.writeLog(p.ModuleType + " resume fail", ErrorLevel.ERROR, p.ModuleType);
                        }
                    });
                    threads.Add(t);
                    t.Start();
                }
                foreach (var t in threads)
                {
                    t.Join();
                }

                if (StatusMgr.SystemStatus != SYSTEM_STATUS.Resuming) return;

                if (resumeOk)
                {
                    Log.writeLog("All Plugins Resume OK.");
                    UpdateSystemStatus(SYSTEM_STATUS.Running);
                }
                else
                {
                    UpdateSystemStatus(SYSTEM_STATUS.ResumeFailed);
                }

            });
        }

        public void Reset()
        {
            if (!_formHome.GetButtonInUse(ButtonsName.Reset))
            {
                Log.showMessageBox("can't reset, button not in use", "init", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.GetButtonEnable(ButtonsName.Reset))
            {
                Log.showMessageBox("can't reset, button is disabled", "init", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (!_formHome.isAllModuleAlive())
            {
                Log.showMessageBox("can't reset, not all module is alive", "reset", MsgBoxButtons.OK, MsgBoxIcon.Error);
                return;
            }
            if (CanReset != null)
            {
                foreach (Func<string> canReset in CanReset.GetInvocationList())
                {
                    string message = canReset();
                    if (!string.IsNullOrEmpty(message))
                    {
                        Log.showMessageBox($"can't reset, {message}", "reset", MsgBoxButtons.OK, MsgBoxIcon.Error);
                        return;
                    }
                }
            }

            Task.Run(() =>
            {
                UpdateSystemStatus(SYSTEM_STATUS.Resetting);

                bool resetOk = true;
                var pluOrder = PluginMgr.GetInstance().PluginsResetOrder;
                for (int i = 0; i < pluOrder.Count; i++)
                {
                    var plugins = pluOrder[i];
                    List<Thread> threads = new List<Thread>();
                    foreach (var p in plugins)
                    {
                        Thread t = new Thread(() =>
                        {
                            if (!p.reset())
                            {
                                resetOk = false;
                                Log.writeLog(p.ModuleType + " reset fail", ErrorLevel.ERROR, p.ModuleType);
                            }
                        });
                        threads.Add(t);
                        t.Start();
                    }
                    foreach (var t in threads)
                    {
                        t.Join();
                    }
                    if (!resetOk)
                        break;
                }

                if (StatusMgr.SystemStatus != SYSTEM_STATUS.Resetting) return;

                if (resetOk)
                {
                    Log.writeLog("All Plugins Reset OK.");
                    UpdateSystemStatus(SYSTEM_STATUS.Idle);
                }
                else
                {
                    UpdateSystemStatus(SYSTEM_STATUS.ResetFailed);
                }
            });
        }

        public void Abort()
        {
            Task.Run(() =>
            {
                UpdateSystemStatus(SYSTEM_STATUS.Abort);

                var plugins = PluginMgr.GetInstance().Plugins;
                List<Thread> threads = new List<Thread>();
                bool abortOk = true;
                foreach (var p in plugins)
                {
                    Thread t = new Thread(() =>
                    {
                        if (!p.abort())
                        {
                            abortOk = false;
                            Log.writeLog(p.ModuleType + " abort fail", ErrorLevel.ERROR, p.ModuleType);
                        }
                    });
                    threads.Add(t);
                    t.Start();
                }
                foreach (var t in threads)
                {
                    t.Join();
                }

                if (abortOk)
                {
                    Log.writeLog("All Plugins Abort OK.");
                }
            });
        }

        public bool IsCloseable(out string details)
        {
            details = "";
            switch(StatusMgr.SystemStatus)
            {
                case SYSTEM_STATUS.Finishing:
                case SYSTEM_STATUS.Initing:
                case SYSTEM_STATUS.Paused:
                case SYSTEM_STATUS.Pausing:
                case SYSTEM_STATUS.Resetting:
                case SYSTEM_STATUS.Resuming:
                case SYSTEM_STATUS.Running:
                case SYSTEM_STATUS.Starting:
                    details = $"The software cannot be shut down while the system is {StatusMgr.SystemStatus.ToString()}!";
                    return false;
                case SYSTEM_STATUS.Abort:
                case SYSTEM_STATUS.Error:
                case SYSTEM_STATUS.Finished:
                case SYSTEM_STATUS.FinishedFailed:
                case SYSTEM_STATUS.Idle:
                case SYSTEM_STATUS.InitFailed:
                case SYSTEM_STATUS.PauseFailed:
                case SYSTEM_STATUS.Ready:
                case SYSTEM_STATUS.ResetFailed:
                case SYSTEM_STATUS.ResumeFailed:
                case SYSTEM_STATUS.StartFailed:
                default:
                    return true;
            }
        }
    }
}
