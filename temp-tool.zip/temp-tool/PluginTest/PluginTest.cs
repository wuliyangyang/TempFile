﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AlcUtility;

namespace PluginTest
{
    class PluginTest : PluginBase
    {
        private static PluginTest _instance;

        public static PluginTest GetInstance() { return _instance; }

        public PluginTest() : base("Test")
        {
            _instance = this;
        }

        public override bool Load()
        {
            UpdateModuleStatus(true);
            TestMgr.Test();
            //WriteAndReadConfig();
            return base.Load();
        }

        public override bool Initialize()
        {
            ShowMsgBox("test plugin init start", "Test");
            Thread.Sleep(1000);
            return true;
        }

        public override Form GetForm()
        {
            return new Form();
        }

        private void WriteAndReadConfig()
        {
            Task.Run(() =>
            {
                while (true)
                {
                    ConfigMgr.Instance.TestCfg = 100;
                    Thread.Sleep(80);
                }
            });

            Task.Run(() =>
            {
                while (true)
                {
                    int i = ConfigMgr.Instance.TestCfg;
                    Log($"get TestCfg: {i}");
                    if (i == 1000)
                    {
                        Error("get TestCfg Error", 1, AlcErrorLevel.WARN);
                    }
                    Thread.Sleep(50);
                }
            });
        }
    }
}
