﻿using AlcUtility;
using LogLib;
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace ALC.Managers
{
    public class BinaryFileHelper
    {
        private static BinaryFileHelper _instence = new BinaryFileHelper();
        public static BinaryFileHelper getInstence()
        {
            return _instence;
        }
        private BinaryFileHelper()
        { }

        private const string FileName = "p_p.db";
        private const int PasswordLength = 128;

        public string GetPassword(string authority)
        {
            byte[] passwordStr = ReadInfoFromFile();
            if (passwordStr == null) return null;
            return AnalyzerPasswordStr(authority, passwordStr);
        }

        /// <summary>
        /// 读取二进制文件信息方法
        /// </summary>
        /// <returns>对应用户密码</returns>
        private byte[] ReadInfoFromFile()
        {
            if (!File.Exists(FileName))
            {
                Log.writeLog("Log info file do not exist", ErrorLevel.DEBUG);
                return null;
            }

            byte[] binaryStr;

            FileStream fs = new FileStream(FileName, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            binaryStr = br.ReadBytes((int)fs.Length);

            br.Close();
            fs.Close();

            return binaryStr;
        }

        private string AnalyzerPasswordStr(string authority, byte[] passwordStr)
        {
            int passwordNum = passwordStr.Count() / PasswordLength / 2;
            byte[] bufferByte = new byte[PasswordLength];
            for (int i = 0; i < passwordNum; i++)
            {
                Array.ConstrainedCopy(passwordStr, i * 2 * PasswordLength, bufferByte, 0, PasswordLength);
                string bufferStr = RSAMgr.GetInstance().RSADecrypt(Convert.ToBase64String(bufferByte));
                if (authority.ToUpper() == bufferStr.ToUpper())
                {
                    Array.ConstrainedCopy(passwordStr, (i * 2 + 1) * PasswordLength, bufferByte, 0, PasswordLength);
                    return Convert.ToBase64String(bufferByte);
                }
            }
            return null;
        }

        public void SavePassword(string authority, string password)
        {
            byte[] passwordListByte = ReadInfoFromFile();

            if (passwordListByte != null)
            {
                bool isAuthorityExist = false;
                int passwordNum = passwordListByte.Count() / PasswordLength / 2;
                byte[] bufferByte = new byte[PasswordLength];
                for (int i = 0; i < passwordNum; i++)
                {
                    Array.ConstrainedCopy(passwordListByte, i * 2 * PasswordLength, bufferByte, 0, PasswordLength);
                    string bufferStr = RSAMgr.GetInstance().RSADecrypt(Convert.ToBase64String(bufferByte));
                    if (authority.ToUpper() == bufferStr.ToUpper())
                    {
                        isAuthorityExist = true;
                        bufferByte = RSAMgr.GetInstance().RSAEncryptToByte(password);
                        Array.ConstrainedCopy(bufferByte, 0, passwordListByte, (i * 2 + 1) * PasswordLength, PasswordLength);
                    }
                }
                if (!isAuthorityExist)
                {
                    byte[] passwordListByteNew = new byte[passwordListByte.Count() + PasswordLength * 2];
                    RSAMgr.GetInstance().RSAEncryptToByte(authority).CopyTo(passwordListByteNew, 0);
                    RSAMgr.GetInstance().RSAEncryptToByte(password).CopyTo(passwordListByteNew, PasswordLength);
                    passwordListByte.CopyTo(passwordListByteNew, PasswordLength * 2);
                    passwordListByte = passwordListByteNew;
                }
            }
            else
            {
                passwordListByte = new byte[PasswordLength * 2];
                RSAMgr.GetInstance().RSAEncryptToByte(authority).CopyTo(passwordListByte, 0);
                RSAMgr.GetInstance().RSAEncryptToByte(password).CopyTo(passwordListByte, PasswordLength);
            }

            FileStream fs = new FileStream(FileName, FileMode.Create);
            BinaryWriter binWriter = new BinaryWriter(fs);
            
            binWriter.Write(passwordListByte);

            binWriter.Close();
            fs.Close();
        }
    }
}
