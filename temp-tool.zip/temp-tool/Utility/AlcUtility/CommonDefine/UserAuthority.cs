﻿namespace AlcUtility
{
    public enum UserAuthority
    {
        ADMINISTRATOR = 0,
        ENGINEER,
        OPERATOR,
    }
}
