﻿using Newtonsoft.Json;
using System;

namespace AlcUtility
{
    public class MessageType
    {
        public const string REQ = "REQ";
        public const string RSP = "RSP";

        public const int ReqBinary = 0;
        public const int RspBinary = 1;
    }


    public class ReceivedData
    {
        public string moduleType { get; set; }
        public string moduleId { get; set; }
        
        public string ip { set; get; }
        public int port { set; get; }

        public JsonData strData { get; set; }
        public BinaryData binaryData { get; set; }

        public string toString()
        {
            string res = string.Format("moduleType = {0}, moduleId = {1}, ip = {2}, port = {3}, strData = {4}， BinaryData = {5}",
                moduleType ?? "", moduleId ?? "", ip ?? "", port,
                strData == null ? "" : strData.ToString(),
                binaryData == null ? "" : binaryData.ToString());
            return res;
        }
    }

    public class JsonData
    {
        public int msgChannel { set; get; }
        public string msgType { set; get; }
        public string msgName { set; get; }
        public object msgParam { set; get; }
        public Int64 msgResult { set; get; }
        public string errMsg { set; get; }

        public string toString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }

    public class BinaryData
    {
        public int channelId { set; get; }//4 byte
        public int msgType { set; get; }//4 byte
        public int commandId { set; get; }//4 byte
        public float param1 { set; get; }//4 byte
        public float param2 { set; get; }//4 byte
        public float param3 { set; get; }//4 byte
        public float param4 { set; get; }//4 byte
        public float param5 { set; get; }//4 byte
        public Int64 errorcode { set; get; }//4 byte
        public string strMessage {set; get;}// 32 byte

        public string toString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
    
    public class CommonCommands
    {
        public const string Register = "register";
        public const string Disconnected = "disconnected";

        public const int RegisterBinary = 1;
        public const int DisconnectedBinary = 999;
    }

    public class RegisterParam
    {
        public string moduletype { set; get; }
        public string moduleid { set; get; }
    }
}
